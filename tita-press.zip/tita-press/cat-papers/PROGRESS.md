# CAT papers — progress and workflow

Done: all 21 papers (diagnostic-01, full-mock-01 … full-mock-20). Each builds cleanly with every check passing.
keycheck reports 37 warnings across the set; each was reviewed, and all are numbers written as words in the solutions.

## Per-paper workflow
1. `full-mock-NN/paper.py` — NAME, LEDE, SEED.
2. `content_dilr.py` — 5 sets / 22 questions; each set has a solver; `verify()` asserts every key.
3. `content_varc.py` — 4 passages × 4 Q, plus VA: 3 summaries, 3 jumbles (key must not be the printed order), 2 odd-one-out.
   Solutions name options in words, not letters.
4. `content_qa.py` — 22 questions, each with a `check()` lambda.
5. `python3 autobalance.py full-mock-NN` — slides evenly spaced numeric option windows to spread keys across A–D.
6. `python3 build.py full-mock-NN` — reruns all checks, shuffles/sorts options, renders PDFs to out/.
7. `python3 keycheck.py full-mock-NN` — warns if a numeric key's value is missing from its solution (review each warning).

Rebuild everything: `python3 -B build.py diagnostic-01 full-mock-{01..20}`.
