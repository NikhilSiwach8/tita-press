"""Spread numeric MCQ keys across A-D by sliding evenly spaced option windows.

Usage: python3 autobalance.py full-mock-11
Only touches questions whose options are integers in arithmetic progression (optional % or ° suffix);
the window is shifted by whole steps, never below zero, so the right answer stays among plausible neighbours.
"""
import importlib, re, sys
from collections import Counter
from rebalance import rebalance

FORMAT = re.compile(r"^(\d+)([%°]?)$")


def parse(opts):
    m = [FORMAT.match(o) for o in opts]
    if not all(m) or len({x.group(2) for x in m}) != 1 or any("," in o for o in opts):
        return None
    vals = [int(x.group(1)) for x in m]
    steps = {b - a for a, b in zip(vals, vals[1:])}
    return (vals, m[0].group(2)) if len(steps) == 1 and steps.pop() > 0 else None


def main(folder):
    sys.path.insert(0, folder)
    items = []  # (file, question dict)
    for name in ("content_dilr", "content_qa"):
        mod = importlib.import_module(name)
        qs = [q for s in mod.SETS for q in s["questions"]] if name == "content_dilr" else mod.QA
        items += [(f"{folder}/{name}.py", q) for q in qs if not q.get("tita")]
    numeric = []
    for f, q in items:
        try:
            vals = sorted(float(o.rstrip("%°").replace(",", "")) for o in q["opts"])
        except ValueError:
            continue
        numeric.append((f, q))
    count = Counter(sorted(q["opts"], key=lambda o: float(o.rstrip("%°").replace(",", ""))).index(q["opts"][q["ans"]]) for _, q in numeric)
    target = len(numeric) / 4
    changes = {}
    for f, q in numeric:
        p = parse(q["opts"])
        if not p: continue
        vals, suf = p
        right = int(q["opts"][q["ans"]].rstrip("%°"))
        pos = vals.index(right)
        if count[pos] <= target: continue
        step = vals[1] - vals[0]
        for new in sorted(range(4), key=lambda k: count[k]):
            lo = right - new * step
            if count[new] >= target or lo < 0 or new == pos: continue
            opts = [f"{lo + k * step}{suf}" for k in range(4)]
            changes.setdefault(f, []).append((q["q"][:60], opts, new))
            count[pos] -= 1; count[new] += 1
            break
    for f, ch in changes.items():
        rebalance(f, ch)
    print("positions after:", dict(sorted(count.items())), "| changed:", sum(len(c) for c in changes.values()))


if __name__ == "__main__":
    main(sys.argv[1])
