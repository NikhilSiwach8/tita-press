"""Build a TITA Press paper: verify every answer, then render the paper and solutions to PDF.

Usage: python3 build.py diagnostic-01 [full-mock-01 ...]   (writes out/*.html and out/*.pdf)

Each paper folder holds paper.py (NAME, LEDE, SEED) and content_varc.py, content_dilr.py, content_qa.py.
"""
import html
from fractions import Fraction
import pathlib
import random
import re
import subprocess

import importlib
import sys

ROOT = pathlib.Path(__file__).parent
OUT = ROOT / "out"
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
PAPER_NAME = LEDE = SEED = None  # set by load_paper()
content_varc = content_dilr = content_qa = None
LETTERS = "ABCD"
e = html.escape


# ---------- flatten into numbered questions ----------
def build_questions():
    qs = []
    for p in content_varc.PASSAGES:
        for i, q in enumerate(p["questions"]):
            qs.append(dict(sec="VARC", group=p["title"], first=i == 0, intro=p["text"], **q))
    last_kind = None
    for v in content_varc.VA:
        item = dict(sec="VARC", kind=v["kind"], ans=v["ans"], sol=v["sol"], tita=v["kind"] != "summary")
        item["direction"] = content_varc.VA_DIRECTIONS[v["kind"]] if v["kind"] != last_kind else None
        if v["kind"] == "summary":
            item.update(q=v["text"], opts=v["opts"])
        else:
            item.update(sentences=v["sentences"])
        last_kind = v["kind"]
        qs.append(item)
    for s in content_dilr.SETS:
        for i, q in enumerate(s["questions"]):
            qs.append(dict(sec="DILR", group=s["title"], first=i == 0, intro=s["intro"], table=s.get("table"), **q))
    for q in content_qa.QA:
        qs.append(dict(sec="QA", **{k: v for k, v in q.items() if k != "check"}))
    for n, q in enumerate(qs, 1):
        q["n"] = n
        q.setdefault("tita", False)
    shuffle_keys(qs)
    return qs


# Content is written with most keys on (B); spread them evenly across A–D.
# Moving the right option swaps it with whatever sat in the target slot,
# and VARC solutions that name options by letter are relettered to match.
OPTION_REF = re.compile(r"\b[A-D]\b")
NEXT_WORD = re.compile(r" ([a-z]+)")
# "A" + lowercase word is ambiguous: option A ("A contradicts…") or the article ("A temptation…").
# Every case must be listed here, so a new solution can never be relettered wrongly in silence.
OPTION_VERBS = {"is", "and", "ignores", "contradicts", "overstates", "misstates", "confuses", "describes", "reverses", "misreads", "goes", "misses", "takes", "belongs", "overgeneralises"}
ARTICLE_NOUNS = {"temptation", "good", "literal", "queue", "nudge", "text", "belief", "better", "library", "note", "standard", "building", "reconstruction", "gift", "leap", "drug", "field", "partial"}


def reletter(sol, moved):
    # Solutions that name options only in words carry no letters to change
    if not re.search(r"\b[B-D]\b", sol) and not any(re.search(rf"\bA {v}\b", sol) for v in OPTION_VERBS):
        return sol
    def sub(m):
        if m.group() == "A":
            w = NEXT_WORD.match(sol, m.end())
            if w and w.group(1) in ARTICLE_NOUNS:
                return "A"
            if w and w.group(1) not in OPTION_VERBS:
                raise ValueError(f"Unclear 'A {w.group(1)}' in solution; add it to OPTION_VERBS or ARTICLE_NOUNS: {sol[:80]}")
        return moved[m.group()]
    return OPTION_REF.sub(sub, sol)


LAST_OPTIONS = {"Cannot be determined", "None of these", "None of them"}
NUMERIC = re.compile(r"^(?:Seed |Room |M)?([−-]?[\d,]+(?:\.\d+)?(?:/\d+)?)(?:√(\d+))?[%°]?$")


CLOCK = re.compile(r"^(\d{1,2}):(\d{2})$")


def numeric_value(opt):
    """Value of a numeric option such as '18,000', '−1', '63/125', '22.22%', '130°', '24√3' or '09:58'; None for text."""
    t = CLOCK.match(opt)
    if t:
        return int(t.group(1)) * 60 + int(t.group(2))
    m = NUMERIC.match(opt)
    if not m:
        return None
    s = m.group(1).replace(",", "").replace("−", "-")
    return float(Fraction(s)) * (float(m.group(2)) ** 0.5 if m.group(2) else 1)


def shuffle_keys(qs):
    mcqs = [q for q in qs if not q["tita"]]
    # Numeric options are printed in ascending order, as in the real paper; only text options are shuffled
    textual = []
    for q in mcqs:
        tail = [o for o in q["opts"] if o in LAST_OPTIONS]
        body = [o for o in q["opts"] if o not in tail]
        if None in [numeric_value(o) for o in body]:
            textual.append(q)
            continue
        right = q["opts"][q["ans"]]
        q["opts"] = sorted(body, key=numeric_value) + tail
        q["ans"] = q["opts"].index(right)
    # Aim the text-option keys at whichever letters the numeric keys left short
    counts = [sum(1 for q in mcqs if q not in textual and q["ans"] == i) for i in range(4)]
    targets = []
    for _ in textual:
        i = min(range(4), key=lambda i: counts[i])
        counts[i] += 1
        targets.append(LETTERS[i])
    random.Random(SEED).shuffle(targets)
    for q, t in zip(textual, targets):
        old, new = q["ans"], LETTERS.index(t)
        order = list(range(4))
        order[old], order[new] = order[new], order[old]
        q["opts"] = [q["opts"][i] for i in order]
        q["ans"] = new
        moved = {LETTERS[order[i]]: LETTERS[i] for i in range(4)}  # original letter -> new letter
        if q["sec"] == "VARC":
            q["sol"] = reletter(q["sol"], moved)
    # "Cannot be determined" and "None of …" always go last, as in the real paper
    for q in textual:
        last = [o for o in q["opts"] if o in LAST_OPTIONS]
        if last:
            assert q["sec"] != "VARC" and len(last) == 1, "relettering would also be needed"
            i = q["opts"].index(last[0])
            q["opts"][i], q["opts"][3] = q["opts"][3], q["opts"][i]
            q["ans"] = {i: 3, 3: i}.get(q["ans"], q["ans"])


def answer_text(q):
    return q["ans"] if q["tita"] else LETTERS[q["ans"]]


def check_structure(qs):
    counts = {s: sum(1 for q in qs if q["sec"] == s) for s in ("VARC", "DILR", "QA")}
    assert counts == {"VARC": 24, "DILR": 22, "QA": 22}, counts
    for q in qs:
        if not q["tita"]:
            assert len(q["opts"]) == 4 and 0 <= q["ans"] < 4, q["n"]
            assert len(set(q["opts"])) == 4, f"duplicate options in Q{q['n']}"
            ratios = [Fraction(int(x), int(y)) for x, y in (re.fullmatch(r"(\d+) : (\d+)", o).groups() for o in q["opts"] if re.fullmatch(r"\d+ : \d+", o))]
            assert len(set(ratios)) == len(ratios), f"Q{q['n']}: two ratio options are equal"
        if q.get("kind") == "jumble":
            want = sorted(str(i) for i in range(1, len(q["sentences"]) + 1))
            assert sorted(q["ans"]) == want, f"Q{q['n']}: jumble key {q['ans']} is not an ordering of all its sentences"
            assert q["ans"] != "".join(want), f"Q{q['n']}: jumble key is the printed order, so it can be guessed"
        if q.get("kind") == "odd":
            assert q["ans"] in [str(i) for i in range(1, len(q["sentences"]) + 1)], f"Q{q['n']}: odd-one-out key out of range"
    # MCQ keys should not pile up on one letter
    from collections import Counter
    return counts, Counter(LETTERS[q["ans"]] for q in qs if not q["tita"])


# ---------- shared styles ----------
CSS = """
@page { size: A4; margin: 18mm 16mm 20mm;
  @bottom-left { content: "TITA Press · __NAME__"; font: 8pt 'IBM Plex Mono', monospace; color: #6b7285; }
  @bottom-right { content: "Page " counter(page); font: 8pt 'IBM Plex Mono', monospace; color: #6b7285; } }
@page :first { @bottom-left { content: none; } @bottom-right { content: none; } }
:root { --ink: #1a2132; --muted: #5a6377; --line: #cfd5e2; --omr: #c8304f; --soft: #f3f5f9; }
* { box-sizing: border-box; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body { margin: 0; color: var(--ink); font: 10.5pt/1.5 'IBM Plex Serif', Georgia, serif; }
h1, h2, h3, .sans { font-family: 'Archivo', 'Helvetica Neue', Arial, sans-serif; }
.mono { font-family: 'IBM Plex Mono', Menlo, monospace; font-variant-numeric: tabular-nums; }
.cover { page-break-after: always; }
.brand { display: flex; align-items: center; gap: 8px; font: 800 13pt 'Archivo', sans-serif; font-stretch: 125%; }
.mark { display: inline-grid; grid-template-columns: repeat(2, 7px); gap: 2px; }
.mark i { width: 7px; height: 7px; border-radius: 50%; border: 1.3px solid var(--omr); }
.mark i:nth-child(1), .mark i:nth-child(4) { background: var(--omr); }
.cover h1 { font-size: 40pt; font-weight: 800; font-stretch: 118%; letter-spacing: -.02em; line-height: 1; margin: 18mm 0 4mm; }
.cover .sub { font: 500 10pt 'IBM Plex Mono', monospace; letter-spacing: .06em; text-transform: uppercase; color: var(--omr); }
.cover .lede { font-family: 'IBM Plex Sans', sans-serif; font-size: 11pt; color: var(--muted); max-width: 120mm; margin-top: 6mm; }
.fill { display: grid; grid-template-columns: 1fr 1fr; gap: 5mm 10mm; margin-top: 10mm; font-family: 'IBM Plex Sans', sans-serif; font-size: 9.5pt; }
.fill div { border-bottom: 1px solid var(--ink); padding-bottom: 6mm; color: var(--muted); }
table { border-collapse: collapse; width: 100%; font-family: 'IBM Plex Sans', sans-serif; font-size: 9.5pt; }
th, td { border: 1px solid var(--line); padding: 5px 8px; text-align: left; }
thead th { background: var(--soft); font-weight: 600; }
td.r, th.r { text-align: right; font-family: 'IBM Plex Mono', monospace; }
.instr { margin-top: 6mm; }
.instr h2 { font-size: 11pt; margin: 6mm 0 2mm; font-stretch: 110%; }
.instr ul { margin: 0; padding-left: 5mm; font-family: 'IBM Plex Sans', sans-serif; font-size: 9.5pt; }
.instr li { margin-bottom: 1.2mm; }
.foot { margin-top: 8mm; font: 8pt 'IBM Plex Sans', sans-serif; color: var(--muted); }
.section-head { gap: 6mm; page-break-before: always; border-bottom: 2px solid var(--ink); padding-bottom: 3mm; margin-bottom: 5mm; display: flex; justify-content: space-between; align-items: baseline; }
.section-head h2 { font-size: 18pt; font-stretch: 112%; margin: 0; }
.section-head span { font: 500 9pt 'IBM Plex Mono', monospace; color: var(--muted); }
.directions { font-family: 'IBM Plex Sans', sans-serif; font-size: 9.5pt; font-style: italic; color: var(--muted); margin: 5mm 0 3mm; }
.group { margin: 6mm 0 3mm; }
.group.set { break-inside: avoid; }
.group h3 { font: 600 9pt 'IBM Plex Mono', monospace; letter-spacing: .08em; text-transform: uppercase; color: var(--omr); margin: 0 0 2mm; }
.passage p { margin: 0 0 2.2mm; text-align: justify; hyphens: auto; }
.passage.dilr p { text-align: left; font-family: 'IBM Plex Sans', sans-serif; font-size: 10pt; margin-bottom: 1.2mm; }
.passage table { margin: 3mm 0 1mm; width: auto; min-width: 60%; }
.q { break-inside: avoid; margin: 4mm 0; display: grid; grid-template-columns: 9mm 1fr; }
.q .num { font: 600 10pt 'IBM Plex Mono', monospace; }
.q .num small { display: block; font-size: 6.5pt; color: var(--omr); letter-spacing: .05em; }
.opts { list-style: none; margin: 1.5mm 0 0; padding: 0; display: grid; gap: 1mm; }
.opts li { display: grid; grid-template-columns: 7mm 1fr; }
.opts li b { font: 600 9.5pt 'IBM Plex Mono', monospace; }
.sents { list-style: none; margin: 1.5mm 0 0; padding: 0; display: grid; gap: 1mm; }
.sents li { display: grid; grid-template-columns: 7mm 1fr; }
.tita-box { margin-top: 2mm; display: flex; gap: 1.2mm; align-items: center; font: 8pt 'IBM Plex Mono', monospace; color: var(--muted); }
.tita-box i { width: 6mm; height: 6.5mm; border: 1px solid var(--muted); }
.rough { break-inside: avoid; height: 32mm; border: 1px dashed var(--line); margin-top: 4mm; padding: 2mm 3mm; font: 8pt 'IBM Plex Mono', monospace; color: var(--muted); }
/* answer sheet */
.sheet { page-break-before: always; }
.sheet-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 8mm; margin-top: 4mm; }
.sheet-col h3 { font: 600 9pt 'IBM Plex Mono', monospace; letter-spacing: .08em; color: var(--omr); margin: 0 0 2mm; border-bottom: 1px solid var(--line); padding-bottom: 1mm; }
.row { display: flex; align-items: center; gap: 2.2mm; height: 8.6mm; border-bottom: 1px dotted var(--line); font: 8.5pt 'IBM Plex Mono', monospace; }
.row .n { width: 7mm; font-weight: 600; }
.bub { width: 5mm; height: 5mm; border-radius: 50%; border: 1.2px solid var(--omr); display: grid; place-items: center; font-size: 6.5pt; color: var(--omr); }
.tbox { width: 4.6mm; height: 5.4mm; border: 1px solid var(--muted); }
.tl { font-size: 6pt; color: var(--muted); margin-right: 1mm; }
/* solutions */
.key { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 8mm; }
.key .row { height: 5.6mm; justify-content: space-between; }
.key .row b { font-weight: 600; }
.key .row span.t { color: var(--muted); font-size: 7pt; }
.sol { break-inside: avoid; margin: 3.5mm 0; display: grid; grid-template-columns: 11mm 1fr; padding-bottom: 3mm; border-bottom: 1px dotted var(--line); }
.sol .qtext { font-family: 'IBM Plex Sans', sans-serif; font-size: 9pt; color: var(--muted); margin-bottom: 1.2mm; }
.sol .ans { font: 600 9.5pt 'IBM Plex Mono', monospace; color: #1d8656; margin-bottom: 1mm; }
.sol .exp { font-size: 10pt; }
.score { margin-top: 6mm; }
.score { break-inside: avoid; }
.score td { height: 8mm; }
"""

FONTS = '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,400..800&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Serif:ital,wght@0,400;0,600;1,400&display=swap">'
BRAND = '<div class="brand"><span class="mark"><i></i><i></i><i></i><i></i></span>TITA Press</div>'
SECTIONS = [("VARC", "Verbal Ability and Reading Comprehension"),
            ("DILR", "Data Interpretation and Logical Reasoning"),
            ("QA", "Quantitative Ability")]


def page(title, body):
    return f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>{e(title)}</title>{FONTS}<style>{CSS.replace('__NAME__', PAPER_NAME)}</style></head><body>{body}</body></html>"


def section_table(qs):
    rows = ""
    for code, name in SECTIONS:
        sq = [q for q in qs if q["sec"] == code]
        t = sum(q["tita"] for q in sq)
        rows += f"<tr><td><b>{code}</b> · {name}</td><td class='r'>{sq[0]['n']}–{sq[-1]['n']}</td><td class='r'>{len(sq)}</td><td class='r'>{len(sq) - t}</td><td class='r'>{t}</td><td class='r'>40 min</td></tr>"
    return f"<table><thead><tr><th>Section</th><th class='r'>Questions</th><th class='r'>Count</th><th class='r'>MCQ</th><th class='r'>TITA</th><th class='r'>Time</th></tr></thead><tbody>{rows}</tbody></table>"


NUMERIC_CELL = re.compile(r"[−+-]?[\d,.]+%?(?: \(\d+\))?|–")


def render_table(t):
    # Right-align a column only if every cell in it is a number (or a blank dash)
    numeric = [i > 0 and all(NUMERIC_CELL.fullmatch(r[i]) for r in t["rows"]) for i in range(len(t["head"]))]
    head = "".join(f"<th{' class=r' if numeric[i] else ''}>{e(h)}</th>" for i, h in enumerate(t["head"]))
    body = "".join("<tr>" + "".join(f"<td{' class=r' if numeric[i] else ''}>{e(c)}</td>" for i, c in enumerate(r)) + "</tr>" for r in t["rows"])
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def render_question(q):
    tag = "<small>TITA</small>" if q["tita"] else ""
    if q.get("sentences"):
        stem = "<ol class='sents'>" + "".join(f"<li><b class='mono'>{i}.</b><span>{e(s)}</span></li>" for i, s in enumerate(q["sentences"], 1)) + "</ol>"
    elif q.get("kind") == "summary":
        stem = f"<p style='margin:0'>{e(q['q'])}</p>"
    else:
        stem = f"<p style='margin:0'>{e(q['q'])}</p>"
    if q["tita"]:
        width = 6 if q["sec"] != "VARC" else 5
        answer = "<div class='tita-box'>Your answer " + "<i></i>" * width + "</div>"
    else:
        answer = "<ol class='opts'>" + "".join(f"<li><b>({LETTERS[i]})</b><span>{e(o)}</span></li>" for i, o in enumerate(q["opts"])) + "</ol>"
    return f"<div class='q'><div class='num'>{q['n']}{tag}</div><div>{stem}{answer}</div></div>"


def render_paper(qs):
    total_tita = sum(q["tita"] for q in qs)
    body = f"""<section class='cover'>{BRAND}
      <h1>{PAPER_NAME}</h1>
      <div class='sub'>CAT pattern · 68 questions · 120 minutes · {total_tita} TITA</div>
      <p class='lede'>{e(LEDE)}</p>
      <div class='fill'><div>Name</div><div>Date</div><div>Start time</div><div>Finish time</div></div>
      <div class='instr'>
        <h2>Paper structure</h2>{section_table(qs)}
        <h2>Marking</h2>
        <ul><li>MCQ: +3 for a correct answer, −1 for a wrong answer, 0 if left blank.</li>
            <li>TITA (type in the answer): +3 for a correct answer, 0 for a wrong or blank answer. There are no options; write your answer in the boxes.</li>
            <li>Maximum score: 204.</li></ul>
        <h2>Rules for the attempt</h2>
        <ul><li>Attempt the sections in order: VARC, then DILR, then QA. Give each section exactly 40 minutes.</li>
            <li>When a section's 40 minutes are up, move on. Do not return to an earlier section.</li>
            <li>An on-screen basic calculator is allowed in the real exam. Use a basic four-function calculator only.</li>
            <li>Mark your final answers on the answer sheet at the back of this paper.</li></ul>
      </div>
      <p class='foot'>© TITA Press. All questions are original and written for practice in the CAT pattern. TITA Press is independent and not affiliated with the IIMs, which conduct CAT.</p>
    </section>"""
    for code, name in SECTIONS:
        sq = [q for q in qs if q["sec"] == code]
        body += f"<div class='section-head'><h2>{name}</h2><span>{code} · Q{sq[0]['n']}–{sq[-1]['n']} · 40 minutes</span></div>"
        if code == "VARC":
            body += "<p class='directions'>Directions for questions 1 to 16: Read each passage and answer the questions that follow it.</p>"
        if code == "DILR":
            body += "<p class='directions'>Directions: Each set below is followed by questions. Answer them using the information given.</p>"
        if code == "QA":
            body += "<p class='directions'>Directions: Choose the correct option for MCQs, or write your answer in the boxes for TITA questions.</p>"
        for q in sq:
            if q.get("first"):
                cls = "passage dilr" if code == "DILR" else "passage"
                paras = "".join(f"<p>{e(p)}</p>" for p in q["intro"])
                table = render_table(q["table"]) if q.get("table") else ""
                body += f"<div class='group{' set' if code == 'DILR' else ''}'><h3>{q['group']}</h3><div class='{cls}'>{paras}{table}</div></div>"
            if q.get("direction"):
                body += f"<p class='directions'>{e(q['direction'])}</p>"
            body += render_question(q)
        body += "<div class='rough'>Rough work</div>"
    # answer sheet
    cols = ""
    for code, _ in SECTIONS:
        rows = ""
        for q in [q for q in qs if q["sec"] == code]:
            if q["tita"]:
                marks = "<span class='tl'>TITA</span>" + "<span class='tbox'></span>" * 5
            else:
                marks = "".join(f"<span class='bub'>{l}</span>" for l in LETTERS)
            rows += f"<div class='row'><span class='n'>{q['n']}</span>{marks}</div>"
        cols += f"<div class='sheet-col'><h3>{code}</h3>{rows}</div>"
    body += f"""<section class='sheet'><div class='section-head' style='page-break-before:avoid'><h2>Answer sheet</h2><span>{PAPER_NAME}</span></div>
      <p class='directions' style='margin-top:0'>Fill one bubble per MCQ. For TITA questions, write one character per box.</p>
      <div class='sheet-grid'>{cols}</div></section>"""
    return page(f"TITA Press {PAPER_NAME}", body)


def render_solutions(qs):
    key_cols = ""
    for code, _ in SECTIONS:
        rows = "".join(f"<div class='row'><span class='n'>{q['n']}</span><b>{e(answer_text(q))}</b><span class='t'>{'TITA' if q['tita'] else 'MCQ'}</span></div>"
                       for q in qs if q["sec"] == code)
        key_cols += f"<div class='sheet-col'><h3>{code}</h3>{rows}</div>"
    score_rows = "".join(f"<tr><td><b>{c}</b></td><td></td><td></td><td></td><td></td><td></td></tr>" for c, _ in SECTIONS)
    body = f"""<section class='cover' style='height:auto;page-break-after:always'>{BRAND}
      <h1 style='margin-top:10mm;font-size:28pt'>{PAPER_NAME}<br>Answer key and solutions</h1>
      <div class='key' style='margin-top:8mm'>{key_cols}</div>
      <div class='score instr'><h2>Your score</h2>
        <table><thead><tr><th>Section</th><th class='r'>MCQ right</th><th class='r'>MCQ wrong</th><th class='r'>TITA right</th><th class='r'>Score = 3 × right − MCQ wrong</th><th class='r'>Time used</th></tr></thead>
        <tbody>{score_rows}<tr><td><b>Total</b></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table>
      </div></section>"""
    for code, name in SECTIONS:
        sq = [q for q in qs if q["sec"] == code]
        body += f"<div class='section-head'><h2>{name}</h2><span>Solutions · Q{sq[0]['n']}–{sq[-1]['n']}</span></div>"
        group = None
        for q in sq:
            if q.get("group") and q["group"] != group and q.get("first"):
                group = q["group"]
                body += f"<div class='group'><h3>{group}</h3></div>"
            if q.get("sentences"):
                stem = " / ".join(f"{i}. {s}" for i, s in enumerate(q["sentences"], 1))
                stem = ("Sentence order: " if q["kind"] == "jumble" else "Odd one out: ") + stem
            else:
                stem = q["q"]
            if len(stem) > 230:
                stem = stem[:227].rsplit(" ", 1)[0] + "…"
            ans = answer_text(q)
            if not q["tita"]:
                ans = f"({ans}) {q['opts'][q['ans']]}"
            body += f"<div class='sol'><div class='mono' style='font-weight:600'>{q['n']}</div><div><div class='qtext'>{e(stem)}</div><div class='ans'>Answer: {e(ans)}</div><div class='exp'>{e(q['sol'])}</div></div></div>"
    return page(f"TITA Press {PAPER_NAME} Solutions", body)


def to_pdf(html_path, pdf_path):
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--virtual-time-budget=15000",
                    f"--print-to-pdf={pdf_path}", html_path.as_uri()], check=True, capture_output=True)


def load_paper(folder):
    """Import a paper folder's modules fresh, so several papers can be built in one run."""
    global PAPER_NAME, LEDE, SEED, content_varc, content_dilr, content_qa
    path = str((ROOT / folder).resolve())
    sys.path.insert(0, path)
    try:
        mods = {}
        for name in ("paper", "content_varc", "content_dilr", "content_qa"):
            sys.modules.pop(name, None)
            mods[name] = importlib.import_module(name)
    finally:
        sys.path.remove(path)
    PAPER_NAME, LEDE, SEED = mods["paper"].NAME, mods["paper"].LEDE, mods["paper"].SEED
    content_varc, content_dilr, content_qa = mods["content_varc"], mods["content_dilr"], mods["content_qa"]


def build(folder):
    load_paper(folder)
    print(f"== {PAPER_NAME}")
    print(content_dilr.verify())
    print(content_qa.verify())
    qs = build_questions()
    counts, letters = check_structure(qs)
    print("Section counts:", counts, "| MCQ key spread:", dict(sorted(letters.items())), "| TITA:", sum(q["tita"] for q in qs))
    OUT.mkdir(exist_ok=True)
    slug = PAPER_NAME.lower().replace(" ", "-")
    for kind, html_text in (("paper", render_paper(qs)), ("solutions", render_solutions(qs))):
        h = OUT / f"{slug}-{kind}.html"
        h.write_text(html_text, encoding="utf-8")
        p = OUT / f"TITA-Press-{PAPER_NAME.replace(' ', '-')}-{kind.title()}.pdf"
        to_pdf(h, p)
        print("Wrote", p.name)


if __name__ == "__main__":
    for folder in sys.argv[1:] or ["diagnostic-01"]:
        build(folder)
