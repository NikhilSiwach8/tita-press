"""DILR section: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import permutations, product, combinations
from fractions import Fraction

# ---------- Set 1: seating ----------
def seating_solutions():
    sols = []
    for perm in permutations("PQRSTUV"):
        pos = {p: i + 1 for i, p in enumerate(perm)}
        if pos["Q"] not in (1, 7): continue
        if abs(pos["Q"] - pos["S"]) != 3: continue
        if pos["R"] - pos["T"] != 1: continue
        if abs(pos["U"] - pos["S"]) == 1: continue
        if not (pos["P"] > pos["V"] + 1): continue
        if pos["V"] in (1, 7) or pos["T"] in (1, 7): continue
        sols.append("".join(perm))
    return sols

# ---------- Set 2: tournament ----------
TEAMS = "ABCDE"
MATCHES = list(combinations(TEAMS, 2))

def tally(out):
    pts = dict.fromkeys(TEAMS, 0); w = dict.fromkeys(TEAMS, 0); d = dict.fromkeys(TEAMS, 0)
    for (a, b), o in zip(MATCHES, out):
        if o == 0: pts[a] += 3; w[a] += 1
        elif o == 2: pts[b] += 3; w[b] += 1
        else: pts[a] += 1; pts[b] += 1; d[a] += 1; d[b] += 1
    return pts, w, d

def tournament_solutions():
    sols = []
    for out in product(range(3), repeat=10):
        pts, w, d = tally(out)
        v = [pts[t] for t in TEAMS]
        if len(set(v)) < 5 or sorted(v, reverse=True) != v: continue
        if pts["A"] != 10: continue
        if out.count(1) != 3: continue
        if w["E"] != 0 or d["E"] != 1: continue
        if w["D"] != 1: continue
        if out[MATCHES.index(("A", "E"))] != 1: continue
        sols.append(out)
    return sols

def result(out, a, b):
    o = out[MATCHES.index((a, b))]
    return {0: a, 1: "draw", 2: b}[o]

# ---------- Set 3: bookshop table ----------
UNITS = {"North": (420, 610, 180), "South": (380, 720, 240), "East": (510, 450, 300),
         "West": (300, 820, 150), "Central": (460, 540, 260)}
PRICES = (350, 500, 200)
def revenue(b): return sum(u * p for u, p in zip(UNITS[b], PRICES))

# ---------- Set 4: workshop schedule ----------
def schedule_solutions():
    sols = []
    for perm in permutations("FAMOSE"):
        d = {w: i for i, w in enumerate(perm)}
        if not d["F"] < d["A"]: continue
        if abs(d["M"] - d["O"]) != 1 or d["M"] > d["O"]: continue
        if d["E"] not in (0, 5) or d["S"] != 2 or d["A"] != 4: continue
        for tr in product("XYZ", repeat=6):
            if any(tr.count(x) != 2 for x in "XYZ"): continue
            if any(tr[i] == tr[i + 1] for i in range(5)): continue
            t = {w: tr[i] for i, w in enumerate(perm)}
            if t["F"] != "X" or t["S"] != "Y" or t["E"] == "Z": continue
            sols.append((perm, tr))
    return sols

# ---------- Set 5: electives ----------
def electives():
    F, M, O, all3, two, FM, MO, N = 110, 90, 70, 15, 50, 20, 12, 200
    FO = two - FM - MO
    onlyF = F - FM - FO - all3; onlyM = M - FM - MO - all3; onlyO = O - FO - MO - all3
    one = onlyF + onlyM + onlyO
    none = N - one - two - all3
    return dict(FO=FO, onlyF=onlyF, onlyM=onlyM, onlyO=onlyO, one=one, none=none, two=two, all3=all3, O=O)

SETS = [
    {"title": "Set 1",
     "intro": ["Seven friends, P, Q, R, S, T, U and V, sit in a row of seven seats numbered 1 to 7 from left to right, all facing the same direction. The following is known:",
               "1. Q sits in one of the two end seats.",
               "2. Exactly two people sit between Q and S.",
               "3. R sits immediately to the right of T.",
               "4. U does not sit next to S.",
               "5. P sits somewhere to the right of V, but not next to V.",
               "6. Neither V nor T sits in an end seat."],
     "questions": [
        {"q": "Who sits in seat 4?", "opts": ["V", "S", "P", "U"], "ans": 1,
         "sol": "Q is in seat 1 or seat 7. Either way, exactly two people between Q and S puts S in seat 4. No further work is needed."},
        {"q": "How many different seating arrangements satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "First rule out Q = 7. Then S = 4 and T–R (T not in seat 1) sits in 2–3 or 5–6. With 2–3, V must be in 5 or 6 and P at least two seats to its right: impossible. With 5–6, V is in 2 or 3 and again P has no seat far enough right. So Q = 1, S = 4. The pair T–R fits in seats 2–3, 5–6 or 6–7. Seats 2–3: then V, U, P fill 5, 6, 7; U not next to S rules out U in 5, and P must be right of V with a gap, giving Q T R S V U P. Seats 5–6: V, U, P fill 2, 3, 7 with U not in 3 and V not in 7, giving Q U V S T R P. Seats 6–7: V, U, P fill 2, 3, 5, giving Q U V S P T R. That makes 3 arrangements."},
        {"q": "Which of the following must be true?",
         "opts": ["V sits in seat 3.", "U sits in seat 2.", "Q sits in seat 1.", "P sits in seat 7."], "ans": 2,
         "sol": "The three arrangements are QTRSVUP, QUVSTRP and QUVSPTR. Only 'Q sits in seat 1' holds in all three."},
        {"q": "If R sits in an end seat, who sits in seat 5?", "opts": ["P", "T", "V", "U"], "ans": 0,
         "sol": "Only QUVSPTR has R at an end (seat 7). Seat 5 is P."},
     ]},
    {"title": "Set 2",
     "intro": ["Five teams, A, B, C, D and E, played a football tournament in which every team played every other team exactly once. A win earned 3 points, a draw 1 point to each team and a loss 0 points. The following is known about the final standings:",
               "1. All five teams finished with different points totals, and the final order from top to bottom was A, B, C, D, E.",
               "2. A finished with 10 points.",
               "3. Exactly three matches in the tournament ended in a draw.",
               "4. E did not win a match but drew exactly one.",
               "5. D won exactly one match.",
               "6. A's only draw was against the team that finished last."],
     "questions": [
        {"q": "What was the result of the match between C and D?", "opts": ["C won", "D won", "It was a draw", "Cannot be determined"], "ans": 2,
         "sol": "A has 10 points from 4 matches: 3 wins and 1 draw, the draw against E (clue 6). So E's only draw is with A, and E lost to B, C and D. D's one win is therefore against E. That leaves B–C, B–D and C–D with two draws among them, and D cannot win its remaining match. So far B, C and D have 3 points each. Draws in B–C and B–D with C beating D gives C 7, B 5: C above B, not allowed. Draws in B–D and C–D puts D level with or above one of B or C: not allowed. Only draws in B–C and C–D with B beating D works: A 10, B 7, C 5, D 4, E 1. C vs D was a draw."},
        {"q": "How many points did C finish with?", "tita": True, "ans": "5",
         "sol": "From the full results above: C lost to A, drew with B and D, and beat E: 0 + 1 + 1 + 3 = 5."},
        {"q": "Against which team or teams did B lose?", "opts": ["A only", "A and C", "C only", "B did not lose any match"], "ans": 0,
         "sol": "B lost to A, drew with C and beat D and E, finishing with 7 points."},
        {"q": "How many matches did C win?", "opts": ["0", "1", "2", "3"], "ans": 1,
         "sol": "C's only win was against E."},
     ]},
    {"title": "Set 3",
     "intro": ["A bookshop chain has five branches. The table shows the number of books each branch sold in 2025 in three categories. Every fiction book sold for ₹350, every exam-preparation book for ₹500 and every children's book for ₹200."],
     "table": {"head": ["Branch", "Fiction", "Exam preparation", "Children's"],
               "rows": [[b, *map(str, UNITS[b])] for b in UNITS]},
     "questions": [
        {"q": "Which branch earned the highest total revenue from these three categories?", "opts": ["North", "South", "West", "Central"], "ans": 2,
         "sol": "Revenues: North ₹4,88,000, South ₹5,41,000, East ₹4,63,500, West ₹5,45,000, Central ₹4,83,000. West is highest, just ahead of South: its 820 exam-preparation books make up for low fiction sales."},
        {"q": "What percentage of the chain's exam-preparation books were sold by the West branch? Give your answer to the nearest whole number.", "tita": True, "ans": "26",
         "sol": "Total exam-preparation books = 610 + 720 + 450 + 820 + 540 = 3,140. West's share = 820 / 3,140 = 26.1%, which rounds to 26."},
        {"q": "In how many branches did children's books account for more than 10% of the branch's total revenue?", "opts": ["0", "1", "2", "3"], "ans": 2,
         "sol": "Children's revenue as a share of branch revenue: North 7.4%, South 8.9%, East 12.9%, West 5.5%, Central 10.8%. Only East and Central exceed 10%."},
        {"q": "What is the difference, in rupees, between the highest and the lowest total branch revenue?", "tita": True, "ans": "81500",
         "sol": "Highest is West at ₹5,45,000; lowest is East at ₹4,63,500. The difference is ₹81,500."},
        {"q": "Suppose the South branch had raised the price of exam-preparation books by 10% and, as a result, sold 10% fewer of them, with everything else unchanged. By how many rupees would South's total revenue have fallen?", "tita": True, "ans": "3600",
         "sol": "Exam-preparation revenue becomes 648 books × ₹550 = ₹3,56,400 instead of 720 × ₹500 = ₹3,60,000. A 10% rise and a 10% fall multiply to 0.99, a 1% drop: ₹3,600."},
     ]},
    {"title": "Set 4",
     "intro": ["A business school runs six one-day workshops, Analytics, Ethics, Finance, Marketing, Operations and Strategy, on six consecutive days from Monday to Saturday, one workshop per day. Three trainers, X, Y and Z, conduct exactly two workshops each. The following is known:",
               "1. Strategy is on Wednesday and Analytics is on Friday.",
               "2. Finance is held on some day before Analytics.",
               "3. Marketing and Operations are on consecutive days, with Marketing first.",
               "4. Ethics is on either the first or the last day.",
               "5. No trainer conducts workshops on two consecutive days.",
               "6. X conducts Finance, Y conducts Strategy, and Z does not conduct Ethics."],
     "questions": [
        {"q": "Which workshop is held on Thursday?", "opts": ["Finance", "Ethics", "Operations", "Marketing"], "ans": 0,
         "sol": "Wednesday and Friday are taken, so the consecutive pair Marketing–Operations must be Monday–Tuesday. Ethics then takes Saturday (the first day is gone), leaving Thursday for Finance, which is before Friday's Analytics as required. Order: Marketing, Operations, Strategy, Finance, Analytics, Ethics."},
        {"q": "Who conducts Analytics?", "opts": ["X", "Y", "Z", "Cannot be determined"], "ans": 2,
         "sol": "Thursday (Finance) is X and Wednesday (Strategy) is Y, so Friday cannot be X. Suppose Friday were Y. Then Saturday's Ethics is not Y (consecutive) and not Z (clue 6), so it is X, and Z must take both Monday and Tuesday, which breaks clue 5. So Friday is Z."},
        {"q": "How many different complete schedules (workshop and trainer for every day) satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "Fixed: Wed Y, Thu X, Fri Z. X, Y and Z each have one more workshop, on Monday, Tuesday and Saturday. Tuesday cannot be Y (Wednesday is Y) and Saturday cannot be Z (Friday is Z, and clue 6). Of the six ways to assign them, three survive: (Mon, Tue, Sat) = (X, Z, Y), (Y, Z, X) and (Z, X, Y)."},
        {"q": "If Y conducts Marketing, who conducts Ethics?", "opts": ["X", "Y", "Z", "Cannot be determined"], "ans": 0,
         "sol": "Y on Monday leaves only the schedule (Y, Z, X) for Monday, Tuesday and Saturday, so X conducts Ethics on Saturday."},
     ]},
    {"title": "Set 5",
     "intro": ["In a batch of 200 MBA students, each student may choose any of three electives: Finance, Marketing and Operations. Some students choose none. The following is known:",
               "1. 110 students chose Finance, 90 chose Marketing and 70 chose Operations.",
               "2. 15 students chose all three electives.",
               "3. 50 students chose exactly two electives.",
               "4. 20 students chose Finance and Marketing but not Operations.",
               "5. 12 students chose Marketing and Operations but not Finance."],
     "questions": [
        {"q": "How many students chose none of the three electives?", "tita": True, "ans": "10",
         "sol": "Finance and Operations only = 50 − 20 − 12 = 18. Only Finance = 110 − 20 − 18 − 15 = 57; only Marketing = 90 − 20 − 12 − 15 = 43; only Operations = 70 − 18 − 12 − 15 = 25. Students with at least one elective = 57 + 43 + 25 + 50 + 15 = 190, so 10 chose none."},
        {"q": "How many students chose exactly one elective?", "opts": ["115", "120", "125", "135"], "ans": 2,
         "sol": "57 + 43 + 25 = 125."},
        {"q": "How many students chose Finance but not Marketing?", "tita": True, "ans": "75",
         "sol": "Only Finance (57) plus Finance and Operations only (18) = 75."},
        {"q": "Approximately what percentage of the students who chose Operations also chose at least one other elective?", "opts": ["36%", "45%", "64%", "71%"], "ans": 2,
         "sol": "Operations students with another elective = 18 + 12 + 15 = 45, out of 70: 64.3%."},
        {"q": "If 5 of the students who chose only Marketing also added Operations, how many students would then have exactly two electives?", "opts": ["45", "50", "55", "60"], "ans": 2,
         "sol": "Each of those 5 students moves from 'exactly one' to 'exactly two': 50 + 5 = 55."},
     ]},
]


def verify():
    s1 = seating_solutions()
    assert sorted(s1) == sorted(["QTRSVUP", "QUVSTRP", "QUVSPTR"]), s1
    assert all(s[3] == "S" for s in s1)
    assert str(len(s1)) == SETS[0]["questions"][1]["ans"]
    assert all(s[0] == "Q" for s in s1) and not all(s[2] == "V" for s in s1) and not all(s[1] == "U" for s in s1) and not all(s[6] == "P" for s in s1)
    r_end = [s for s in s1 if s[0] == "R" or s[6] == "R"]
    assert len(r_end) == 1 and r_end[0][4] == "P"

    s2 = tournament_solutions()
    assert len(s2) == 1, len(s2)
    out = s2[0]; pts, w, d = tally(out)
    assert result(out, "C", "D") == "draw"
    assert pts["C"] == 5 and w["C"] == 1
    assert [t for t in TEAMS if t != "B" and result(out, *sorted(("B", t))) == t] == ["A"]

    rev = {b: revenue(b) for b in UNITS}
    assert max(rev, key=rev.get) == "West"
    exam = sum(u[1] for u in UNITS.values())
    assert round(UNITS["West"][1] / exam * 100) == 26
    assert sum(1 for b in UNITS if UNITS[b][2] * 200 / rev[b] > 0.10) == 2
    assert max(rev.values()) - min(rev.values()) == 81500
    assert UNITS["South"][1] * 500 - Fraction(UNITS["South"][1] * 9, 10) * 550 == 3600

    s4 = schedule_solutions()
    assert len(s4) == 3
    assert all(p[3] == "F" for p, _ in s4)
    assert all(tr[p.index("A")] == "Z" for p, tr in s4)
    ym = [(p, tr) for p, tr in s4 if tr[p.index("M")] == "Y"]
    assert len(ym) == 1 and ym[0][1][ym[0][0].index("E")] == "X"

    e = electives()
    assert e["none"] == 10 and e["one"] == 125 and e["onlyF"] + e["FO"] == 75
    assert round((e["FO"] + 12 + e["all3"]) / e["O"] * 100) == 64
    assert e["two"] + 5 == 55
    return "DILR: all 22 keys match the solvers"
