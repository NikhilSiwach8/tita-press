"""QA section: 22 questions. Each item's check() recomputes the answer from scratch."""
from fractions import Fraction as Fr
from itertools import combinations
from math import comb, isclose


def n_divisors(n):
    return sum(1 for d in range(1, n + 1) if n % d == 0)


QA = [
    {"q": "A 40-litre mixture contains milk and water in the ratio 3 : 1. How many litres of water must be added to make the ratio 3 : 2?",
     "opts": ["5", "10", "15", "20"], "ans": 1,
     "check": lambda: (Fr(30, 3) * 2 - 10) == 10,
     "sol": "Milk = 30 L and water = 10 L. For 3 : 2, water must be 30 × 2/3 = 20 L, so add 10 L."},
    {"q": "A car travels from P to Q at 60 km/h and returns along the same road at 40 km/h. What is its average speed for the whole journey, in km/h?",
     "opts": ["45", "48", "50", "52"], "ans": 1,
     "check": lambda: Fr(2 * 60 * 40, 60 + 40) == 48,
     "sol": "For equal distances, average speed = 2ab/(a + b) = 2 × 60 × 40 / 100 = 48 km/h. The simple average, 50, is the trap."},
    {"q": "12 workers can finish a job in 15 days. They work together for 5 days, after which 4 workers leave. In how many more days will the remaining workers finish the job?",
     "tita": True, "ans": "15",
     "check": lambda: Fr(12 * 15 - 12 * 5, 8) == 15,
     "sol": "The job is 12 × 15 = 180 worker-days. After 5 days, 60 are done and 120 remain. 8 workers need 120 / 8 = 15 days."},
    {"q": "The difference between the compound interest and the simple interest on a sum of money for 2 years at 10% per annum is ₹150. What is the sum, in rupees?",
     "tita": True, "ans": "15000",
     "check": lambda: isclose(15000 * (1.1 ** 2 - 1) - 15000 * 0.2, 150),
     "sol": "For 2 years, CI − SI = P × r² = P × 0.01. So P = 150 / 0.01 = ₹15,000."},
    {"q": "The incomes of A and B are in the ratio 5 : 4 and their expenses in the ratio 3 : 2. If each of them saves ₹2,000 a month, what is A's monthly income, in rupees?",
     "opts": ["4,000", "5,000", "6,000", "8,000"], "ans": 1,
     "check": lambda: (5 * 1000 - 3 * 1000 == 2000) and (4 * 1000 - 2 * 1000 == 2000),
     "sol": "Let incomes be 5x and 4x, expenses 3y and 2y. Then 5x − 3y = 2000 and 4x − 2y = 2000. From the second, y = 2x − 1000; substituting, 5x − 6x + 3000 = 2000, so x = 1000. A's income = ₹5,000."},
    {"q": "The ratio of the present ages of A and B is 3 : 5. After 6 years the ratio will be 2 : 3. What is B's present age, in years?",
     "tita": True, "ans": "30",
     "check": lambda: Fr(18 + 6, 30 + 6) == Fr(2, 3) and Fr(18, 30) == Fr(3, 5),
     "sol": "(3k + 6)/(5k + 6) = 2/3 gives 9k + 18 = 10k + 12, so k = 6 and B is 5 × 6 = 30."},
    {"q": "The price of sugar rises by 25%. By what percentage must a family reduce its consumption so that its spending on sugar stays the same?",
     "opts": ["20%", "25%", "15%", "30%"], "ans": 0,
     "check": lambda: Fr(1) - Fr(1) / Fr(5, 4) == Fr(1, 5),
     "sol": "New consumption = 1 / 1.25 = 0.8 of the old, a 20% cut."},
    {"q": "The roots of x² − 7x + k = 0 differ by 3. What is the value of k?",
     "tita": True, "ans": "10",
     "check": lambda: 5 + 2 == 7 and 5 - 2 == 3 and 5 * 2 == 10,
     "sol": "The roots add to 7 and differ by 3, so they are 5 and 2. Their product is k = 10."},
    {"q": "If log₃x + log₉x + log₂₇x = 11, what is the value of x?",
     "tita": True, "ans": "729",
     "check": lambda: Fr(6) * (1 + Fr(1, 2) + Fr(1, 3)) == 11 and 3 ** 6 == 729,
     "sol": "log₉x = ½ log₃x and log₂₇x = ⅓ log₃x, so (11/6) log₃x = 11, log₃x = 6 and x = 3⁶ = 729."},
    {"q": "How many integers x satisfy x² − 5x − 14 < 0?",
     "opts": ["7", "8", "9", "10"], "ans": 1,
     "check": lambda: sum(1 for x in range(-50, 50) if x * x - 5 * x - 14 < 0) == 8,
     "sol": "x² − 5x − 14 = (x − 7)(x + 2) < 0 when −2 < x < 7, so x = −1, 0, 1, …, 6: eight integers."},
    {"q": "If f(x) = 2x + 3 and g(x) = x² − 1, what is f(g(2)) − g(f(1))?",
     "opts": ["−15", "−9", "9", "15"], "ans": 0,
     "check": lambda: (lambda f, g: f(g(2)) - g(f(1)))(lambda x: 2 * x + 3, lambda x: x * x - 1) == -15,
     "sol": "g(2) = 3, so f(g(2)) = 9. f(1) = 5, so g(f(1)) = 24. 9 − 24 = −15."},
    {"q": "The 3rd term of an arithmetic progression is 11 and its 8th term is 31. What is the sum of its first 10 terms?",
     "tita": True, "ans": "210",
     "check": lambda: sum(3 + 4 * i for i in range(10)) == 210 and 3 + 4 * 2 == 11 and 3 + 4 * 7 == 31,
     "sol": "5d = 31 − 11 = 20, so d = 4 and a = 11 − 8 = 3. S₁₀ = 10/2 × (2 × 3 + 9 × 4) = 5 × 42 = 210."},
    {"q": "What is the minimum value of |x − 2| + |x − 8| for real x?",
     "opts": ["0", "4", "6", "10"], "ans": 2,
     "check": lambda: min(abs(x / 10 - 2) + abs(x / 10 - 8) for x in range(-200, 200)) == 6,
     "sol": "For any x between 2 and 8, the sum is the distance between 2 and 8, which is 6. Outside that range it is larger."},
    {"q": "A right-angled triangle has legs of 6 cm and 8 cm. What is the radius of its inscribed circle, in cm?",
     "opts": ["1.5", "2", "2.5", "3"], "ans": 1,
     "check": lambda: Fr(6 + 8 - 10, 2) == 2 and Fr(2 * 24, 6 + 8 + 10) == 2,
     "sol": "The hypotenuse is 10. For a right triangle, r = (a + b − c)/2 = (6 + 8 − 10)/2 = 2. Check: area/semi-perimeter = 24/12 = 2."},
    {"q": "A chord of length 16 cm is at a distance of 6 cm from the centre of a circle. What is the radius of the circle, in cm?",
     "tita": True, "ans": "10",
     "check": lambda: 8 ** 2 + 6 ** 2 == 10 ** 2,
     "sol": "The perpendicular from the centre bisects the chord, giving a right triangle with legs 8 and 6. Radius = √(64 + 36) = 10."},
    {"q": "A solid metal cube of edge 6 cm is melted and recast into small cubes of edge 2 cm each. How many small cubes are made?",
     "opts": ["9", "18", "27", "36"], "ans": 2,
     "check": lambda: 6 ** 3 // 2 ** 3 == 27,
     "sol": "Volume ratio = 6³ / 2³ = 216 / 8 = 27."},
    {"q": "A shopkeeper marks an item 40% above its cost price and then gives two successive discounts of 10% each. What is the profit percentage?",
     "tita": True, "ans": "13.4",
     "check": lambda: Fr(14, 10) * Fr(9, 10) * Fr(9, 10) == Fr(1134, 1000),
     "sol": "Selling price = 1.4 × 0.9 × 0.9 = 1.134 times cost, a profit of 13.4%. Two 10% discounts are a 19% discount, not 20%."},
    {"q": "What is the area of the triangle with vertices (0, 0), (6, 0) and (2, 5)?",
     "opts": ["12", "15", "18", "30"], "ans": 1,
     "check": lambda: abs(0 * (0 - 5) + 6 * (5 - 0) + 2 * (0 - 0)) / 2 == 15,
     "sol": "The base along the x-axis is 6 and the height is 5, so the area is ½ × 6 × 5 = 15."},
    {"q": "What is the remainder when 2¹⁰⁰ is divided by 7?",
     "opts": ["1", "2", "4", "6"], "ans": 1,
     "check": lambda: pow(2, 100, 7) == 2,
     "sol": "2³ = 8 leaves remainder 1, so 2⁹⁹ = (2³)³³ leaves 1 and 2¹⁰⁰ leaves 2."},
    {"q": "How many positive divisors does 360 have?",
     "opts": ["18", "20", "24", "30"], "ans": 2,
     "check": lambda: n_divisors(360) == 24,
     "sol": "360 = 2³ × 3² × 5, so it has (3 + 1)(2 + 1)(1 + 1) = 24 divisors."},
    {"q": "A committee of 3 is to be chosen from 5 men and 4 women. In how many ways can this be done if the committee must include at least one woman?",
     "tita": True, "ans": "74",
     "check": lambda: sum(1 for c in combinations(range(9), 3) if any(i >= 5 for i in c)) == 74,
     "sol": "All committees: C(9, 3) = 84. All-men committees: C(5, 3) = 10. At least one woman: 84 − 10 = 74."},
    {"q": "Two fair dice are rolled. What is the probability that the sum of the numbers shown is 8?",
     "opts": ["1/6", "5/36", "1/9", "7/36"], "ans": 1,
     "check": lambda: Fr(sum(1 for a in range(1, 7) for b in range(1, 7) if a + b == 8), 36) == Fr(5, 36),
     "sol": "The favourable outcomes are (2, 6), (3, 5), (4, 4), (5, 3) and (6, 2): 5 out of 36."},
]

# The storefront's sample question is labelled 'QA · Q.17 of 22'
assert QA[16]["ans"] == "13.4"


def verify():
    for i, item in enumerate(QA, 1):
        assert item["check"](), f"QA {i} failed its check"
    return f"QA: all {len(QA)} checks pass"
