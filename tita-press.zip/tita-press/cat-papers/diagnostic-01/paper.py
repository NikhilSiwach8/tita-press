NAME = "Diagnostic Mock 01"
LEDE = "A full-length paper to find your starting score and weakest section. Sit it in one go, in section order, with a timer running. Answer key, worked solutions and a scoring table are in the separate solutions booklet."
SEED = 2026
