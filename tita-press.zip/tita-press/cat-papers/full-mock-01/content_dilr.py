"""Full Mock 01 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import permutations, product

# ---------- Set 1: test scores ----------
STUDENTS = "ABCDE"

def score_solutions():
    perms = list(permutations((6, 7, 8, 9, 10)))
    sols = []
    for t1 in perms:
        a1 = dict(zip(STUDENTS, t1))
        for t2 in perms:
            a2 = dict(zip(STUDENTS, t2))
            if a2["D"] != a1["A"]: continue
            for t3 in perms:
                a3 = dict(zip(STUDENTS, t3))
                if not a1["C"] < a2["C"] < a3["C"]: continue
                if a3["E"] != 6: continue
                tot = {s: a1[s] + a2[s] + a3[s] for s in STUDENTS}
                if len(set(tot.values())) < 5: continue
                if max(tot, key=tot.get) != "A" or min(tot, key=tot.get) != "D": continue
                if [a1["B"], a2["B"], a3["B"]].count(10) != 1: continue
                if tot["E"] != 24: continue
                sols.append((a1, a2, a3, tot))
    return sols

# ---------- Set 2: knockout ----------
QF = [(1, 8), (4, 5), (3, 6), (2, 7)]

def knockout_solutions():
    sols = []
    for w in product((0, 1), repeat=7):
        for sets in product((2, 3), repeat=7):
            ms, win = [], []
            for i, m in enumerate(QF):
                ms.append(m); win.append(m[w[i]])
            for j, m in enumerate([(win[0], win[1]), (win[2], win[3])]):
                ms.append(m); win.append(m[w[4 + j]])
            f = (win[4], win[5]); ms.append(f); win.append(f[w[6]])
            champ = win[6]
            if sum(1 for m, x in zip(ms, win) if x == max(m)) != 3: continue
            if win[0] != 1 or 1 in ms[6]: continue
            if sum(sets) != 17 or sets[6] != 3: continue
            if sum(1 for i, m in enumerate(ms) if champ in m and sets[i] == 3) != 1: continue
            if any(sets[i] != 3 for i, m in enumerate(ms) if 5 in m): continue
            sols.append((ms, win, sets))
    return sols

# ---------- Set 3: admissions table ----------
FULL = {"P": (2400, 480, 120, 42), "Q": (1800, 450, 90, 36), "R": (3000, 540, 135, 54), "S": (1500, 300, 105, 35)}

def admissions_from_clues():
    """Fill the hidden cells using only the clues given in the set."""
    t = {k: list(v) for k, v in FULL.items()}
    t["Q"][0] = None; t["R"][1] = None; t["S"][2] = None; t["P"][3] = None
    t["Q"][0] = t["Q"][1] * 100 // 25          # clue 1
    t["R"][1] = t["R"][0] * 18 // 100          # clue 2
    t["S"][2] = t["P"][2] - 15                 # clue 3
    t["P"][3] = t["Q"][3] + 6                  # clue 4
    assert sum(v[2] for v in t.values()) == 450  # clue 5 is consistent
    return {k: tuple(v) for k, v in t.items()}

# ---------- Set 4: round table ----------
DEPTS = ["Finance", "HR", "IT", "Legal", "Marketing", "Sales"]
def nxt(s): return s % 6 + 1
def opp(s): return (s + 2) % 6 + 1
def adj(a, b): return nxt(a) == b or nxt(b) == a

def table_solutions():
    sols = []
    for rest in permutations("BCDEF"):
        seat = {"A": 1, **{p: i + 2 for i, p in enumerate(rest)}}
        for deps in permutations(DEPTS):
            d = dict(zip("ABCDEF", deps)); who = {v: k for k, v in d.items()}
            if seat[who["Finance"]] != opp(1): continue
            if seat["B"] != nxt(seat[who["IT"]]): continue
            if not adj(seat["C"], seat["D"]): continue
            h = seat[who["HR"]]
            if not (adj(h, 1) and adj(h, seat["E"])): continue
            if adj(seat["F"], 1): continue
            if who["Legal"] == "A" or seat[who["Legal"]] % 2 == 0: continue
            if "Marketing" in (d["C"], d["F"]) or d["E"] == "IT": continue
            if seat[who["Marketing"]] != nxt(seat[who["Legal"]]): continue
            sols.append((seat, d))
    return sols

# ---------- Set 5: roads ----------
ROADS = {("A", "B"): 4, ("A", "C"): 6, ("B", "C"): 3, ("B", "D"): 7, ("C", "D"): 4,
         ("C", "E"): 8, ("D", "E"): 2, ("D", "F"): 6, ("E", "F"): 3, ("B", "E"): 9}

def routes(roads, s="A", t="F"):
    g = {}
    for (a, b), w in roads.items():
        g.setdefault(a, []).append((b, w)); g.setdefault(b, []).append((a, w))
    out = []
    def walk(u, seen, dist, path):
        if u == t: out.append((dist, path)); return
        for v, w in g[u]:
            if v not in seen: walk(v, seen | {v}, dist + w, path + [v])
    walk(s, {s}, 0, [s])
    return sorted(out)

def shortest(roads): return routes(roads)[0][0]

def without(*keys): return {k: v for k, v in ROADS.items() if k not in keys}

def min_network(roads):
    parent = {}
    def find(x):
        while parent.get(x, x) != x: x = parent[x]
        return x
    total = 0
    for (a, b), w in sorted(roads.items(), key=lambda kv: kv[1]):
        if find(a) != find(b): parent[find(a)] = find(b); total += w
    return total


SETS = [
    {"title": "Set 1",
     "intro": ["Five students, A, B, C, D and E, took three tests. In each test the five students scored 6, 7, 8, 9 and 10 marks in some order, so no two students had the same score in any test. A student's total is the sum of their three scores. The following is known:",
               "1. No two students had the same total. A had the highest total and D the lowest.",
               "2. E's total was 24, and E scored 6 in Test 3.",
               "3. C's score went up from Test 1 to Test 2 and again from Test 2 to Test 3.",
               "4. B scored 10 in exactly one of the three tests.",
               "5. D's score in Test 2 was the same as A's score in Test 1."],
     "questions": [
        {"q": "What was A's score in Test 3?", "opts": ["7", "8", "9", "10"], "ans": 1,
         "sol": "Each test hands out 40 marks, so the five totals add up to 120. E has 24; the other four totals are distinct, with A highest and D lowest. E's Test 1 and Test 2 scores add to 18: (8, 10), (9, 9) or (10, 8). Test 3 gives A, B, C, D the scores 7–10, and C rises every test, so C's Test 3 score is at least 8. Working through E's three options with clues 4 and 5 leaves one table: Test 1 A 8, B 10, C 6, D 7, E 9; Test 2 A 10, B 6, C 7, D 8, E 9; Test 3 A 8, B 9, C 10, D 7, E 6. Totals: A 26, B 25, E 24, C 23, D 22. A scored 8 in Test 3."},
        {"q": "Who scored 10 in Test 3?", "opts": ["A", "B", "C", "D"], "ans": 2,
         "sol": "From the table, C scored 6, 7 and 10."},
        {"q": "What was C's total?", "tita": True, "ans": "23",
         "sol": "6 + 7 + 10 = 23."},
        {"q": "In how many of the three tests did E score more than D?", "opts": ["0", "1", "2", "3"], "ans": 2,
         "sol": "Test 1: E 9, D 7. Test 2: E 9, D 8. Test 3: E 6, D 7. E was ahead in two tests."},
     ]},
    {"title": "Set 2",
     "intro": ["Eight players, seeded 1 (strongest) to 8, played a knockout tennis tournament. Quarter-finals: 1 v 8, 4 v 5, 3 v 6 and 2 v 7. Semi-finals: the winner of 1 v 8 against the winner of 4 v 5, and the winner of 3 v 6 against the winner of 2 v 7. The two semi-final winners played the final. Every match was best of three sets, so it lasted either 2 or 3 sets. A match is an upset if the higher-numbered seed won it. The following is known:",
               "1. Exactly three of the seven matches were upsets.",
               "2. Seed 1 won its quarter-final but did not reach the final.",
               "3. A total of 17 sets were played in the tournament.",
               "4. The final went to 3 sets. The champion played 3 sets in exactly one of their matches.",
               "5. Every match that seed 5 played went to 3 sets."],
     "questions": [
        {"q": "Who was the runner-up?", "opts": ["Seed 3", "Seed 4", "Seed 2", "Seed 5"], "ans": 3,
         "sol": "Seven matches with 17 sets means exactly three went to 3 sets. Suppose seed 5 lost to seed 4. Then 4 beat 1 and reached the final, and the champion came from the bottom half. Checking each possible champion (2, 3, 6, 7) gives either fewer or more than three upsets, so this is impossible. So 5 beat 4. In the semi-final 5 met 1, and if 1 had won, 1 would have reached the final; so 5 beat 1 and reached the final. All three of 5's matches went to 3 sets, so those are the only 3-set matches. If 5 had won the final, the champion would have played three 3-set matches, breaking clue 4. So seed 5 lost the final."},
        {"q": "How many of the seven matches lasted exactly 2 sets?", "tita": True, "ans": "4",
         "sol": "The three 3-set matches are all seed 5's (quarter-final, semi-final, final). The other four matches lasted 2 sets."},
        {"q": "How many different players could have been the champion?", "tita": True, "ans": "2",
         "sol": "5's wins over 4 and 1 are two upsets, so the bottom half and the final contain exactly one more. A champion seeded 6 or 7 would create at least two (their quarter-final and the final). Champion 3: beat 6, then either beat 2 (upset) or beat 7 after 7 upset 2: one upset either way. Champion 2: beat 7, then beat 6 after 6 upset 3: one upset. (Beating 3 instead gives none.) So the champion was seed 2 or seed 3."},
        {"q": "If seed 7 won its quarter-final, who won the tournament?", "opts": ["Seed 2", "Seed 3", "Seed 6", "Seed 7"], "ans": 1,
         "sol": "Of the three possible tournaments, the only one in which 7 beat 2 has seed 3 beating 6, then 7, then 5 in the final."},
        {"q": "Which players certainly lost in the quarter-finals?", "opts": ["Seeds 4 and 8 only", "Seeds 4, 6 and 8", "Seeds 4, 7 and 8", "Seeds 6 and 7 only"], "ans": 0,
         "sol": "Seed 1 beat 8 and seed 5 beat 4 in every case. Seeds 6 and 7 each win their quarter-final in one of the three possible tournaments, so neither is certain to have lost."},
     ]},
    {"title": "Set 3",
     "intro": ["The table gives admissions data for an MBA programme at four colleges, P, Q, R and S. Some entries are missing and are marked with a dash.",
               "1. Q shortlisted 25% of its applicants.",
               "2. R shortlisted 18% of its applicants.",
               "3. S admitted 15 fewer candidates than P.",
               "4. P admitted 6 more women than Q.",
               "5. The four colleges together admitted 450 candidates."],
     "table": {"head": ["College", "Applicants", "Shortlisted", "Admitted", "Women admitted"],
               "rows": [["P", "2,400", "480", "120", "–"], ["Q", "–", "450", "90", "36"],
                        ["R", "3,000", "–", "135", "54"], ["S", "1,500", "300", "–", "35"]]},
     "questions": [
        {"q": "Which college admitted the highest percentage of its applicants?", "opts": ["P", "Q", "R", "S"], "ans": 3,
         "sol": "Filling the gaps: Q applicants = 450 / 0.25 = 1,800; R shortlisted = 18% of 3,000 = 540; S admitted = 120 − 15 = 105; P women = 36 + 6 = 42. Admitted ÷ applicants: P 5%, Q 5%, R 4.5%, S 7%. S is highest."},
        {"q": "What percentage of all shortlisted candidates across the four colleges were admitted? Give your answer to the nearest whole number.", "tita": True, "ans": "25",
         "sol": "Shortlisted: 480 + 450 + 540 + 300 = 1,770. Admitted: 450. 450 / 1,770 = 25.4%, which rounds to 25."},
        {"q": "Women made up approximately what percentage of all candidates admitted by the four colleges?", "opts": ["33%", "35%", "37%", "39%"], "ans": 2,
         "sol": "Women admitted: 42 + 36 + 54 + 35 = 167, out of 450: 37.1%."},
        {"q": "In how many colleges did more than 25% of shortlisted candidates get admitted?", "opts": ["0", "1", "2", "3"], "ans": 1,
         "sol": "Admitted ÷ shortlisted: P 120/480 = 25%, Q 90/450 = 20%, R 135/540 = 25%, S 105/300 = 35%. P and R are exactly 25%, not more, so only S qualifies."},
        {"q": "Next year R expects 20% more applicants. If its shortlisting and admission rates stay the same, how many candidates will R admit?", "tita": True, "ans": "162",
         "sol": "With unchanged rates, admissions scale with applicants: 135 × 1.2 = 162."},
     ]},
    {"title": "Set 4",
     "intro": ["Six colleagues, A, B, C, D, E and F, sit around a round table with six seats numbered 1 to 6 clockwise. Each works in a different department: Finance, HR, IT, Legal, Marketing or Sales. 'Next clockwise' to a seat means the seat with the next number (seat 1 is next clockwise to seat 6). Seats 1 and 4, 2 and 5, and 3 and 6 are directly opposite each other. The following is known:",
               "1. A sits in seat 1, and the Finance colleague sits directly opposite A.",
               "2. B sits next clockwise to the IT colleague.",
               "3. C and D sit next to each other.",
               "4. The HR colleague sits next to both A and E.",
               "5. F does not sit next to A.",
               "6. The Legal colleague is not A and sits in an odd-numbered seat.",
               "7. Neither C nor F works in Marketing, and E does not work in IT.",
               "8. The Marketing colleague sits next clockwise to the Legal colleague."],
     "questions": [
        {"q": "Who works in Legal?", "opts": ["E", "C", "D", "B"], "ans": 1,
         "sol": "F is not next to A, so F is in seat 3, 4 or 5. HR is in seat 2 or 6 with E beside it. Legal is in seat 3 or 5, with Marketing in the next seat clockwise (4 or 6). Seat 4 is Finance, so Legal is seat 5 and Marketing is seat 6. Testing HR in seat 2 and in seat 6 against clues 2, 3 and 7 leaves one arrangement: 1 A (IT), 2 B (HR), 3 E (Sales), 4 F (Finance), 5 C (Legal), 6 D (Marketing). C works in Legal."},
        {"q": "Who sits directly opposite E?", "opts": ["A", "B", "C", "D"], "ans": 3,
         "sol": "E is in seat 3; the seat opposite is 6, which is D."},
        {"q": "In which department does E work?", "opts": ["Sales", "HR", "Marketing", "Finance"], "ans": 0,
         "sol": "From the arrangement, E (seat 3) works in Sales."},
        {"q": "Going clockwise from A to C, how many people sit between them?", "tita": True, "ans": "3",
         "sol": "Clockwise from seat 1 to seat 5 you pass seats 2, 3 and 4: B, E and F."},
     ]},
    {"title": "Set 5",
     "intro": ["Six towns, A to F, are linked by two-way roads. The table lists every road and its length in kilometres. A route may not pass through the same town twice."],
     "table": {"head": ["Road", "Length (km)", "Road", "Length (km)"],
               "rows": [["A–B", "4", "C–D", "4"], ["A–C", "6", "C–E", "8"], ["B–C", "3", "D–E", "2"],
                        ["B–D", "7", "D–F", "6"], ["B–E", "9", "E–F", "3"]]},
     "questions": [
        {"q": "What is the length, in km, of the shortest route from A to F?", "tita": True, "ans": "15",
         "sol": "A–C–D–E–F = 6 + 4 + 2 + 3 = 15. The next best routes are 16 km, for example A–B–C–D–E–F or A–B–E–F."},
        {"q": "Closing which one of the following roads would NOT change the length of the shortest route from A to F?", "opts": ["A–C", "C–D", "D–E", "B–C"], "ans": 3,
         "sol": "The 15 km route uses A–C, C–D, D–E and E–F, so closing any of these pushes the shortest distance to 16 km. B–C is not on that route, so closing it leaves the shortest distance at 15 km."},
        {"q": "If road C–D is closed, how many different routes from A to F have the shortest possible length?", "tita": True, "ans": "2",
         "sol": "Without C–D, the shortest length is 16 km, achieved by A–B–E–F (4 + 9 + 3) and A–B–D–E–F (4 + 7 + 2 + 3). Every other route is longer."},
        {"q": "The council wants to keep as few kilometres of road as possible while making sure every town can still be reached from every other town. What is the minimum total length of road it must keep?", "opts": ["16", "17", "18", "19"], "ans": 0,
         "sol": "Keep the shortest roads that do not form a loop: D–E 2, B–C 3, E–F 3, A–B 4, C–D 4. These connect all six towns with 2 + 3 + 3 + 4 + 4 = 16 km."},
     ]},
]


def verify():
    s1 = score_solutions()
    assert len(s1) == 1
    a1, a2, a3, tot = s1[0]
    assert a3["A"] == 8 and max(a3, key=a3.get) == "C" and tot["C"] == 23
    assert sum(1 for t in (a1, a2, a3) if t["E"] > t["D"]) == 2

    s2 = knockout_solutions()
    assert len(s2) == 3
    assert all(set(ms[6]) - {win[6]} == {5} for ms, win, _ in s2)
    assert all(sum(1 for s in sets if s == 2) == 4 for *_, sets in s2)
    assert {win[6] for _, win, _ in s2} == {2, 3}
    seven = [win for _, win, _ in s2 if win[3] == 7]
    assert len(seven) == 1 and seven[0][6] == 3
    qf_losers = [set(m) - {win[i]} for ms, win, _ in s2 for i, m in enumerate(ms[:4])]
    always = {p for p in range(1, 9) if all(any(p in l for l in [set(m) - {win[i]} for i, m in enumerate(ms[:4])]) for ms, win, _ in s2)}
    assert always == {4, 8}, always

    t = admissions_from_clues()
    assert t == FULL
    rate = {k: v[2] / v[0] for k, v in t.items()}
    assert max(rate, key=rate.get) == "S"
    assert round(450 / sum(v[1] for v in t.values()) * 100) == 25
    assert round(sum(v[3] for v in t.values()) / 450 * 100) == 37
    assert sum(1 for v in t.values() if v[2] / v[1] > 0.25) == 1
    assert t["R"][2] * 6 // 5 == 162

    s4 = table_solutions()
    assert len(s4) == 1
    seat, d = s4[0]
    by_seat = {v: k for k, v in seat.items()}
    assert {v: k for k, v in d.items()}["Legal"] == "C"
    assert by_seat[opp(seat["E"])] == "D" and d["E"] == "Sales"
    assert (seat["C"] - seat["A"]) % 6 - 1 == 3

    assert shortest(ROADS) == 15
    assert [shortest(without(k)) for k in [("A", "C"), ("C", "D"), ("D", "E"), ("B", "C")]] == [16, 16, 16, 15]
    r = routes(without(("C", "D")))
    assert sum(1 for dist, _ in r if dist == r[0][0]) == 2 and r[0][0] == 16
    assert min_network(ROADS) == 16
    return "DILR: all 22 keys match the solvers"
