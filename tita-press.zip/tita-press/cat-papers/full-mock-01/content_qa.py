"""Full Mock 01 QA: 22 questions at CAT difficulty. Each item's check() recomputes the answer from scratch."""
from fractions import Fraction as Fr
from itertools import combinations, permutations
from math import comb, factorial, isclose, sqrt


def power_in_factorial(n, p):
    k, q = 0, p
    while q <= n:
        k += n // q; q *= p
    return k


def alternate_days():
    done, day = Fr(0), 0
    while done < 1:
        day += 1
        done += Fr(1, 20) if day % 2 else Fr(1, 30)
    return day


def best_product():
    best = 0
    for x10 in range(1, 120):
        for y10 in range(1, 120 - x10):
            x, y = x10 / 10, y10 / 10
            best = max(best, x * y * y * (12 - x - y))
    return best


QA = [
    {"q": "Two cars start at the same time from towns X and Y and drive towards each other. After they pass each other, the car from X takes 16 hours to reach Y and the car from Y takes 9 hours to reach X. If the car from X travels at 30 km/h, what is the distance between X and Y, in km?",
     "tita": True, "ans": "840",
     "check": lambda: (lambda vb: (lambda t: isclose((30 + vb) * t, 840) and isclose(vb * t / 30, 16))(vb * 9 / 30))(30 * sqrt(16 / 9)),
     "sol": "If they meet after t hours, each car's remaining distance is what the other covered in t hours. So 30t = 9v and vt = 16 × 30 = 480, where v is the speed of the car from Y. Substituting t = 9v/30 gives 9v²/30 = 480, so v² = 1600, v = 40 km/h and t = 12. Distance = (30 + 40) × 12 = 840 km."},
    {"q": "If x + 1/x = 3, what is the value of x⁵ + 1/x⁵?",
     "tita": True, "ans": "123",
     "check": lambda: (lambda x: isclose(x ** 5 + x ** -5, 123))((3 + sqrt(5)) / 2),
     "sol": "x² + 1/x² = 3² − 2 = 7 and x³ + 1/x³ = 3³ − 3 × 3 = 18. Then (x² + 1/x²)(x³ + 1/x³) = x⁵ + 1/x⁵ + x + 1/x, so x⁵ + 1/x⁵ = 7 × 18 − 3 = 123."},
    {"q": "What is the sum of all three-digit numbers that are divisible by 7 but not by 3?",
     "tita": True, "ans": "46858",
     "check": lambda: sum(n for n in range(100, 1000) if n % 7 == 0 and n % 3) == 46858,
     "sol": "Multiples of 7 from 105 to 994: 128 terms, sum 128 × (105 + 994)/2 = 70,336. Those also divisible by 3 are multiples of 21 from 105 to 987: 43 terms, sum 43 × (105 + 987)/2 = 23,478. Difference: 46,858."},
    {"q": "A vessel holds 80 litres of pure milk. 8 litres are drawn out and replaced with water. This is done three times in all. How many litres of milk are left in the vessel?",
     "opts": ["57.6", "58.32", "60.48", "56"], "ans": 1,
     "check": lambda: isclose(80 * (1 - 8 / 80) ** 3, 58.32),
     "sol": "Each round keeps 72/80 = 0.9 of the milk. After three rounds: 80 × 0.9³ = 58.32 litres. Subtracting 8 litres three times (giving 56) is the trap, since later rounds remove diluted mixture."},
    {"q": "A triangle has sides of 13 cm, 14 cm and 15 cm. What is the radius of its circumscribed circle, in cm?",
     "opts": ["7.5", "7.8", "8", "8.125"], "ans": 3,
     "check": lambda: (lambda s: Fr(13 * 14 * 15, 4 * 84) == Fr(65, 8) and s * (s - 13) * (s - 14) * (s - 15) == 84 ** 2)(21),
     "sol": "Semi-perimeter 21, so the area is √(21 × 8 × 7 × 6) = 84. R = abc / 4K = 13 × 14 × 15 / 336 = 65/8 = 8.125 cm."},
    {"q": "A function f satisfies f(x) + 2f(1/x) = 3x for every non-zero real x. What is f(2)?",
     "opts": ["−1", "1", "3/2", "2"], "ans": 0,
     "check": lambda: (lambda f: all(isclose(f(x) + 2 * f(1 / x), 3 * x) for x in (0.5, 2, 3, -7)) and f(2) == -1)(lambda x: 2 / x - x),
     "sol": "Put x = 2: f(2) + 2f(1/2) = 6. Put x = 1/2: f(1/2) + 2f(2) = 3/2. Doubling the second and subtracting the first: 3f(2) = 3 − 6, so f(2) = −1."},
    {"q": "A sum of money invested at compound interest grows to ₹13,310 in 3 years and to ₹14,641 in 4 years. What was the sum invested, in rupees?",
     "tita": True, "ans": "10000",
     "check": lambda: isclose(10000 * 1.1 ** 3, 13310) and isclose(10000 * 1.1 ** 4, 14641),
     "sol": "One year's growth: 14,641 / 13,310 = 1.1, so the rate is 10%. Principal = 13,310 / 1.1³ = 13,310 / 1.331 = ₹10,000."},
    {"q": "In how many ways can the letters of the word BANANA be arranged so that no two A's are next to each other?",
     "tita": True, "ans": "12",
     "check": lambda: len({p for p in permutations("BANANA") if "AA" not in "".join(p)}) == 12,
     "sol": "Arrange B, N, N first: 3!/2! = 3 ways. They create 4 gaps (including the ends), and the three A's must go in 3 different gaps: C(4, 3) = 4. Total 3 × 4 = 12."},
    {"q": "x, y and z are positive real numbers with x + y + z = 12. What is the maximum value of x·y²·z?",
     "tita": True, "ans": "324",
     "check": lambda: isclose(best_product(), 324, rel_tol=1e-9),
     "sol": "Split y into two halves and apply AM–GM to x, y/2, y/2, z, which add to 12: their product is at most 3⁴ = 81, with equality when all four equal 3. So x·(y/2)²·z ≤ 81, i.e. x·y²·z ≤ 324, reached at x = 3, y = 6, z = 3."},
    {"q": "The average weight of A, B and C is 84 kg. When D joins them, the average of the four becomes 80 kg. E, who weighs 3 kg more than D, then replaces A, and the average weight of B, C, D and E becomes 79 kg. What is A's weight, in kg?",
     "opts": ["75", "78", "80", "85"], "ans": 0,
     "check": lambda: (lambda D: 252 - (316 - D - (D + 3)) == 75)(320 - 252),
     "sol": "A + B + C = 252 and A + B + C + D = 320, so D = 68 and E = 71. B + C + D + E = 316, so B + C = 316 − 139 = 177. A = 252 − 177 = 75 kg."},
    {"q": "How many points with integer coordinates lie strictly inside the triangle with vertices (0, 0), (10, 0) and (0, 10)?",
     "opts": ["36", "45", "55", "66"], "ans": 0,
     "check": lambda: sum(1 for x in range(1, 10) for y in range(1, 10) if x + y < 10) == 36,
     "sol": "Interior points need x ≥ 1, y ≥ 1 and x + y ≤ 9. For x = 1, …, 8 there are 9 − x values of y: 8 + 7 + … + 1 = 36."},
    {"q": "For how many integer values of k does the equation x² + kx + 16 = 0 have no real roots?",
     "opts": ["15", "16", "17", "18"], "ans": 0,
     "check": lambda: sum(1 for k in range(-50, 51) if k * k - 64 < 0) == 15,
     "sol": "No real roots means k² − 64 < 0, so −8 < k < 8: the integers −7 to 7, which is 15 values."},
    {"q": "In an election between two candidates, 10% of the registered voters did not vote, and 10% of the votes cast were invalid. The winner received 54% of the valid votes and won by 1,620 votes. How many voters were registered?",
     "tita": True, "ans": "25000",
     "check": lambda: isclose(25000 * 0.9 * 0.9 * (0.54 - 0.46), 1620),
     "sol": "Valid votes = 0.9 × 0.9 × N = 0.81N. The margin is 54% − 46% = 8% of valid votes: 0.08 × 0.81N = 0.0648N = 1,620, so N = 25,000."},
    {"q": "What is the remainder when 3²⁰²⁶ is divided by 100?",
     "opts": ["9", "29", "49", "69"], "ans": 1,
     "check": lambda: pow(3, 2026, 100) == 29,
     "sol": "3⁵ = 243 ≡ 43 and 3¹⁰ ≡ 43² = 1849 ≡ 49, so 3²⁰ ≡ 49² = 2401 ≡ 1 (mod 100). 2026 = 20 × 101 + 6, so 3²⁰²⁶ ≡ 3⁶ = 729 ≡ 29."},
    {"q": "A square is inscribed in a semicircle of radius 5 cm, with one side of the square lying along the diameter. What is the area of the square, in cm²?",
     "opts": ["16", "18", "20", "25"], "ans": 2,
     "check": lambda: isclose((sqrt(20) / 2) ** 2 + 20, 25),
     "sol": "By symmetry the square's base is centred on the diameter. A top corner is at distance s/2 sideways and s up from the centre, and lies on the circle: (s/2)² + s² = 25, so 5s²/4 = 25 and s² = 20."},
    {"q": "A can finish a piece of work in 20 days and B in 30 days. They work on alternate days, A working on the first day. On which day is the work completed?",
     "tita": True, "ans": "24",
     "check": lambda: alternate_days() == 24,
     "sol": "In each two-day cycle they finish 1/20 + 1/30 = 1/12 of the work. Twelve cycles, 24 days, complete it exactly, with B working on day 24."},
    {"q": "If logₐb = 2 and log_b c = 3, where a, b, c > 1, what is the value of log_c(ab)?",
     "opts": ["1/6", "1/4", "1/3", "1/2"], "ans": 3,
     "check": lambda: (lambda la: Fr(la + 2 * la, 6 * la) == Fr(1, 2))(1),
     "sol": "Write b = a² and c = b³ = a⁶. Then ab = a³, and log_c(ab) = 3/6 = 1/2."},
    {"q": "What is the highest power of 6 that divides 50! exactly?",
     "tita": True, "ans": "22",
     "check": lambda: min(power_in_factorial(50, 2), power_in_factorial(50, 3)) == 22 and factorial(50) % 6 ** 22 == 0 and factorial(50) % 6 ** 23,
     "sol": "6 = 2 × 3, and 3 is the scarcer factor. Power of 3 in 50!: 16 + 5 + 1 = 22 (power of 2 is 47). So 6²² divides 50! but 6²³ does not."},
    {"q": "A shopkeeper uses a weight of 900 g in place of 1 kg, and sells his goods at 10% above cost price. What is his actual profit percentage?",
     "opts": ["18.18%", "20%", "21%", "22.22%"], "ans": 3,
     "check": lambda: isclose((1.1 / 0.9 - 1) * 100, 22.2222, rel_tol=1e-4),
     "sol": "For goods costing 0.9 units (900 g) he charges 1.1 units (10% above the cost of 1 kg). Profit = 1.1/0.9 − 1 = 2/9 = 22.22%."},
    {"q": "A right circular cone is cut by a plane parallel to its base, halfway up its height. What fraction of the cone's volume lies in the lower piece (the frustum)?",
     "opts": ["1/2", "2/3", "3/4", "7/8"], "ans": 3,
     "check": lambda: 1 - Fr(1, 2) ** 3 == Fr(7, 8),
     "sol": "The small cone on top is similar to the whole cone with scale factor 1/2, so its volume is (1/2)³ = 1/8 of the whole. The frustum has 7/8."},
    {"q": "How many pairs of positive integers (x, y) satisfy x² − y² = 96?",
     "opts": ["4", "5", "6", "8"], "ans": 0,
     "check": lambda: sum(1 for x in range(1, 100) for y in range(1, x) if x * x - y * y == 96) == 4,
     "sol": "(x − y)(x + y) = 96, and both factors must be even with x − y < x + y. Writing them as 2m and 2n with mn = 24 and m < n gives (1, 24), (2, 12), (3, 8), (4, 6): four pairs, e.g. (25, 23), (14, 10), (11, 5), (10, 2)."},
    {"q": "Three different numbers are chosen at random from 1, 2, 3, …, 21. What is the probability that their sum is even?",
     "opts": ["1/2", "67/133", "66/133", "10/19"], "ans": 1,
     "check": lambda: Fr(sum(1 for c in combinations(range(1, 22), 3) if sum(c) % 2 == 0), comb(21, 3)) == Fr(67, 133),
     "sol": "There are 11 odd and 10 even numbers. The sum is even with three evens, C(10, 3) = 120, or two odds and one even, C(11, 2) × 10 = 550. Total choices: C(21, 3) = 1,330. Probability = 670 / 1,330 = 67/133."},
]


def verify():
    for i, item in enumerate(QA, 1):
        assert item["check"](), f"QA {i} failed its check"
    return f"QA: all {len(QA)} checks pass"
