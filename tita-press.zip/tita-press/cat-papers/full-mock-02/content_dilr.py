"""Full Mock 02 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import permutations, product

# ---------- Set 1: floors ----------
def floor_solutions():
    sols = []
    for perm in permutations("PQRSTUV"):
        f = {p: i + 1 for i, p in enumerate(perm)}
        if f["R"] % 2 or f["R"] <= f["T"]: continue
        if abs(f["P"] - f["Q"]) != 3: continue
        if f["S"] in (1, 7) or abs(f["U"] - f["S"]) == 1: continue
        if f["V"] != f["Q"] + 1 or f["T"] == 1 or f["P"] <= f["S"]: continue
        sols.append("".join(perm))  # index 0 = floor 1
    return sols

# ---------- Set 2: judges ----------
DANCERS = "WXYZ"

def judge_solutions():
    ranks = list(permutations((4, 3, 2, 1)))
    sols = []
    for j in product(ranks, repeat=4):
        tot = {d: sum(j[k][i] for k in range(4)) for i, d in enumerate(DANCERS)}
        if tot["W"] != 13 or tot["Z"] != 6 or len(set(tot.values())) < 4: continue
        if any(j[k][1] == 1 for k in range(4)): continue
        if sum(1 for k in range(4) if j[k][2] == 4) != 1: continue
        if j[0][3] != 1 or j[1][1] != 4: continue
        if tot["X"] <= tot["Y"]: continue
        sols.append((j, tot))
    return sols

# ---------- Set 3: languages ----------
def language_solutions():
    sols = []
    for he, ht, et in product(range(10, 200), repeat=3):
        h, e, t = 115 - 30 - he - ht, 130 - 30 - he - et, 70 - 30 - ht - et
        if min(h, e, t) < 0 or h + e + t + he + ht + et + 30 != 200: continue
        sols.append(dict(h=h, e=e, t=t, he=he, ht=ht, et=et))
    return sols

# ---------- Set 4: sales ----------
PRICE = {"Alpha": 1200, "Beta": 800, "Gamma": 500}
UNITS = {"Alpha": (120, 135, 150, 140, 160, 150), "Beta": (200, 190, 210, 230, 220, 250), "Gamma": (300, 320, 280, 310, 400, 360)}
MONTHS = ["January", "February", "March", "April", "May", "June"]
def rev(p, m): return PRICE[p] * UNITS[p][m]

# ---------- Set 5: warehouses ----------
COST = {"X": (4, 6, 9), "Y": (5, 3, 7), "Z": (8, 5, 2)}

def warehouse_solutions():
    def splits(n):
        for a in range(0, n + 1, 10):
            for b in range(0, n - a + 1, 10):
                yield (a, b, n - a - b)
    sols = []
    for x in splits(80):
        for y in splits(60):
            for z in splits(40):
                if any(x[i] + y[i] + z[i] != c for i, c in enumerate((70, 50, 60))): continue
                g = {"X": x, "Y": y, "Z": z}
                if any(sum(1 for v in r if v) < 2 for r in g.values()): continue
                if not (x[0] > x[1] and x[0] > x[2]) or z[0]: continue
                pos = [v for v in y if v]
                if len(set(pos)) == len(pos): continue
                if z[1] <= x[1]: continue
                sols.append(g)
    return sols

def cost(g): return sum(c * v for w in g for c, v in zip(COST[w], g[w]))


SETS = [
    {"title": "Set 1",
     "intro": ["Seven people, P, Q, R, S, T, U and V, live in a seven-storey building, one on each floor. The floors are numbered 1 (lowest) to 7 (highest). The following is known:",
               "1. R lives on an even-numbered floor, somewhere above T.",
               "2. Exactly two floors lie between the floors of P and Q.",
               "3. S lives neither on floor 1 nor on floor 7, and U does not live directly above or below S.",
               "4. V lives directly above Q.",
               "5. T does not live on floor 1.",
               "6. P lives somewhere above S."],
     "questions": [
        {"q": "Who lives on floor 3?", "opts": ["P", "S", "T", "V"], "ans": 1,
         "sol": "T is not on floor 1, so R, which is even and above T, is on floor 4 or 6. The pair Q, V (V directly above Q) and P three floors from Q must fit around R, T and S, with S below P and U not next to S. With R on 4 nothing fits. With R on 6 exactly two arrangements work, from floor 1 up: Q, V, S, P, T, R, U and U, T, S, Q, V, R, P. In both, S is on floor 3."},
        {"q": "How many different arrangements of the seven people satisfy all the conditions?", "tita": True, "ans": "2",
         "sol": "The two arrangements are Q V S P T R U and U T S Q V R P (floor 1 to floor 7)."},
        {"q": "Which of the following must be true?", "opts": ["P lives on floor 4.", "Q lives on floor 1.", "R lives on floor 6.", "T lives on floor 2."], "ans": 2,
         "sol": "Only R on floor 6 holds in both arrangements. Each of the other statements holds in just one."},
        {"q": "If U lives on the top floor, who lives on floor 5?", "opts": ["T", "V", "P", "Q"], "ans": 0,
         "sol": "U on floor 7 gives Q V S P T R U, so T is on floor 5."},
     ]},
    {"title": "Set 2",
     "intro": ["Four judges, numbered 1 to 4, each ranked four dancers, W, X, Y and Z, from first to last. A first place earned 4 points, second 3, third 2 and last 1. A dancer's total is the sum of the points from all four judges. The following is known:",
               "1. W's total was 13 and Z's total was 6. No two dancers had the same total.",
               "2. No judge ranked X last.",
               "3. Exactly one judge ranked Y first.",
               "4. Judge 1 ranked Z last, and Judge 2 ranked X first.",
               "5. X's total was higher than Y's."],
     "questions": [
        {"q": "How many judges ranked Z first?", "opts": ["0", "1", "2", "3"], "ans": 0,
         "sol": "Z got 1 point from Judge 1, so the other three judges gave Z 5 points in all. Each gave at least 1, so none can have given 4 (4 + 1 + 1 = 6 > 5). No judge ranked Z first."},
        {"q": "Which of the following could have been X's total?", "opts": ["9", "10", "11", "13"], "ans": 2,
         "sol": "The four totals add to 4 × 10 = 40, so X + Y = 40 − 13 − 6 = 21, with X > Y. X cannot be 13 (W has 13). X = 10 would make Y = 11, above X. X = 11 with Y = 10 is possible, for example (first to last) Judge 1: W, X, Y, Z; Judge 2: X, Y, W, Z; Judge 3: W, Z, X, Y; Judge 4: Y, W, X, Z. (X = 12 is also possible but is not offered.)"},
        {"q": "What is the largest number of judges who could have ranked W first?", "tita": True, "ans": "2",
         "sol": "Judge 2 ranked X first, and one judge ranked Y first, so at most two judges are left to rank W first. Two is achievable, as in the example above."},
        {"q": "If X's total was 11, how many judges ranked Z last?", "tita": True, "ans": "3",
         "sol": "With X = 11, Y = 10. After Judge 1's 1 point, Z's other 5 points split as 3 + 1 + 1 or 2 + 2 + 1. Working through the rankings, only the 3 + 1 + 1 split lets X and Y reach 11 and 10 while satisfying clues 2 and 3, so three judges ranked Z last."},
     ]},
    {"title": "Set 3",
     "intro": ["A survey of the 200 employees of a firm recorded which of three languages, Hindi, English and Tamil, each employee speaks. Every employee speaks at least one of the three. The following is known:",
               "1. 115 employees speak Hindi, 130 speak English and 70 speak Tamil.",
               "2. 30 employees speak all three languages.",
               "3. For each pair of languages, at least 10 employees speak exactly that pair and not the third."],
     "questions": [
        {"q": "How many employees speak exactly two of the three languages?", "tita": True, "ans": "55",
         "sol": "Let S be the number who speak exactly one language and D exactly two. Counting people: S + D + 30 = 200. Counting language-speakers: S + 2D + 3 × 30 = 115 + 130 + 70 = 315. Subtracting the first equation from the second: D + 60 = 115, so D = 55."},
        {"q": "What is the largest possible number of employees who speak only Tamil?", "opts": ["15", "20", "25", "30"], "ans": 1,
         "sol": "Only Tamil = 70 − 30 − (Hindi–Tamil only) − (English–Tamil only). The three pair-only groups add to 55, so Hindi–Tamil plus English–Tamil = 55 − (Hindi–English only), which is at least 55 − 35 = 20 because the other two pairs need at least 10 each. Only Tamil is therefore at most 40 − 20 = 20."},
        {"q": "What is the smallest possible number of employees who speak only English?", "opts": ["55", "60", "65", "70"], "ans": 0,
         "sol": "Only English = 130 − 30 − (Hindi–English only) − (English–Tamil only) = 100 − (55 − Hindi–Tamil only). With Hindi–Tamil only at its minimum of 10, only English is at least 100 − 45 = 55."},
        {"q": "If 20 employees speak only Tamil, how many speak only Hindi?", "tita": True, "ans": "40",
         "sol": "20 only-Tamil needs Hindi–Tamil only = English–Tamil only = 10 and Hindi–English only = 35. Only Hindi = 115 − 30 − 35 − 10 = 40."},
        {"q": "What is the largest possible number of employees who speak both Hindi and English (whether or not they also speak Tamil)?", "opts": ["50", "55", "60", "65"], "ans": 3,
         "sol": "Hindi-and-English = 30 + (Hindi–English only), and Hindi–English only is at most 55 − 10 − 10 = 35. The maximum is 65; every group stays non-negative there (only Hindi 40, only English 55, only Tamil 20)."},
     ]},
    {"title": "Set 4",
     "intro": ["A company sells three products. Their prices were fixed through the first half of the year: Alpha at ₹1,200, Beta at ₹800 and Gamma at ₹500 per unit. The table gives the number of units of each product sold every month."],
     "table": {"head": ["Product", *[m[:3] for m in MONTHS]],
               "rows": [[p, *map(str, UNITS[p])] for p in UNITS]},
     "questions": [
        {"q": "In which month was the company's total revenue from the three products the highest?", "opts": ["March", "April", "May", "June"], "ans": 2,
         "sol": "Monthly revenue in ₹ thousand: January 454, February 474, March 488, April 507, May 568, June 560. Gamma's jump to 400 units in May puts May just ahead of June."},
        {"q": "In how many of the six months did Gamma earn more revenue than Beta?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "Gamma earns more when 500 × Gamma units > 800 × Beta units, i.e. Gamma units > 1.6 × Beta units. That holds in February (320 > 304) and May (400 > 352) only."},
        {"q": "By what percentage did Alpha's revenue in June exceed its revenue in January?", "tita": True, "ans": "25",
         "sol": "The price is unchanged, so revenue grows with units: 150 / 120 = 1.25, a 25% increase."},
        {"q": "Suppose that in June the company had cut Beta's price by 10% and, as a result, sold 20% more units of Beta, with everything else unchanged. By how many rupees would June's total revenue have risen?", "tita": True, "ans": "16000",
         "sol": "Beta's June revenue would be 300 × ₹720 = ₹2,16,000 instead of 250 × ₹800 = ₹2,00,000. Since 0.9 × 1.2 = 1.08, revenue rises 8%: ₹16,000."},
     ]},
    {"title": "Set 5",
     "intro": ["Three warehouses, X, Y and Z, supply three shops, 1, 2 and 3. In one week X dispatched 80 units, Y 60 and Z 40, and shops 1, 2 and 3 received 70, 50 and 60 units respectively. Every shipment from a warehouse to a shop was a multiple of 10 units; a warehouse may have sent nothing to a shop. The table gives the transport cost in rupees per unit on each route.",
               "1. Each warehouse supplied at least two shops.",
               "2. X sent more units to shop 1 than to either of the other shops.",
               "3. Z sent nothing to shop 1.",
               "4. Y sent the same non-zero number of units to at least two shops.",
               "5. Shop 2 received more units from Z than from X."],
     "table": {"head": ["Cost per unit (₹)", "Shop 1", "Shop 2", "Shop 3"],
               "rows": [[w, *map(str, COST[w])] for w in COST]},
     "questions": [
        {"q": "How many different shipment plans satisfy all the conditions?", "tita": True, "ans": "6",
         "sol": "Z sends nothing to shop 1, so X and Y supply its 70 units, with X's share the largest of X's three shipments. Working through X's shipment to shop 1 (40 to 70) and applying clues 1, 4 and 5 leaves six plans, written as X / Y / Z to shops 1, 2, 3: (40,20,20 / 30,0,30 / 0,30,10), (50,0,30 / 20,20,20 / 0,30,10), (50,10,20 / 20,20,20 / 0,20,20), (60,0,20 / 10,40,10 / 0,10,30), (60,10,10 / 10,10,40 / 0,30,10), (70,0,10 / 0,30,30 / 0,20,20)."},
        {"q": "What is the lowest possible total transport cost, in rupees?", "tita": True, "ans": "770",
         "sol": "Costs of the six plans: ₹990, ₹940, ₹880, ₹770, ₹920 and ₹810. The cheapest is X 60, 0, 20; Y 10, 40, 10; Z 0, 10, 30, costing 240 + 180 + 50 + 120 + 70 + 50 + 60 = ₹770."},
        {"q": "In the cheapest plan, how many units did Y send to shop 2?", "opts": ["10", "20", "30", "40"], "ans": 3,
         "sol": "In the ₹770 plan Y sends 10, 40 and 10 units: 40 to shop 2, on its cheapest route (₹3 per unit)."},
        {"q": "What is the largest number of units X could have sent to shop 1?", "opts": ["50", "60", "70", "80"], "ans": 2,
         "sol": "X sending 70 to shop 1 works: X 70, 0, 10; Y 0, 30, 30; Z 0, 20, 20. 80 is impossible, because X must supply at least two shops."},
        {"q": "If Y sent 20 units to each shop, what is the lowest possible total transport cost, in rupees?", "opts": ["880", "920", "940", "990"], "ans": 0,
         "sol": "Two plans have Y sending 20 to each shop: X 50, 0, 30 with Z 0, 30, 10 (₹940), and X 50, 10, 20 with Z 0, 20, 20 (₹880). The lower is ₹880."},
     ]},
]


def verify():
    s1 = floor_solutions()
    assert sorted(s1) == sorted(["QVSPTRU", "UTSQVRP"]), s1
    assert all(s[2] == "S" and s[5] == "R" for s in s1)
    assert not all(s[3] == "P" for s in s1) and not all(s[0] == "Q" for s in s1) and not all(s[1] == "T" for s in s1)
    top_u = [s for s in s1 if s[6] == "U"]
    assert len(top_u) == 1 and top_u[0][4] == "T"

    s2 = judge_solutions()
    assert s2 and all(sum(1 for k in range(4) if j[k][3] == 4) == 0 for j, _ in s2)
    example = ((4, 3, 2, 1), (2, 4, 3, 1), (4, 2, 1, 3), (3, 2, 4, 1))  # the ranking quoted in question 2's solution
    assert any(j == example and t["X"] == 11 for j, t in s2)
    xs = {t["X"] for _, t in s2}
    assert 11 in xs and not xs & {9, 10, 13}
    assert max(sum(1 for k in range(4) if j[k][0] == 4) for j, _ in s2) == 2
    assert {sum(1 for k in range(4) if j[k][3] == 1) for j, t in s2 if t["X"] == 11} == {3}

    s3 = language_solutions()
    assert {s["he"] + s["ht"] + s["et"] for s in s3} == {55}
    assert max(s["t"] for s in s3) == 20 and min(s["e"] for s in s3) == 55
    assert {s["h"] for s in s3 if s["t"] == 20} == {40}
    assert max(s["he"] for s in s3) + 30 == 65

    totals = [sum(rev(p, m) for p in PRICE) for m in range(6)]
    assert MONTHS[totals.index(max(totals))] == "May"
    assert sum(1 for m in range(6) if rev("Gamma", m) > rev("Beta", m)) == 2
    assert rev("Alpha", 5) * 100 // rev("Alpha", 0) - 100 == 25
    assert UNITS["Beta"][5] * 6 // 5 * 720 - rev("Beta", 5) == 16000

    s5 = warehouse_solutions()
    assert len(s5) == 6
    best = min(s5, key=cost)
    assert cost(best) == 770 and best["Y"][1] == 40
    assert max(g["X"][0] for g in s5) == 70
    assert min(cost(g) for g in s5 if g["Y"] == (20, 20, 20)) == 880
    return "DILR: all 22 keys match the solvers"
