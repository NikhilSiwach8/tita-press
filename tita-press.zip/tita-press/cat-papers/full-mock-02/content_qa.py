"""Full Mock 02 QA: 22 questions at CAT difficulty. Each item's check() recomputes the answer from scratch."""
from fractions import Fraction as Fr
from itertools import combinations
from math import comb, isclose, pi, sqrt


def real_roots_2x_eq_x2():
    """Count sign changes of 2^x − x² on a fine grid, plus exact touching roots."""
    f = lambda x: 2 ** x - x * x
    xs = [i / 1000 for i in range(-10000, 10001)]
    roots = 0
    for a, b in zip(xs, xs[1:]):
        if f(a) == 0:
            roots += 1
        elif f(a) * f(b) < 0:
            roots += 1
    return roots


def trailing_zeros_of_superfactorial(n):
    fives = 0
    for k in range(1, n + 1):
        m = k
        while m:
            m //= 5; fives += m
    return fives


QA = [
    {"q": "Two trains, 150 m and 200 m long, run on parallel tracks. Travelling in the same direction, the faster train takes 70 seconds to pass the slower one completely; travelling in opposite directions, they pass each other in 10 seconds. What is the speed of the faster train, in km/h?",
     "tita": True, "ans": "72",
     "check": lambda: (lambda d, s: isclose((d + s) / 2 * 3.6, 72))(350 / 70, 350 / 10),
     "sol": "Total length 350 m. Same direction: difference of speeds = 350/70 = 5 m/s. Opposite directions: sum = 350/10 = 35 m/s. Faster = (35 + 5)/2 = 20 m/s = 72 km/h."},
    {"q": "If a + b + c = 0 and abc = 4, what is the value of a³ + b³ + c³?",
     "opts": ["0", "4", "8", "12"], "ans": 3,
     "check": lambda: (lambda a, b: isclose(a ** 3 + b ** 3 + (-a - b) ** 3, 3 * a * b * (-a - b)))(1.7, -3.1),
     "sol": "a³ + b³ + c³ − 3abc = (a + b + c)(a² + b² + c² − ab − bc − ca) = 0, so a³ + b³ + c³ = 3abc = 12."},
    {"q": "A boat goes 30 km upstream and 44 km downstream in 10 hours. It goes 40 km upstream and 55 km downstream in 13 hours. What is the speed of the boat in still water, in km/h?",
     "tita": True, "ans": "8",
     "check": lambda: isclose(30 / 5 + 44 / 11, 10) and isclose(40 / 5 + 55 / 11, 13) and (5 + 11) / 2 == 8,
     "sol": "Let u and d be the times per km upstream and downstream: 30u + 44d = 10 and 40u + 55d = 13. Multiply the first by 4 and the second by 3: 120u + 176d = 40 and 120u + 165d = 39, so 11d = 1, d = 1/11 (11 km/h) and u = 1/5 (5 km/h). Boat speed = (11 + 5)/2 = 8 km/h."},
    {"q": "A number is first increased by x% and then decreased by x%. The result is 4% less than the original number. What is x?",
     "opts": ["12", "15", "16", "20"], "ans": 3,
     "check": lambda: isclose((1 + 0.2) * (1 - 0.2), 0.96),
     "sol": "(1 + x/100)(1 − x/100) = 1 − (x/100)² = 0.96, so (x/100)² = 0.04 and x = 20."},
    {"q": "By selling 33 metres of cloth, a shopkeeper gains an amount equal to the selling price of 11 metres. What is his gain percentage?",
     "opts": ["50%", "60%", "66.67%", "75%"], "ans": 0,
     "check": lambda: Fr(33, 33 - 11) - 1 == Fr(1, 2),
     "sol": "SP(33) − CP(33) = SP(11), so CP(33) = SP(22). The cost of 33 m buys only 22 m at selling price: gain = 33/22 − 1 = 50%. (Taking 11/33 = 33.33% is the usual slip.)"},
    {"q": "Alloy P contains copper and zinc in the ratio 3 : 2; alloy Q contains them in the ratio 1 : 3. In what ratio must P and Q be mixed to obtain an alloy with equal amounts of copper and zinc?",
     "opts": ["5 : 2", "2 : 5", "3 : 2", "1 : 1"], "ans": 0,
     "check": lambda: Fr(5 * Fr(3, 5) + 2 * Fr(1, 4), 7) == Fr(1, 2),
     "sol": "Copper fractions: P 3/5 = 0.6, Q 1/4 = 0.25, target 0.5. By alligation, P : Q = (0.5 − 0.25) : (0.6 − 0.5) = 0.25 : 0.1 = 5 : 2."},
    {"q": "Pipe A fills a tank in 12 hours and pipe B in 15 hours, while pipe C empties the full tank in 20 hours. If all three are opened together when the tank is empty, in how many hours will it be full?",
     "tita": True, "ans": "10",
     "check": lambda: 1 / (Fr(1, 12) + Fr(1, 15) - Fr(1, 20)) == 10,
     "sol": "Net rate = 1/12 + 1/15 − 1/20 = (5 + 4 − 3)/60 = 1/10 of the tank per hour, so 10 hours."},
    {"q": "The average of five consecutive odd numbers is 61. What is the product of the smallest and the largest of them?",
     "tita": True, "ans": "3705",
     "check": lambda: sum(range(57, 66, 2)) == 305 and 57 * 65 == 3705,
     "sol": "The middle number is the average, 61, so the numbers are 57, 59, 61, 63, 65. 57 × 65 = 3,705."},
    {"q": "A sum is invested at 20% per annum compound interest, compounded every six months. The interest earned in one year is ₹4,200. What is the sum invested, in rupees?",
     "tita": True, "ans": "20000",
     "check": lambda: isclose(20000 * (1.1 ** 2 - 1), 4200),
     "sol": "Each half-year earns 10%, so a year multiplies the sum by 1.1² = 1.21. Interest = 0.21P = 4,200, so P = ₹20,000."},
    {"q": "What is the product of all the real roots of x² − 5|x| + 6 = 0?",
     "opts": ["−36", "6", "36", "72"], "ans": 2,
     "check": lambda: [x for x in range(-10, 11) if x * x - 5 * abs(x) + 6 == 0] == [-3, -2, 2, 3] and (-3) * (-2) * 2 * 3 == 36,
     "sol": "With t = |x|: t² − 5t + 6 = 0 gives t = 2 or 3, so x = ±2, ±3. Product = (−2)(2)(−3)(3) = 36."},
    {"q": "How many real values of x satisfy 2ˣ = x²?",
     "opts": ["1", "2", "3", "4"], "ans": 2,
     "check": lambda: real_roots_2x_eq_x2() == 3,
     "sol": "x = 2 and x = 4 are solutions. For negative x, 2ˣ falls from 1 towards 0 while x² rises from 0, so the curves cross once more between −1 and 0. For x > 4, 2ˣ grows faster than x² and they never meet again. Three solutions."},
    {"q": "The sum of an infinite geometric progression is 12, and the sum of the squares of its terms is 48. What is its first term?",
     "tita": True, "ans": "6",
     "check": lambda: (lambda a, r: isclose(a / (1 - r), 12) and isclose(a * a / (1 - r * r), 48))(6, 0.5),
     "sol": "a/(1 − r) = 12 and a²/(1 − r²) = 48. Dividing the second by the first: a/(1 + r) = 4. So 12(1 − r) = 4(1 + r), giving r = 1/2 and a = 6."},
    {"q": "For how many integers n with 0 < n < 20 is (n − 1)(n − 4)(n − 9) < 0?",
     "opts": ["4", "5", "6", "7"], "ans": 0,
     "check": lambda: sum(1 for n in range(1, 20) if (n - 1) * (n - 4) * (n - 9) < 0) == 4,
     "sol": "The product is negative for n < 1 or 4 < n < 9. In the range 1 to 19 that gives n = 5, 6, 7, 8. (At n = 1, 4 and 9 it is zero, not negative.)"},
    {"q": "If log₂(log₃(log₄ x)) = 0, what is x?",
     "opts": ["12", "27", "48", "64"], "ans": 3,
     "check": lambda: isclose(__import__("math").log(__import__("math").log(__import__("math").log(64, 4), 3), 2), 0, abs_tol=1e-12),
     "sol": "log₃(log₄ x) = 2⁰ = 1, so log₄ x = 3¹ = 3, so x = 4³ = 64."},
    {"q": "What is the minimum value of (x² + 2x + 10)/(x + 1) for x > −1?",
     "opts": ["6", "8", "9", "10"], "ans": 0,
     "check": lambda: isclose(min((t * t + 9) / t for t in [i / 1000 for i in range(1, 20000)]), 6),
     "sol": "Put t = x + 1 > 0. The numerator is t² + 9, so the expression is t + 9/t ≥ 2√9 = 6 by AM–GM, with equality at t = 3 (x = 2)."},
    {"q": "Two parallel chords of a circle of radius 13 cm have lengths 24 cm and 10 cm and lie on opposite sides of the centre. What is the distance between them, in cm?",
     "tita": True, "ans": "17",
     "check": lambda: sqrt(13 ** 2 - 12 ** 2) + sqrt(13 ** 2 - 5 ** 2) == 17,
     "sol": "Distance of the 24 cm chord from the centre: √(169 − 144) = 5. Of the 10 cm chord: √(169 − 25) = 12. On opposite sides: 5 + 12 = 17 cm."},
    {"q": "What is the area of the circle inscribed in an equilateral triangle of side 6 cm, in cm²?",
     "opts": ["2π", "3π", "4π", "9π/4"], "ans": 1,
     "check": lambda: isclose(pi * (6 / (2 * sqrt(3))) ** 2, 3 * pi),
     "sol": "The inradius of an equilateral triangle is side/(2√3) = 6/(2√3) = √3. Area = π(√3)² = 3π."},
    {"q": "In a rectangle measuring 12 cm by 5 cm, what is the perpendicular distance from a vertex to the diagonal that does not pass through it, in cm?",
     "opts": ["30/13", "12/5", "13/3", "60/13"], "ans": 3,
     "check": lambda: Fr(2 * Fr(12 * 5, 2), 13) == Fr(60, 13),
     "sol": "The diagonal is 13. The triangle formed by the vertex and that diagonal has area ½ × 12 × 5 = 30 = ½ × 13 × h, so h = 60/13 cm."},
    {"q": "A solid metal sphere of radius 6 cm is melted and recast into solid cones, each of base radius 3 cm and height 4 cm. How many cones are made?",
     "tita": True, "ans": "24",
     "check": lambda: Fr(4 * 6 ** 3, 3) / Fr(3 ** 2 * 4, 3) == 24,
     "sol": "Sphere: (4/3)π × 216 = 288π. Cone: (1/3)π × 9 × 4 = 12π. 288π / 12π = 24."},
    {"q": "What is the smallest positive number that leaves a remainder of 5 when divided by each of 6, 8 and 12, and is divisible by 7?",
     "tita": True, "ans": "77",
     "check": lambda: min(n for n in range(1, 10000) if all(n % d == 5 for d in (6, 8, 12)) and n % 7 == 0) == 77,
     "sol": "The number is 24k + 5 (24 is the LCM). 24k + 5 ≡ 3k + 5 ≡ 0 (mod 7) gives 3k ≡ 2, so k = 3 and the number is 77."},
    {"q": "How many zeros are there at the end of the product 1! × 2! × 3! × … × 10!?",
     "opts": ["7", "8", "9", "10"], "ans": 0,
     "check": lambda: trailing_zeros_of_superfactorial(10) == 7 and (lambda p: len(str(p)) - len(str(p).rstrip("0")))(__import__("math").prod(__import__("math").factorial(k) for k in range(1, 11))) == 7,
     "sol": "Count factors of 5, since 2s are plentiful. 5! to 9! each contain one 5 (five factorials), and 10! contains two. Total 5 + 2 = 7 zeros."},
    {"q": "A bag holds 4 red balls and 6 blue balls. Three balls are drawn at random without replacement. What is the probability that at least two of them are red?",
     "opts": ["1/6", "1/5", "1/4", "1/3"], "ans": 3,
     "check": lambda: Fr(comb(4, 2) * 6 + comb(4, 3), comb(10, 3)) == Fr(1, 3),
     "sol": "Two red and one blue: C(4, 2) × 6 = 36. Three red: C(4, 3) = 4. Total draws: C(10, 3) = 120. Probability = 40/120 = 1/3."},
]


def verify():
    for i, item in enumerate(QA, 1):
        assert item["check"](), f"QA {i} failed its check"
    return f"QA: all {len(QA)} checks pass"
