"""Full Mock 03 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import permutations, product

# ---------- Set 1: meetings ----------
def meeting_solutions():
    sols = []
    for perm in permutations("ABCDH"):  # Audit, Budget, Client, Design, Hiring; index 0 = Monday
        d = {m: i for i, m in enumerate(perm)}
        if d["C"] != 2 or not d["B"] - d["A"] > 1 or d["D"] > d["H"]: continue
        for rooms in product((1, 2, 3), repeat=5):
            r = {perm[i]: rooms[i] for i in range(5)}
            if r["D"] != r["H"] or any(rooms[i] == rooms[i + 1] for i in range(4)): continue
            if rooms.count(3) != 1 or rooms[2] != 3 or r["B"] == 1: continue
            sols.append((perm, r))
    return sols

# ---------- Set 2: bus ----------
BOARD = (30, 18, 12, 20, 8, 0)
ALIGHT = (0, 10, 15, 9, 16, 38)

def bus_from_clues():
    """Fill the three blanks from the clues, then return boarding, alighting and load after each stop."""
    b, a = list(BOARD), list(ALIGHT)
    b[2] = a[3] = a[5] = None           # the blanks in the printed table
    load = lambda k: sum(b[:k + 1]) - sum(a[:k + 1])
    b[2] = 35 - (load(1)) + a[2]        # left stop 3 with 35
    a[3] = load(2) + b[3] - 46          # left stop 4 with 46
    a[5] = load(4) + b[5]               # everyone off at stop 6
    assert (tuple(b), tuple(a)) == (BOARD, ALIGHT)
    return b, a, [load(k) for k in range(6)]

def max_first_to_last():
    """Most stop-1 boarders who can still be aboard at stop 6: let everyone else get off first."""
    groups = {}
    for k in range(5):  # stops 1-5; everyone left gets off at stop 6
        off = ALIGHT[k]
        for g in sorted(groups, reverse=True):  # latest boarders first, stop-1 group last
            if g == 0: continue
            take = min(off, groups[g]); groups[g] -= take; off -= take
        if off:
            groups[0] -= off
            assert groups[0] >= 0
        if BOARD[k]: groups[k] = groups.get(k, 0) + BOARD[k]
    return groups[0]

# ---------- Set 3: exam results ----------
EXAM = {"X": ((40, 75), (30, 80)), "Y": ((35, 60), (45, 80)), "Z": ((50, 70), (25, 88))}  # (students, pass %) boys, girls
def passed(n, pct): return n * pct // 100

# ---------- Set 4: truth-tellers ----------
PEOPLE = "ABCDE"

def truth_solutions(c_claim=2, ignore=None):
    out = []
    for t in product((True, False), repeat=5):
        T = dict(zip(PEOPLE, t)); liars = 5 - sum(t)
        said = {"A": not T["B"], "B": T["C"] and T["D"], "C": liars == c_claim,
                "D": (not T["A"]) or (not T["E"]), "E": T["B"]}
        if all(said[p] == T[p] for p in PEOPLE if p != ignore):
            out.append("".join(p for p in PEOPLE if T[p]))
    return out

# ---------- Set 5: rankings ----------
FIRMS = "KLMNOP"

def ranking_solutions():
    sols = []
    for a in permutations(range(1, 7)):
        r24 = dict(zip(FIRMS, a))
        if r24["K"] != 1 or r24["N"] != 2 or r24["M"] < r24["N"]: continue
        for b in permutations(range(1, 7)):
            r25 = dict(zip(FIRMS, b))
            up = {f: r24[f] - r25[f] for f in FIRMS}
            if 0 in up.values() or sum(1 for v in up.values() if v > 0) != 3: continue
            if r25["K"] == 1 or up["L"] != 3 or max(up.values()) > 3: continue
            if r25["M"] != r24["N"] or abs(up["O"]) != 1 or r25["O"] != 5: continue
            if r25["P"] != 6 or up["N"] >= 0: continue
            sols.append((r24, r25))
    return sols


SETS = [
    {"title": "Set 1",
     "intro": ["Five meetings, Audit, Budget, Client, Design and Hiring, are held on the five weekdays from Monday to Friday, one meeting a day. Each is held in one of three rooms, 1, 2 and 3. The following is known:",
               "1. Client is on Wednesday.",
               "2. Audit is held on an earlier day than Budget, but not on the day immediately before it.",
               "3. Design is held on an earlier day than Hiring, and the two are held in the same room.",
               "4. No room is used on two consecutive days.",
               "5. Room 3 is used only once, on Wednesday.",
               "6. Budget is not held in room 1."],
     "questions": [
        {"q": "In which room is Hiring held?", "opts": ["Room 1", "Room 2", "Room 3", "Cannot be determined"], "ans": 0,
         "sol": "Wednesday is Client in room 3, so the other four days use rooms 1 and 2, alternating within Monday–Tuesday and within Thursday–Friday. Audit must be at least two days before Budget with Wednesday taken, so Audit is on Monday or Tuesday and Budget on Thursday or Friday. Design comes before Hiring and the remaining days are one early and one late, so Design is early and Hiring late. Budget is not in room 1, so it is in room 2; Hiring, on the other late day, is in room 1; Design shares Hiring's room (1), so Audit is in room 2. Hiring is in room 1."},
        {"q": "Which meeting is held in the same room as Budget?", "opts": ["Audit", "Client", "Design", "Hiring"], "ans": 0,
         "sol": "From the reasoning above, Audit and Budget are in room 2, Design and Hiring in room 1, and Client in room 3."},
        {"q": "How many different complete schedules (day and room for every meeting) satisfy all the conditions?", "tita": True, "ans": "4",
         "sol": "Audit and Design can take Monday and Tuesday in either order, and Budget and Hiring can take Thursday and Friday in either order. Rooms are fixed in every case, and adjacent days always differ (2 and 1), so there are 2 × 2 = 4 schedules."},
        {"q": "If Budget is on Friday, on which day is Hiring held?", "opts": ["Monday", "Tuesday", "Thursday", "Cannot be determined"], "ans": 2,
         "sol": "Budget and Hiring share Thursday and Friday, so Budget on Friday puts Hiring on Thursday."},
        {"q": "On how many different days of the week could Design be held?", "tita": True, "ans": "2",
         "sol": "Design is always on Monday or Tuesday, and both occur in valid schedules."},
     ]},
    {"title": "Set 2",
     "intro": ["A bus runs from stop 1 to stop 6, calling at stops 2, 3, 4 and 5 in order. It starts empty. The table shows how many passengers boarded and got off at each stop; three entries are missing. The following is also known:",
               "1. The bus carried 35 passengers when it left stop 3.",
               "2. The largest number of passengers on board at any time was 46, when the bus left stop 4.",
               "3. Every passenger still on board got off at stop 6."],
     "table": {"head": ["Stop", "1", "2", "3", "4", "5", "6"],
               "rows": [["Boarded", "30", "18", "–", "20", "8", "0"], ["Got off", "0", "10", "15", "–", "16", "–"]]},
     "questions": [
        {"q": "How many passengers got off at stop 6?", "tita": True, "ans": "38",
         "sol": "Leaving stop 2: 30 + 18 − 10 = 38. Leaving stop 3 with 35 means 38 + x − 15 = 35, so 12 boarded at stop 3. Leaving stop 4 with 46: 35 + 20 − y = 46, so 9 got off at stop 4. Leaving stop 5: 46 + 8 − 16 = 38, all of whom get off at stop 6."},
        {"q": "Between which two consecutive stops was the bus most crowded?", "opts": ["Stops 2 and 3", "Stops 3 and 4", "Stops 4 and 5", "Stops 5 and 6"], "ans": 2,
         "sol": "Loads after each stop: 30, 38, 35, 46, 38. The peak of 46 is between stops 4 and 5 (clue 2)."},
        {"q": "What was the average number of passengers on board over the five stretches of the route (stop 1 to 2, 2 to 3, and so on)?", "tita": True, "ans": "37.4",
         "sol": "(30 + 38 + 35 + 46 + 38) / 5 = 187 / 5 = 37.4."},
        {"q": "What is the largest possible number of passengers who travelled all the way from stop 1 to stop 6?", "opts": ["20", "25", "28", "30"], "ans": 0,
         "sol": "The 10 who got off at stop 2 must have boarded at stop 1, leaving at most 20 of the stop-1 group. Every later drop-off can be covered by people who boarded later: stop 3's 15 from stop 2's 18, stop 4's 9 from the remaining 3 plus stop 3's 12, and stop 5's 16 from the remaining 6 plus stop 4's 20. So 20 is achievable."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the number of boys and girls in each of three sections of a class and the percentage of each group who passed the final examination."],
     "table": {"head": ["Section", "Boys", "Boys passed", "Girls", "Girls passed"],
               "rows": [[s, str(b[0]), f"{b[1]}%", str(g[0]), f"{g[1]}%"] for s, (b, g) in EXAM.items()]},
     "questions": [
        {"q": "Which section had the highest overall pass percentage?", "opts": ["X", "Y", "Z", "X and Z equally"], "ans": 0,
         "sol": "Passes: X 30 + 24 = 54 of 70 (77.1%); Y 21 + 36 = 57 of 80 (71.25%); Z 35 + 22 = 57 of 75 (76%). X is highest."},
        {"q": "What percentage of all the girls in the three sections passed?", "tita": True, "ans": "82",
         "sol": "Girls passed: 24 + 36 + 22 = 82, out of 30 + 45 + 25 = 100 girls: 82%."},
        {"q": "In how many sections was the girls' pass percentage at least 10 percentage points higher than the boys'?", "opts": ["0", "1", "2", "3"], "ans": 2,
         "sol": "Gaps: X 80 − 75 = 5, Y 80 − 60 = 20, Z 88 − 70 = 18. Two sections."},
        {"q": "If 5 more boys in section Y had passed, which section would then have the highest overall pass percentage?", "opts": ["X", "Y", "Z", "X and Y equally"], "ans": 1,
         "sol": "Y would have 62 passes out of 80 = 77.5%, just above X's 54/70 = 77.14% and Z's 76%."},
     ]},
    {"title": "Set 4",
     "intro": ["Each of five people, A, B, C, D and E, is either a truth-teller, who always tells the truth, or a liar, who always lies. Each makes one statement:",
               "A: 'B is a liar.'",
               "B: 'C and D are both truth-tellers.'",
               "C: 'Exactly two of the five of us are liars.'",
               "D: 'At least one of A and E is a liar.'",
               "E: 'B is a truth-teller.'"],
     "questions": [
        {"q": "How many of the five are liars?", "opts": ["1", "2", "3", "4"], "ans": 2,
         "sol": "Suppose B tells the truth. Then C, D and E (who backs B) tell the truth and A is a liar, making exactly one liar, which contradicts C. So B lies, A tells the truth and E lies. E being a liar makes D's statement true, so D tells the truth. B's statement is false, so C must be a liar. Liars: B, C and E, three in all. C's claim of two is false, as a liar's claim must be."},
        {"q": "Which two people are both truth-tellers?", "opts": ["A and D", "B and E", "A and C", "D and E"], "ans": 0,
         "sol": "From the reasoning above, only A and D tell the truth."},
        {"q": "Suppose C had instead said 'Exactly three of the five of us are liars', with the other statements unchanged. How many ways could the five be assigned as truth-tellers and liars consistently?", "opts": ["0", "1", "2", "3"], "ans": 0,
         "sol": "If B tells the truth, there is again only one liar (A), so C's new claim is false while C is supposed to tell the truth: impossible. If B lies, the same steps make A and D truthful and B, C, E liars: three liars, so C's claim would be true, but C is a liar. Neither case works, so there are no consistent assignments."},
        {"q": "If C's original statement is ignored, in how many ways can the five be consistently assigned as truth-tellers and liars?", "tita": True, "ans": "2",
         "sol": "Without C's statement, B truthful gives B, C, D, E truthful and A a liar, which is consistent (D's claim is true because A lies). B lying gives A and D truthful and B, C, E liars, as before. Two assignments."},
     ]},
    {"title": "Set 5",
     "intro": ["Six firms, K, L, M, N, O and P, were ranked 1 (best) to 6 in an industry survey in both 2024 and 2025, with no ties. A firm 'improved' if its rank number went down. The following is known:",
               "1. No firm had the same rank in both years, and exactly three firms improved.",
               "2. K was ranked first in 2024 but not in 2025. N was ranked second in 2024, and its rank got worse.",
               "3. L improved by three places, and no firm improved by more than three places.",
               "4. M was ranked below N in 2024, and M's 2025 rank was the same as N's 2024 rank.",
               "5. O moved by exactly one place and was ranked fifth in 2025.",
               "6. P was ranked last in 2025."],
     "questions": [
        {"q": "Which firm was ranked first in 2025?", "opts": ["K", "L", "M", "N"], "ans": 1,
         "sol": "M is second in 2025 (clue 4), O fifth and P sixth. K and N got worse, so neither is first in 2025. First must be L, M's place being taken, so L improved from 4 to 1. O moved one place to fifth from sixth (fourth is L's 2024 rank). That leaves 2024 ranks 3 and 5 for M and P, and 2025 ranks 3 and 4 for K and N. All four combinations work, and L is first in each."},
        {"q": "What was L's rank in 2024?", "tita": True, "ans": "4",
         "sol": "L was first in 2025 after improving by three places, so it was fourth in 2024."},
        {"q": "For how many of the six firms are both the 2024 and the 2025 ranks known for certain?", "tita": True, "ans": "2",
         "sol": "L (4 then 1) and O (6 then 5) are fixed. K and N have known 2024 ranks but 2025 ranks of 3 or 4; M and P have known 2025 ranks but 2024 ranks of 3 or 5."},
        {"q": "If K was ranked third in 2025, what was N's rank in 2025?", "opts": ["1", "3", "4", "5"], "ans": 2,
         "sol": "K and N share 2025 ranks 3 and 4, so K third puts N fourth."},
        {"q": "Which of the following could have been P's rank in 2024?", "opts": ["1", "2", "3", "4"], "ans": 2,
         "sol": "P's 2024 rank is 3 or 5. Of the options, only 3 is possible."},
     ]},
]


def verify():
    s1 = meeting_solutions()
    assert len(s1) == 4
    assert all(r["H"] == 1 and r["B"] == 2 and r["A"] == 2 and r["D"] == 1 for _, r in s1)
    fri_b = [p for p, _ in s1 if p[4] == "B"]
    assert fri_b and all(p.index("H") == 3 for p in fri_b)
    assert {p.index("D") for p, _ in s1} == {0, 1}

    b, a, load = bus_from_clues()
    assert a[5] == 38 and load.index(max(load)) == 3
    assert sum(load[:5]) / 5 == 37.4
    assert max_first_to_last() == 20

    passes = {s: passed(*bg[0]) + passed(*bg[1]) for s, bg in EXAM.items()}
    size = {s: bg[0][0] + bg[1][0] for s, bg in EXAM.items()}
    assert max(passes, key=lambda s: passes[s] / size[s]) == "X"
    assert sum(passed(*bg[1]) for bg in EXAM.values()) * 100 // sum(bg[1][0] for bg in EXAM.values()) == 82
    assert sum(1 for bg in EXAM.values() if bg[1][1] - bg[0][1] >= 10) == 2
    passes["Y"] += 5
    assert max(passes, key=lambda s: passes[s] / size[s]) == "Y"

    assert truth_solutions() == ["AD"]
    assert truth_solutions(c_claim=3) == []
    assert len(truth_solutions(ignore="C")) == 2

    s5 = ranking_solutions()
    assert len(s5) == 4
    assert all(r25["L"] == 1 and r24["L"] == 4 for r24, r25 in s5)
    fixed = [f for f in FIRMS if len({r24[f] for r24, _ in s5}) == 1 and len({r25[f] for _, r25 in s5}) == 1]
    assert fixed == ["L", "O"], fixed
    assert {r25["N"] for _, r25 in s5 if r25["K"] == 3} == {4}
    assert {r24["P"] for r24, _ in s5} == {3, 5}
    return "DILR: all 22 keys match the solvers"
