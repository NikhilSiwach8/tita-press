NAME = "Full Mock 03"
LEDE = "The third paper in the Full Mock Series, set at the difficulty of a real CAT slot. Sit it in one go, in section order, with a timer running. Answer key, worked solutions and a scoring table are in the separate solutions booklet."
SEED = 303
