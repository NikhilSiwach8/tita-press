"""Full Mock 04 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from collections import Counter
from itertools import combinations, permutations

# ---------- Set 1: team selection ----------
def teams():
    out = []
    for t in combinations("PQRSTUVW", 4):
        s = set(t)
        if len(s & set("PQRS")) < 2: continue
        if {"P", "T"} <= s or {"R", "S"} <= s: continue
        if "Q" in s and "U" not in s: continue
        if "V" in s and "W" not in s: continue
        out.append(s)
    return out

# ---------- Set 2: transferable-vote election ----------
BALLOTS = [(32, ("Iyer", "Khan", "Jain", "Lal")), (28, ("Jain", "Lal", "Khan", "Iyer")),
           (22, ("Khan", "Jain", "Iyer", "Lal")), (18, ("Lal", "Khan", "Jain", "Iyer"))]

def runoff(ballots):
    """Returns (winner, number of counts). Lowest first-preference total is eliminated each count."""
    alive = {c for _, order in ballots for c in order}
    total = sum(n for n, _ in ballots)
    for count in range(1, len(alive) + 1):
        tally = Counter({c: 0 for c in alive})
        for n, order in ballots:
            tally[next(c for c in order if c in alive)] += n
        leader, votes = tally.most_common(1)[0]
        if votes * 2 > total:
            return leader, count
        alive.remove(min(tally, key=tally.get))

# ---------- Set 3: number grid ----------
def grid_solutions():
    sols = []
    for p in permutations(range(1, 10)):
        g = [p[0:3], p[3:6], p[6:9]]
        if [sum(r) for r in g] != [15, 12, 18]: continue
        if [sum(g[r][c] for r in range(3)) for c in range(3)] != [12, 16, 17]: continue
        if g[1][1] != 1: continue
        sols.append(g)
    return sols

# ---------- Set 4: portfolio ----------
START = {"Equity": 400000, "Debt": 300000, "Gold": 200000, "Cash": 100000}
RETURN = {"Equity": 15, "Debt": 7, "Gold": -5, "Cash": 3}
# table rows below are written out to match START and RETURN
def end_value(start): return {k: v * (100 + RETURN[k]) // 100 for k, v in start.items()}

# ---------- Set 5: gym visits ----------
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
COUNTS = [3, 2, 3, 2, 2, 3]

def gym_solutions():
    opts = [frozenset(c) for c in combinations(range(6), 3)]
    spaced = lambda s: all(d + 1 not in s for d in s)
    sols = []
    for P in opts:
        if not spaced(P): continue
        for Q in opts:
            if P & Q or 4 not in Q: continue
            for R in opts:
                if sorted(R) != list(range(min(R), min(R) + 3)): continue
                for S in opts:
                    if not {2, 5} <= S: continue
                    for T in opts:
                        if T & R or 1 not in T: continue
                        if [sum(d in X for X in (P, Q, R, S, T)) for d in range(6)] != COUNTS: continue
                        sols.append(dict(P=P, Q=Q, R=R, S=S, T=T))
    return sols

def days(s): return ", ".join(DAYS[d] for d in sorted(s))


SETS = [
    {"title": "Set 1",
     "intro": ["A team of four is to be chosen from eight employees: four seniors, P, Q, R and S, and four juniors, T, U, V and W. The selection must follow these rules:",
               "1. The team must include at least two seniors.",
               "2. P and T cannot both be chosen, and R and S cannot both be chosen.",
               "3. If Q is chosen, U must also be chosen.",
               "4. V can be chosen only if W is also chosen."],
     "questions": [
        {"q": "How many different teams can be chosen?", "tita": True, "ans": "11",
         "sol": "R and S cannot both be in, so the seniors are two or three of P, Q and one of R/S. Listing by seniors: P Q (needs U; fourth member R, S or W): PQRU, PQSU, PQUW. P with R or S but not Q (no T; V needs W): PRUW, PRVW, PSUW, PSVW. Q with R or S but not P (needs U): QRTU, QRUW, QSTU, QSUW. P, Q, R, S can't all be in. That makes 3 + 4 + 4 = 11."},
        {"q": "Which employee is a member of the largest number of possible teams?", "opts": ["P", "Q", "U", "W"], "ans": 2,
         "sol": "Counting through the 11 teams: U appears in 9, P, Q and W in 7 each."},
        {"q": "If P is chosen, how many different teams are possible?", "tita": True, "ans": "7",
         "sol": "The teams containing P are PQRU, PQSU, PQUW, PRUW, PRVW, PSUW and PSVW: seven."},
        {"q": "If T is chosen, which of the following must also be chosen?", "opts": ["P and U", "Q and U", "R and W", "S and W"], "ans": 1,
         "sol": "T rules out P, so the two seniors must include Q (only one of R and S is allowed). Q brings U. The teams are QRTU and QSTU, both containing Q and U."},
     ]},
    {"title": "Set 2",
     "intro": ["In a club election, 100 members each ranked all four candidates, Iyer, Jain, Khan and Lal, in order of preference. The ballots fell into four groups:",
               "32 members: Iyer, Khan, Jain, Lal",
               "28 members: Jain, Lal, Khan, Iyer",
               "22 members: Khan, Jain, Iyer, Lal",
               "18 members: Lal, Khan, Jain, Iyer",
               "Votes are counted in rounds. In each round every ballot counts for the highest-ranked candidate still in the race. If a candidate has more than half the votes, that candidate wins; otherwise the candidate with the fewest votes is eliminated and a new round is counted."],
     "questions": [
        {"q": "Who won the election?", "opts": ["Iyer", "Jain", "Khan", "Lal"], "ans": 2,
         "sol": "Round 1: Iyer 32, Jain 28, Khan 22, Lal 18. Lal is eliminated and those 18 ballots pass to Khan. Round 2: Khan 40, Iyer 32, Jain 28. Jain is eliminated; those 28 ballots skip Lal (already out) and pass to Khan. Round 3: Khan 68, Iyer 32. Khan wins."},
        {"q": "In which round of counting was the winner decided?", "tita": True, "ans": "3",
         "sol": "No one has a majority in rounds 1 and 2; Khan reaches 68 in round 3."},
        {"q": "Which candidate would have won if the election had been decided simply by the most first preferences?", "opts": ["Iyer", "Jain", "Khan", "Lal"], "ans": 0,
         "sol": "First preferences: Iyer 32, Jain 28, Khan 22, Lal 18. Iyer has the most."},
        {"q": "If the 18 members who ranked Lal first had instead ranked the candidates Lal, Jain, Khan, Iyer, who would have won?", "opts": ["Iyer", "Jain", "Khan", "Lal"], "ans": 1,
         "sol": "Round 1 is unchanged and Lal goes out, but now those 18 ballots pass to Jain. Round 2: Jain 46, Iyer 32, Khan 22. Khan is eliminated and those 22 ballots pass to Jain. Round 3: Jain 68, Iyer 32. Jain wins."},
     ]},
    {"title": "Set 3",
     "intro": ["The numbers 1 to 9 are placed in a 3 × 3 grid, one number in each cell. The following is known:",
               "1. The numbers in the top, middle and bottom rows add up to 15, 12 and 18 respectively.",
               "2. The numbers in the left, middle and right columns add up to 12, 16 and 17 respectively.",
               "3. The centre cell contains 1."],
     "questions": [
        {"q": "In how many different ways can the grid be filled?", "tita": True, "ans": "4",
         "sol": "The middle row is 1 plus two numbers adding to 11, and the middle column is 1 plus two numbers adding to 15. Working through these with the other sums gives four grids (rows top to bottom): 2 9 4 / 3 1 8 / 7 6 5; 4 9 2 / 3 1 8 / 5 6 7; 4 8 3 / 2 1 9 / 6 7 5; and 4 8 3 / 6 1 5 / 2 7 9."},
        {"q": "Which of the following must be true?", "opts": ["9 is in the top row.", "4 is in the top row.", "8 is in the middle row.", "5 is in the bottom-right corner."], "ans": 1,
         "sol": "4 appears in the top row of all four grids. 9 is in the top row of only two; 8 is in the middle row of only two; 5 is in the bottom-right corner of only two."},
        {"q": "If the two diagonals of the grid have equal sums, what number is in the bottom-left corner?", "opts": ["2", "5", "6", "7"], "ans": 2,
         "sol": "Only the grid 4 8 3 / 2 1 9 / 6 7 5 has equal diagonals (4 + 1 + 5 = 3 + 1 + 6 = 10). Its bottom-left corner is 6."},
        {"q": "If no two horizontally adjacent cells contain consecutive numbers, what is the sum of the four corner cells?", "tita": True, "ans": "18",
         "sol": "Each of the other three grids has two consecutive numbers side by side in a row (7 and 6 in the first, 5 and 6 in the second, 2 and 1 in the third, as listed above). Only 4 8 3 / 6 1 5 / 2 7 9 avoids this. Its corners add to 4 + 3 + 2 + 9 = 18."},
        {"q": "In how many of the possible grids is the bottom-right corner 5?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "The bottom-right corners of the four grids are 5, 7, 5 and 9. Two grids."},
     ]},
    {"title": "Set 4",
     "intro": ["At the start of a year an investor held the portfolio shown in the table. The last column shows the return each asset earned over the year. There were no additions or withdrawals during the year."],
     "table": {"head": ["Asset", "Value at start (₹)", "Return over the year"],
               "rows": [["Equity", "4,00,000", "+15%"], ["Debt", "3,00,000", "+7%"], ["Gold", "2,00,000", "−5%"], ["Cash", "1,00,000", "+3%"]]},
     "questions": [
        {"q": "What was the percentage return on the whole portfolio over the year?", "tita": True, "ans": "7.4",
         "sol": "End values: Equity 4,60,000, Debt 3,21,000, Gold 1,90,000, Cash 1,03,000; total 10,74,000 against 10,00,000 at the start: 7.4%."},
        {"q": "Which asset's share of the portfolio's total value rose over the year?", "opts": ["Equity", "Debt", "Gold", "Cash"], "ans": 0,
         "sol": "An asset's share rises only if it beat the portfolio's 7.4% return. Only Equity (15%) did: its share went from 40% to 4,60,000 / 10,74,000 = 42.8%. Debt's 7% falls just short."},
        {"q": "If the investor had moved ₹50,000 from Gold to Equity at the start of the year, what would the portfolio's percentage return have been?", "tita": True, "ans": "8.4",
         "sol": "Moving ₹50,000 from an asset returning −5% to one returning 15% adds 50,000 × 20% = ₹10,000 to the gain: 74,000 + 10,000 = 84,000, or 8.4%."},
        {"q": "At the end of the year the investor rebalances to the original proportions (Equity 40%, Debt 30%, Gold 20%, Cash 10%) without adding money. How many rupees' worth of Gold must be bought?", "tita": True, "ans": "24800",
         "sol": "The target for Gold is 20% of 10,74,000 = 2,14,800. Gold is worth 1,90,000, so ₹24,800 must be bought."},
     ]},
    {"title": "Set 5",
     "intro": ["Five friends, P, Q, R, S and T, each went to a gym on exactly three of the six days from Monday to Saturday in one week. The number of friends at the gym on each day was: Monday 3, Tuesday 2, Wednesday 3, Thursday 2, Friday 2, Saturday 3. The following is also known:",
               "1. P and Q were never at the gym on the same day, and P never went on two consecutive days.",
               "2. R went on three consecutive days.",
               "3. S went on Wednesday and on Saturday.",
               "4. T was never at the gym on a day when R was.",
               "5. T went on Tuesday, and Q went on Friday."],
     "questions": [
        {"q": "On which days did S go to the gym?", "opts": ["Monday, Wednesday, Saturday", "Tuesday, Wednesday, Saturday", "Wednesday, Thursday, Saturday", "Wednesday, Friday, Saturday"], "ans": 0,
         "sol": "P and Q never overlap, so between them they cover all six days once. R and T never overlap either (clue 4), so they also cover every day once. That accounts for 2 visits every day, so S supplies the third visit on exactly the days with 3: Monday, Wednesday and Saturday."},
        {"q": "How many different weekly schedules for the five friends satisfy all the conditions?", "tita": True, "ans": "6",
         "sol": "R's three consecutive days and T's other three must give T Tuesday, so R is Wednesday–Friday (T: Monday, Tuesday, Saturday) or Thursday–Saturday (T: Monday–Wednesday). P has no two consecutive days and Q, taking P's complement, includes Friday: P is Monday/Wednesday/Saturday, Monday/Thursday/Saturday or Tuesday/Thursday/Saturday. 2 × 3 = 6 schedules."},
        {"q": "If R went to the gym on Saturday, on which days did T go?", "opts": ["Monday, Tuesday, Wednesday", "Monday, Tuesday, Saturday", "Tuesday, Wednesday, Thursday", "Tuesday, Thursday, Saturday"], "ans": 0,
         "sol": "R on Saturday means R went Thursday to Saturday, so T, avoiding R's days, went Monday, Tuesday and Wednesday."},
        {"q": "If P went to the gym on Tuesday, on which days did Q go?", "opts": ["Monday, Wednesday, Friday", "Monday, Thursday, Friday", "Wednesday, Thursday, Friday", "Monday, Wednesday, Saturday"], "ans": 0,
         "sol": "The only option for P that includes Tuesday is Tuesday, Thursday, Saturday, so Q took the other days: Monday, Wednesday and Friday."},
        {"q": "What is the largest possible number of days on which P and S were both at the gym?", "tita": True, "ans": "3",
         "sol": "S went Monday, Wednesday and Saturday. P can go on exactly those three days (Q then goes Tuesday, Thursday and Friday), so the answer is 3."},
     ]},
]


def verify():
    ts = teams()
    assert len(ts) == 11
    c = Counter(m for t in ts for m in t)
    assert c.most_common(1)[0][0] == "U" and c["P"] == 7
    with_t = [t for t in ts if "T" in t]
    assert with_t and all({"Q", "U"} <= t for t in with_t)
    assert not all({"P", "U"} <= t for t in with_t) and not all({"R", "W"} <= t for t in with_t)

    assert runoff(BALLOTS) == ("Khan", 3)
    first = Counter()
    for n, order in BALLOTS: first[order[0]] += n
    assert first.most_common(1)[0][0] == "Iyer"
    changed = [(n, ("Lal", "Jain", "Khan", "Iyer") if order[0] == "Lal" else order) for n, order in BALLOTS]
    assert runoff(changed)[0] == "Jain"

    gs = grid_solutions()
    assert len(gs) == 4
    assert all(4 in g[0] for g in gs) and not all(9 in g[0] for g in gs) and not all(8 in g[1] for g in gs) and not all(g[2][2] == 5 for g in gs)
    diag = [g for g in gs if g[0][0] + g[2][2] == g[0][2] + g[2][0]]
    assert len(diag) == 1 and diag[0][2][0] == 6
    spaced = [g for g in gs if all(abs(r[i] - r[i + 1]) != 1 for r in g for i in range(2))]
    assert len(spaced) == 1 and spaced[0][0][0] + spaced[0][0][2] + spaced[0][2][0] + spaced[0][2][2] == 18
    assert sum(1 for g in gs if g[2][2] == 5) == 2

    assert [r[0] for r in SETS[3]["table"]["rows"]] == list(START)
    end = end_value(START)
    assert sum(end.values()) == 1074000
    share_up = [k for k in START if end[k] / 1074000 > START[k] / 1000000]
    assert share_up == ["Equity"]
    moved = dict(START, Equity=450000, Gold=150000)
    assert sum(end_value(moved).values()) - 1000000 == 84000
    assert 1074000 * 20 // 100 - end["Gold"] == 24800

    ys = gym_solutions()
    assert len(ys) == 6
    assert {days(y["S"]) for y in ys} == {"Monday, Wednesday, Saturday"}
    assert {days(y["T"]) for y in ys if 5 in y["R"]} == {"Monday, Tuesday, Wednesday"}
    assert {days(y["Q"]) for y in ys if 1 in y["P"]} == {"Monday, Wednesday, Friday"}
    assert max(len(y["P"] & y["S"]) for y in ys) == 3
    return "DILR: all 22 keys match the solvers"
