"""Full Mock 04 QA: 22 questions at CAT difficulty. Each item's check() recomputes the answer from scratch."""
from fractions import Fraction as Fr
from itertools import permutations
from math import factorial, isclose, log2, sqrt


def round_table_apart():
    """Seatings of 5 around a table (rotations identified) with persons 0 and 1 not adjacent."""
    count = 0
    for rest in permutations(range(1, 5)):
        seat = (0,) + rest
        i = seat.index(1)
        if i not in (1, 4): count += 1
    return count


QA = [
    {"q": "Walking at 5 km/h, a man reaches the station 6 minutes late. Walking at 6 km/h, he reaches it 4 minutes early. How far is the station, in km?",
     "tita": True, "ans": "5",
     "check": lambda: isclose(5 / 5 - 5 / 6, 10 / 60),
     "sol": "The two walking times differ by 6 + 4 = 10 minutes = 1/6 hour. d/5 − d/6 = d/30 = 1/6, so d = 5 km."},
    {"q": "A and B start together from the same point on a 400 m circular track and run in opposite directions at 6 m/s and 4 m/s. After how many seconds will they first be together again at the starting point?",
     "tita": True, "ans": "200",
     "check": lambda: next(t for t in range(1, 10000) if 6 * t % 400 == 0 and 4 * t % 400 == 0) == 200,
     "sol": "A completes a lap every 400/6 = 200/3 s and B every 100 s. They are both at the start at the first common multiple: 200 s (3 laps for A, 2 for B)."},
    {"q": "A shopkeeper marks an item 30% above its cost price. After giving a discount, he still makes a profit of 17%. What discount did he give?",
     "opts": ["10%", "12%", "13%", "15%"], "ans": 0,
     "check": lambda: isclose(1 - 1.17 / 1.3, 0.1),
     "sol": "Selling price / marked price = 1.17 / 1.30 = 0.9, a 10% discount. (Subtracting 30 − 17 = 13 is the trap.)"},
    {"q": "A sum of money doubles in 8 years at simple interest. In how many years will it become three times itself?",
     "opts": ["16", "18", "20", "24"], "ans": 0,
     "check": lambda: 2 / (Fr(1, 8)) == 16,
     "sol": "Doubling means the interest equals the principal in 8 years, i.e. 12.5% a year. Tripling needs interest of twice the principal: 16 years."},
    {"q": "₹7,800 is divided among A, B and C so that A gets half of what B gets, and B gets one-third of what C gets. What is C's share, in rupees?",
     "tita": True, "ans": "5200",
     "check": lambda: (lambda c: c / 6 + c / 3 + c == 7800)(5200),
     "sol": "B = C/3 and A = B/2 = C/6. C/6 + C/3 + C = 3C/2 = 7,800, so C = ₹5,200."},
    {"q": "A can do a job in 10 days and B in 15 days. With the help of C, they finish it in 4 days, and the ₹1,800 paid for the job is shared in proportion to the work each did. What is C's share, in rupees?",
     "tita": True, "ans": "600",
     "check": lambda: (lambda c: c == Fr(1, 12) and 1800 * 4 * c == 600)(Fr(1, 4) - Fr(1, 10) - Fr(1, 15)),
     "sol": "C's daily rate = 1/4 − 1/10 − 1/15 = (15 − 6 − 4)/60 = 1/12. In 4 days C does 4/12 = 1/3 of the job, so C earns 1,800 / 3 = ₹600."},
    {"q": "The average age of a husband and wife was 25 when they married. Six years later the average age of the husband, the wife and their child is 22. How old is the child?",
     "opts": ["1", "2", "3", "4"], "ans": 3,
     "check": lambda: 3 * 22 - (50 + 12) == 4,
     "sol": "At marriage their ages added to 50; six years later, 62. The family total is 3 × 22 = 66, so the child is 4."},
    {"q": "60 litres of a solution contains 20% acid. How many litres of pure acid must be added to make the solution 40% acid?",
     "tita": True, "ans": "20",
     "check": lambda: Fr(12 + 20, 60 + 20) == Fr(2, 5),
     "sol": "The solution has 12 L of acid. (12 + x)/(60 + x) = 0.4 gives 12 + x = 24 + 0.4x, so 0.6x = 12 and x = 20."},
    {"q": "If x² − 3x + 1 = 0, what is the value of x³ + 1/x³?",
     "opts": ["12", "15", "18", "21"], "ans": 2,
     "check": lambda: (lambda x: isclose(x ** 3 + x ** -3, 18))((3 + sqrt(5)) / 2),
     "sol": "Dividing by x: x + 1/x = 3. Then x³ + 1/x³ = (x + 1/x)³ − 3(x + 1/x) = 27 − 9 = 18."},
    {"q": "How many pairs of integers (x, y) satisfy |x| + |y| = 3?",
     "opts": ["4", "6", "8", "12"], "ans": 3,
     "check": lambda: sum(1 for x in range(-5, 6) for y in range(-5, 6) if abs(x) + abs(y) == 3) == 12,
     "sol": "The points form a diamond. With x = 0 or y = 0 there are 4 points (±3, 0), (0, ±3); with both non-zero, |x| = 1 or 2 gives 2 × 4 = 8 more. Total 12."},
    {"q": "What is the sum of all integers n that satisfy n² + n − 6 ≤ 0?",
     "opts": ["−3", "−2", "0", "3"], "ans": 0,
     "check": lambda: sum(n for n in range(-20, 21) if n * n + n - 6 <= 0) == -3,
     "sol": "(n + 3)(n − 2) ≤ 0 for −3 ≤ n ≤ 2. The sum −3 − 2 − 1 + 0 + 1 + 2 = −3."},
    {"q": "If f(x) = (x + 1)/(x − 1) for x ≠ 1, what is f(f(x))?",
     "opts": ["x", "1/x", "−x", "(x + 1)/(x − 1)"], "ans": 0,
     "check": lambda: all(isclose((lambda f: f(f(x)))(lambda t: (t + 1) / (t - 1)), x) for x in (2, 3.5, -4, 0.25)),
     "sol": "f(f(x)) = [(x + 1)/(x − 1) + 1] / [(x + 1)/(x − 1) − 1] = [2x/(x − 1)] / [2/(x − 1)] = x."},
    {"q": "The sum of the first 10 terms of an arithmetic progression is 155, and the sum of the first 20 terms is 610. What is the common difference?",
     "tita": True, "ans": "3",
     "check": lambda: sum(2 + 3 * k for k in range(10)) == 155 and sum(2 + 3 * k for k in range(20)) == 610,
     "sol": "5(2a + 9d) = 155 gives 2a + 9d = 31; 10(2a + 19d) = 610 gives 2a + 19d = 61. Subtracting: 10d = 30, so d = 3 (and a = 2)."},
    {"q": "If x > 1 and log₂x + logₓ2 = 5/2, what is the product of all possible values of x?",
     "opts": ["2√2", "4", "4√2", "8"], "ans": 2,
     "check": lambda: all(isclose(log2(x) + 1 / log2(x), 2.5) for x in (4, sqrt(2))) and isclose(4 * sqrt(2), 4 * 2 ** 0.5),
     "sol": "Let t = log₂x > 0. Then t + 1/t = 5/2, so t = 2 or 1/2, giving x = 4 or √2. Product = 4√2."},
    {"q": "What is the minimum value of (x − 1)(x − 2)(x − 3)(x − 4) for real x?",
     "opts": ["−2", "−1", "−9/16", "0"], "ans": 1,
     "check": lambda: isclose(min((x / 1000 - 1) * (x / 1000 - 2) * (x / 1000 - 3) * (x / 1000 - 4) for x in range(0, 5001)), -1, abs_tol=1e-5),
     "sol": "Pair the factors: (x − 1)(x − 4) = x² − 5x + 4 and (x − 2)(x − 3) = x² − 5x + 6. With u = x² − 5x + 5, the product is (u − 1)(u + 1) = u² − 1, which is at least −1, reached when u = 0."},
    {"q": "A right-angled triangle has sides 7 cm, 24 cm and 25 cm. What is the length of the median drawn to the hypotenuse, in cm?",
     "opts": ["11.5", "12", "12.25", "12.5"], "ans": 3,
     "check": lambda: isclose(sqrt(2 * 7 ** 2 + 2 * 24 ** 2 - 25 ** 2) / 2, 12.5),
     "sol": "In a right triangle the midpoint of the hypotenuse is equidistant from all three vertices, so the median to the hypotenuse is half of it: 12.5 cm."},
    {"q": "A 13 m ladder leans against a vertical wall with its foot 5 m from the wall. The foot slides 7 m further away from the wall. By how many metres does the top of the ladder slide down?",
     "tita": True, "ans": "7",
     "check": lambda: sqrt(13 ** 2 - 5 ** 2) - sqrt(13 ** 2 - 12 ** 2) == 7,
     "sol": "At first the top is √(169 − 25) = 12 m high. With the foot 12 m out, it is √(169 − 144) = 5 m high. It slides down 7 m."},
    {"q": "What is the area of the quadrilateral with vertices (0, 0), (4, 0), (5, 3) and (1, 4), taken in that order?",
     "tita": True, "ans": "14.5",
     "check": lambda: (lambda pts: abs(sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]))) / 2 == 14.5)([(0, 0), (4, 0), (5, 3), (1, 4)]),
     "sol": "Shoelace formula: ½|0·0 − 4·0 + 4·3 − 5·0 + 5·4 − 1·3 + 1·0 − 0·4| = ½(12 + 17) = 14.5."},
    {"q": "A cube has a total surface area of 150 cm². What is the length of its space diagonal, in cm?",
     "opts": ["5√2", "5√3", "10", "5√5"], "ans": 1,
     "check": lambda: isclose(sqrt(3) * sqrt(150 / 6), 5 * sqrt(3)),
     "sol": "6s² = 150, so s = 5. The space diagonal is s√3 = 5√3 cm."},
    {"q": "How many divisors of 2⁴ × 3³ are perfect squares?",
     "opts": ["3", "4", "5", "6"], "ans": 3,
     "check": lambda: sum(1 for d in range(1, 433) if 432 % d == 0 and int(sqrt(d)) ** 2 == d) == 6,
     "sol": "A square divisor needs even exponents: 2⁰, 2², 2⁴ (three choices) and 3⁰, 3² (two choices). 3 × 2 = 6."},
    {"q": "What is the remainder when 1! + 2! + 3! + … + 100! is divided by 12?",
     "tita": True, "ans": "9",
     "check": lambda: sum(factorial(k) for k in range(1, 101)) % 12 == 9,
     "sol": "From 4! = 24 onwards every term is divisible by 12. So the remainder comes from 1 + 2 + 6 = 9."},
    {"q": "In how many ways can 5 people sit around a round table if two particular people must not sit next to each other? (Arrangements that are rotations of each other count as the same.)",
     "opts": ["6", "12", "18", "24"], "ans": 1,
     "check": lambda: round_table_apart() == 12,
     "sol": "Around a table, 5 people can sit in 4! = 24 ways. Treating the two as one unit gives 3! × 2 = 12 arrangements with them together. Apart: 24 − 12 = 12."},
]


def verify():
    for i, item in enumerate(QA, 1):
        assert item["check"](), f"QA {i} failed its check"
    return f"QA: all {len(QA)} checks pass"
