"""Full Mock 05 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import combinations, permutations, product

# ---------- Set 1: follower network ----------
PEOPLE = "UVWXY"
PAIRS = [(a, b) for a in PEOPLE for b in PEOPLE if a != b]
FOLLOWERS = (4, 2, 2, 0, 2)
FOLLOWING = (1, 2, 3, 2, 2)

def follow_solutions():
    sols = []
    for bits in product((0, 1), repeat=len(PAIRS)):
        if sum(bits) != 10: continue
        E = {PAIRS[i] for i, b in enumerate(bits) if b}
        if tuple(sum((q, p) in E for q in PEOPLE) for p in PEOPLE) != FOLLOWERS: continue
        if tuple(sum((p, q) in E for q in PEOPLE) for p in PEOPLE) != FOLLOWING: continue
        if sum(1 for a, b in combinations(PEOPLE, 2) if (a, b) in E and (b, a) in E) != 2: continue
        if ("U", "W") not in E: continue
        sols.append(E)
    return sols

# ---------- Set 2: coins ----------
def coin_solutions():
    sols = []
    for p in range(10, 101):
        q = 2 * p
        for r in range(q + 1, 101):
            for s in range(10, 46):
                t = 45 - s
                v = (p, q, r, s, t)
                if t < 10 or sum(v) != 100 or len(set(v)) < 5: continue
                if s <= t or t % 2 == 0: continue
                sols.append(dict(zip("PQRST", v)))
    return sols

# ---------- Set 3: scorecard ----------
CARD = {"Rao": (64, 48, 6, 2), "Sen": (38, 40, 4, 0), "Das": (55, 30, 3, 4),
        "Pal": (12, 15, 1, 0), "Roy": (27, 18, 2, 1), "Jha": (9, 9, 0, 1)}  # runs, balls, fours, sixes
EXTRAS, TOTAL, BALLS, FOURS = 11, 216, 160, 16

def card_from_clues():
    c = {k: list(v) for k, v in CARD.items()}
    c["Das"][1] = c["Roy"][0] = c["Sen"][2] = None
    c["Das"][1] = BALLS - sum(v[1] for k, v in c.items() if k != "Das")
    c["Roy"][0] = TOTAL - EXTRAS - sum(v[0] for k, v in c.items() if k != "Roy")
    c["Sen"][2] = FOURS - sum(v[2] for k, v in c.items() if k != "Sen")
    return {k: tuple(v) for k, v in c.items()}

# ---------- Set 4: hotel ratings ----------
SITES = ("Site 1", "Site 2", "Site 3")
HOTELS = {"Lotus": ((4.2, 200), (4.0, 100), (4.5, 100)), "Maple": ((3.8, 150), (4.4, 250), (4.0, 100)),
          "Orchid": ((4.8, 50), (4.1, 150), (3.9, 300)), "Pine": ((4.0, 300), (3.6, 100), (4.4, 100))}
def combined(h): return Fr(sum(round(r * 10) * n for r, n in HOTELS[h]), 10 * sum(n for _, n in HOTELS[h]))
def simple(h): return Fr(sum(round(r * 10) for r, _ in HOTELS[h]), 30)

# ---------- Set 5: two rows ----------
def row_solutions():
    sols = []
    for perm in permutations("MNOPQRST"):
        pos = {p: (0, i) for i, p in enumerate(perm[:4])}
        pos.update({p: (1, i) for i, p in enumerate(perm[4:])})
        face = lambda a, b: pos[a][0] != pos[b][0] and pos[a][1] == pos[b][1]
        nb = lambda a, b: pos[a][0] == pos[b][0] and abs(pos[a][1] - pos[b][1]) == 1
        if not face("M", "R"): continue
        if pos["N"] != (0, 0) and pos["N"] != (0, 3) or not face("T", "N"): continue
        if not nb("O", "P") or pos["P"][0] != 1 or pos["P"][1] in (0, 3): continue
        if pos["O"][0] == pos["Q"][0] or pos["S"][0] != 0: continue
        if pos["M"][1] in (0, 3) or nb("M", "Q"): continue
        sols.append(("".join(perm[:4]), "".join(perm[4:])))
    return sols


SETS = [
    {"title": "Set 1",
     "intro": ["Five people, U, V, W, X and Y, use a social network on which each person may follow any of the others. Following need not be mutual. The table shows how many followers each person has among the five, and how many of the others each person follows. In addition:",
               "1. Exactly two pairs of people follow each other.",
               "2. U follows W."],
     "table": {"head": ["Person", "U", "V", "W", "X", "Y"],
               "rows": [["Followers", *map(str, FOLLOWERS)], ["Follows", *map(str, FOLLOWING)]]},
     "questions": [
        {"q": "Whom does W follow?", "opts": ["U and V only", "U, V and Y", "U, X and Y", "V, X and Y"], "ans": 1,
         "sol": "X has no followers, so nobody follows X. W follows three people, all from U, V and Y, so W follows exactly U, V and Y. (U has 4 followers: V, W, X and Y all follow U.)"},
        {"q": "How many different follow networks satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "Fixed so far: U follows only W; V, W, X and Y follow U; W also follows V and Y. That leaves one more choice each for V, X and Y, with V and W needing 2 followers each and Y needing 2, and exactly two mutual pairs (U–W is one). Checking the choices leaves three networks: V→Y, X→W, Y→V (V–Y mutual); V→Y, X→V, Y→W (W–Y mutual); V→W, X→Y, Y→V (V–W mutual)."},
        {"q": "Which of the following must be true?", "opts": ["V follows U.", "Y follows V.", "X follows W.", "V follows Y."], "ans": 0,
         "sol": "U has four followers, so all of V, W, X and Y follow U. Each of the other statements fails in at least one of the three networks."},
        {"q": "If X follows Y, which pair, apart from U and W, follow each other?", "opts": ["V and W", "V and Y", "W and Y", "X and Y"], "ans": 0,
         "sol": "X following Y occurs only in the network where V follows W and Y follows V. There the mutual pairs are U–W and V–W."},
     ]},
    {"title": "Set 2",
     "intro": ["100 coins are distributed among five boxes, P, Q, R, S and T. The following is known:",
               "1. Every box holds at least 10 coins, and no two boxes hold the same number.",
               "2. Q holds twice as many coins as P, and R holds more coins than Q.",
               "3. S and T together hold 45 coins, and S holds more than T.",
               "4. T holds an odd number of coins."],
     "questions": [
        {"q": "How many coins are in box R?", "opts": ["20", "25", "30", "35"], "ans": 1,
         "sol": "P + Q + R = 100 − 45 = 55, with Q = 2P and R > 2P. So 3P + R = 55 and R > 2P gives 55 − 3P > 2P, P < 11. With P ≥ 10, P = 10, Q = 20 and R = 25."},
        {"q": "In how many different ways can the coins be distributed?", "tita": True, "ans": "6",
         "sol": "T is odd, at least 10 and less than S, so T is 11, 13, 15, 17, 19 or 21 (T = 23 would make S = 22 < T). None of the matching S values (34 down to 24) equals 10, 20 or 25. Six distributions."},
        {"q": "What is the largest possible number of coins in box S?", "tita": True, "ans": "34",
         "sol": "S is largest when T is smallest, T = 11, giving S = 34."},
        {"q": "If S holds fewer coins than R, how many coins does T hold?", "opts": ["11", "15", "19", "21"], "ans": 3,
         "sol": "S < 25 and S ≥ 24 leaves only S = 24, so T = 21."},
        {"q": "In how many of the possible distributions does S hold more coins than every other box?", "opts": ["3", "4", "5", "6"], "ans": 2,
         "sol": "S must exceed R = 25 (it always exceeds T). S = 26, 28, 30, 32 or 34: five distributions. Only S = 24 fails."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the batting card of six players in a cricket innings. Three entries are missing. The team scored 216 runs in all, including 11 extras (runs not credited to any batter). The six batters faced 160 balls in all and hit 16 fours between them."],
     "table": {"head": ["Batter", "Runs", "Balls", "Fours", "Sixes"],
               "rows": [["Rao", "64", "48", "6", "2"], ["Sen", "38", "40", "–", "0"], ["Das", "55", "–", "3", "4"],
                        ["Pal", "12", "15", "1", "0"], ["Roy", "–", "18", "2", "1"], ["Jha", "9", "9", "0", "1"]]},
     "questions": [
        {"q": "How many runs did Roy score?", "tita": True, "ans": "27",
         "sol": "The batters scored 216 − 11 = 205. The other five scored 64 + 38 + 55 + 12 + 9 = 178, so Roy scored 27."},
        {"q": "Which batter scored runs at the fastest rate (runs per ball faced)?", "opts": ["Rao", "Das", "Roy", "Jha"], "ans": 1,
         "sol": "Das faced 160 − (48 + 40 + 15 + 18 + 9) = 30 balls. Runs per ball: Das 55/30 = 1.83, Roy 27/18 = 1.5, Rao 64/48 = 1.33, Jha 1.0. Das is fastest."},
        {"q": "What percentage of the runs scored by the six batters came from fours and sixes? Give your answer to the nearest whole number.", "tita": True, "ans": "55",
         "sol": "16 fours give 64 runs; sixes total 2 + 0 + 4 + 0 + 1 + 1 = 8, giving 48 runs. 112 of 205 = 54.6%, which rounds to 55."},
        {"q": "How many of Sen's runs came from shots other than fours and sixes?", "opts": ["18", "22", "26", "30"], "ans": 1,
         "sol": "Fours by the others: 6 + 3 + 1 + 2 + 0 = 12, so Sen hit 4 fours (16 runs) and no sixes. 38 − 16 = 22."},
     ]},
    {"title": "Set 4",
     "intro": ["Four hotels, Lotus, Maple, Orchid and Pine, are reviewed on three websites. For each hotel and website, the table gives the average rating (out of 5) and, in brackets, the number of reviews. A hotel's combined rating is the average over all its reviews on the three websites."],
     "table": {"head": ["Hotel", *SITES],
               "rows": [[h, *[f"{r:.1f} ({n})" for r, n in v]] for h, v in HOTELS.items()]},
     "questions": [
        {"q": "Which hotel has the highest combined rating?", "opts": ["Lotus", "Maple", "Orchid", "Pine"], "ans": 0,
         "sol": "Total rating points ÷ reviews: Lotus 1,690/400 = 4.225; Maple 2,070/500 = 4.14; Orchid 2,025/500 = 4.05; Pine 2,000/500 = 4.0. Lotus is highest."},
        {"q": "Which hotel has the highest simple average of its three website ratings (ignoring the numbers of reviews)?", "opts": ["Lotus", "Maple", "Orchid", "Pine"], "ans": 2,
         "sol": "Simple averages: Lotus 12.7/3 = 4.23, Maple 12.2/3 = 4.07, Orchid 12.8/3 = 4.27, Pine 12.0/3 = 4.0. Orchid leads, because its 4.8 on Site 1 comes from only 50 reviews and counts as much as its 3.9 from 300."},
        {"q": "How many new reviews, each rating Pine 5.0, would be needed on Site 2 to raise Pine's Site 2 average to exactly 4.0?", "tita": True, "ans": "40",
         "sol": "Pine has 100 reviews averaging 3.6 on Site 2, i.e. 360 points. (360 + 5x)/(100 + x) = 4 gives 360 + 5x = 400 + 4x, so x = 40."},
        {"q": "What is the average rating of all the reviews on Site 3, across the four hotels?", "tita": True, "ans": "4.1",
         "sol": "Site 3 points: 450 + 400 + 1,170 + 440 = 2,460 over 100 + 100 + 300 + 100 = 600 reviews: 4.1."},
     ]},
    {"title": "Set 5",
     "intro": ["Eight people, M, N, O, P, Q, R, S and T, sit in two rows of four seats, row 1 and row 2, facing each other. The seats in each row are numbered 1 to 4 so that seat k of row 1 is directly opposite seat k of row 2. Seats 1 and 4 are the ends of each row. The following is known:",
               "1. M sits directly opposite R.",
               "2. N sits at an end of row 1, directly opposite T.",
               "3. O and P sit next to each other in row 2, and P is not at an end.",
               "4. O and Q sit in different rows, and S sits in row 1.",
               "5. M is not at an end, and M does not sit next to Q."],
     "questions": [
        {"q": "How many different seating arrangements satisfy all the conditions?", "tita": True, "ans": "6",
         "sol": "Q is in row 1 (O is in row 2), so row 1 has N, S, Q and one of M/R, and row 2 has T, O, P and the other. The pair M–R sits in seat 2 or 3 opposite each other, N and T at one end, and O–P in the middle-and-end of row 2 with P in the middle. Checking both ends for N and the M/R choice against 'M not next to Q' leaves six arrangements (row 1 / row 2): NMSQ/TRPO, NRQS/TMPO, NRSQ/TMPO, QSMN/OPRT, QSRN/OPMT, SQRN/OPMT."},
        {"q": "Which of the following must be true?", "opts": ["O sits at an end of row 2.", "M sits in row 1.", "R sits next to T.", "Q sits at an end of row 1."], "ans": 0,
         "sol": "P is in the middle of row 2 with O beside it, and the other middle seat holds M or R (opposite each other), so O must take an end seat. The other statements fail in at least one arrangement."},
        {"q": "If M sits in row 1, who sits directly opposite S?", "opts": ["O", "P", "R", "T"], "ans": 1,
         "sol": "M in row 1 leaves NMSQ/TRPO and QSMN/OPRT. In both, S is opposite P."},
        {"q": "If R sits next to N, in how many ways can the eight be seated?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "R is next to N in NRQS/TMPO, NRSQ/TMPO, QSRN/OPMT and SQRN/OPMT: four arrangements."},
        {"q": "Which of the following people could sit directly opposite Q?", "opts": ["M", "O", "R", "T"], "ans": 1,
         "sol": "Across the six arrangements Q faces O or P. Of the options, only O is possible."},
     ]},
]


def verify():
    fs = follow_solutions()
    assert len(fs) == 3
    assert all({q for p, q in E if p == "W"} == {"U", "V", "Y"} for E in fs)
    assert all(("V", "U") in E for E in fs)
    assert not all(("Y", "V") in E for E in fs) and not all(("X", "W") in E for E in fs) and not all(("V", "Y") in E for E in fs)
    xy = [E for E in fs if ("X", "Y") in E]
    assert len(xy) == 1
    mutual = {frozenset((a, b)) for a, b in xy[0] if (b, a) in xy[0]}
    assert mutual == {frozenset("UW"), frozenset("VW")}

    cs = coin_solutions()
    assert len(cs) == 6 and {c["R"] for c in cs} == {25}
    assert max(c["S"] for c in cs) == 34
    assert {c["T"] for c in cs if c["S"] < c["R"]} == {21}
    assert sum(1 for c in cs if all(c["S"] > c[k] for k in "PQRT")) == 5

    card = card_from_clues()
    assert card == CARD
    assert card["Roy"][0] == 27
    assert max(card, key=lambda k: Fr(card[k][0], card[k][1])) == "Das"
    boundary = sum(4 * v[2] + 6 * v[3] for v in card.values())
    assert round(boundary * 100 / sum(v[0] for v in card.values())) == 55
    assert card["Sen"][0] - 4 * card["Sen"][2] - 6 * card["Sen"][3] == 22

    assert max(HOTELS, key=combined) == "Lotus"
    assert max(HOTELS, key=simple) == "Orchid"
    r, n = HOTELS["Pine"][1]
    assert next(x for x in range(1000) if Fr(round(r * 10) * n + 50 * x, 10 * (n + x)) == 4) == 40
    assert Fr(sum(round(v[2][0] * 10) * v[2][1] for v in HOTELS.values()), 10 * sum(v[2][1] for v in HOTELS.values())) == Fr(41, 10)

    rs = row_solutions()
    assert sorted(rs) == sorted([("NMSQ", "TRPO"), ("NRQS", "TMPO"), ("NRSQ", "TMPO"), ("QSMN", "OPRT"), ("QSRN", "OPMT"), ("SQRN", "OPMT")])
    assert all(b[0] == "O" or b[3] == "O" for _, b in rs)
    assert not all("M" in a for a, _ in rs) and not all(a[0] == "Q" or a[3] == "Q" for a, _ in rs)
    side_by_side = lambda row, x, y: x in row and y in row and abs(row.index(x) - row.index(y)) == 1
    assert not all(side_by_side(a, "R", "T") or side_by_side(b, "R", "T") for a, b in rs)
    assert {b[a.index("S")] for a, b in rs if "M" in a} == {"P"}
    assert sum(1 for a, _ in rs if "R" in a and abs(a.index("R") - a.index("N")) == 1) == 4
    assert {b[a.index("Q")] for a, b in rs} == {"O", "P"}
    return "DILR: all 22 keys match the solvers"
