"""Full Mock 06 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: project schedule ----------
TASKS = {  # name: (days, prerequisites)
    "Design": (3, ()), "Permits": (5, ()), "Foundation": (4, ("Design", "Permits")),
    "Frame": (6, ("Foundation",)), "Wiring": (3, ("Frame",)), "Plumbing": (4, ("Frame",)),
    "Walls": (5, ("Wiring", "Plumbing")), "Paint": (2, ("Walls",)), "Landscaping": (7, ("Permits",)),
}

def finish_times(tasks):
    done = {}
    def end(t):
        if t not in done:
            days, pre = tasks[t]
            done[t] = max((end(p) for p in pre), default=0) + days
        return done[t]
    for t in tasks: end(t)
    return done

def duration(tasks): return max(finish_times(tasks).values())

def delayed(task, extra):
    t = dict(TASKS); d, pre = t[task]; t[task] = (d + extra, pre)
    return duration(t)

# ---------- Set 2: gift exchange ----------
FRIENDS = "JKLMN"

def gift_solutions():
    sols = []
    for perm in permutations(FRIENDS):
        g = dict(zip(FRIENDS, perm))
        if any(g[p] == p or g[g[p]] == p for p in FRIENDS): continue
        if g["L"] != "N" or g["J"] == "K": continue
        sols.append(g)
    return sols

# ---------- Set 3: lock code ----------
CLUES = {"529": (1, 0), "571": (0, 1), "164": (0, 0), "938": (1, 1)}  # (right place, wrong place)

def score(code, guess):
    right = sum(c == g for c, g in zip(code, guess))
    return right, len(set(code) & set(guess)) - right

def codes(clues):
    return [c for c in ("".join(p) for p in permutations("0123456789", 3)) if all(score(c, g) == v for g, v in clues.items())]

# ---------- Set 4: exports ----------
YEARS = (2023, 2024, 2025)
EXPORTS = {"Textiles": (120, 126, 130), "Electronics": (80, 100, 125), "Spices": (40, 42, 45), "Machinery": (60, 72, 90)}
def total(i): return sum(v[i] for v in EXPORTS.values())

# ---------- Set 5: apartments ----------
FAMILIES = ["Iyer", "Kapoor", "Menon", "Nair", "Rao", "Sethi"]

def apartment_solutions():
    slots = [(f, s) for f in (1, 2, 3) for s in ("East", "West")]
    sols = []
    for perm in permutations(slots):
        pos = dict(zip(FAMILIES, perm))
        if pos["Iyer"] != (pos["Nair"][0] + 1, pos["Nair"][1]): continue
        if pos["Kapoor"][0] != pos["Menon"][0] or pos["Rao"][0] != 1 or pos["Sethi"][1] == "East": continue
        for mem in permutations(range(2, 8)):
            m = dict(zip(FAMILIES, mem))
            if pos[max(m, key=m.get)][0] != 3 or pos[min(m, key=m.get)][0] != 1: continue
            if m["Menon"] != m["Rao"] + 3 or m["Nair"] <= m["Iyer"]: continue
            if sum(m[f] for f in FAMILIES if pos[f][0] == 2) != 9: continue
            sols.append((pos, m))
    return sols


SETS = [
    {"title": "Set 1",
     "intro": ["A builder plans a house as nine tasks. The table gives each task's duration in days and the tasks that must be finished before it can start. Any number of tasks can be in progress at the same time, and the house is complete when every task is finished."],
     "table": {"head": ["Task", "Days", "Must follow"],
               "rows": [[t, str(d), ", ".join(p) if p else "–"] for t, (d, p) in TASKS.items()]},
     "questions": [
        {"q": "What is the shortest time, in days, in which the house can be completed?", "tita": True, "ans": "26",
         "sol": "Earliest finishes: Design 3, Permits 5, Foundation 5 + 4 = 9, Frame 15, Wiring 18, Plumbing 19, Walls 19 + 5 = 24, Paint 26, Landscaping 5 + 7 = 12. The house is complete at day 26, along Permits–Foundation–Frame–Plumbing–Walls–Paint."},
        {"q": "Which of the following tasks could be delayed by 2 days without delaying completion of the house?", "opts": ["Design", "Permits", "Plumbing", "Wiring"], "ans": 0,
         "sol": "Design finishes on day 3 but Foundation cannot start until Permits finishes on day 5, so Design has 2 days to spare. Permits and Plumbing are on the critical path (no spare time); Wiring finishes on day 18 but Walls waits until day 19, so it has only 1 day."},
        {"q": "If Plumbing took 6 days instead of 4, in how many days could the house be completed?", "tita": True, "ans": "28",
         "sol": "Plumbing would finish on day 21, so Walls runs 21–26 and Paint 26–28. Completion: day 28."},
        {"q": "If Wiring and Plumbing had to be done one after the other (in either order) rather than at the same time, what would be the shortest completion time, in days?", "opts": ["26", "27", "28", "29"], "ans": 3,
         "sol": "Both start after Frame (day 15) and together take 3 + 4 = 7 days, ending on day 22 whichever goes first. Walls then runs 22–27 and Paint 27–29: 29 days."},
     ]},
    {"title": "Set 2",
     "intro": ["Five friends, J, K, L, M and N, exchange gifts. Each gives exactly one gift to one of the others and receives exactly one gift. The following is known:",
               "1. No two friends give gifts to each other.",
               "2. L gives a gift to N.",
               "3. J does not give a gift to K."],
     "questions": [
        {"q": "In how many different ways can the gifts be exchanged?", "tita": True, "ans": "4",
         "sol": "With nobody giving to themselves and no two people swapping, five people must form a single cycle (a 3-cycle would leave a pair to swap). Cycles through L → N with J not followed by K: J→L→N→M→K→J, J→L→N→K→M→J, J→M→L→N→K→J and J→M→K→L→N→J. Four ways."},
        {"q": "Which of the following could J give a gift to?", "opts": ["K", "L", "N", "None of these"], "ans": 1,
         "sol": "J gives to L or to M in the four exchanges. Of the named options, only L is possible. (J cannot give to N, who receives from L.)"},
        {"q": "If K gives a gift to J, in how many ways can the gifts be exchanged?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "K → J appears in J→L→N→M→K→J and J→M→L→N→K→J: two ways."},
        {"q": "If N gives a gift to J, to whom does M give a gift?", "opts": ["J", "K", "L", "N"], "ans": 1,
         "sol": "N → J occurs only in J→M→K→L→N→J, so M gives to K."},
     ]},
    {"title": "Set 3",
     "intro": ["A lock opens with a three-digit code made of three different digits. Each attempt below was scored by saying how many of its digits appear in the code in the same position, and how many appear in the code but in a different position.",
               "529: one digit correct and in the right position.",
               "571: one digit correct but in the wrong position.",
               "164: no digit correct.",
               "938: one digit correct and in the right position, and one digit correct but in the wrong position."],
     "questions": [
        {"q": "What is the code?", "tita": True, "ans": "739",
         "sol": "164 rules out 1, 4 and 6. From 571, exactly one of 5 and 7 is in the code, and not in its tested position. From 529, exactly one of 5, 2 and 9 is in the code, in its tested position. If that digit were 5 it would be first, which 571 forbids; and 5 cannot be in the code alongside 2 or 9. So 5 is out and 7 is in, not in the middle. If 2 were the in-place digit of 529, 9 would be out and 938 would need both 3 and 8 as well as 2 and 7: four digits, impossible. So 9 is last and 2 is out. In 938, 9 is then the misplaced digit, so 3 or 8 is in place; 8 would be last, which is taken, so 3 is in the middle. 7 takes the first place: the code is 739."},
        {"q": "Which digit of 529 is in the code, in the same position?", "opts": ["2", "5", "9", "None of them"], "ans": 2,
         "sol": "The code is 739, which ends in 9, as 529 does."},
        {"q": "If the clue for 164 had not been given, which of the following codes would also fit all the remaining clues?", "opts": ["139", "329", "709", "789"], "ans": 0,
         "sol": "Without 164, the digit 1 is no longer ruled out. In the reasoning above, 1 can take the first place instead of 7, provided 571's single wrong-place digit is still met: 139 scores 529 one in place (9), 571 one misplaced (1), and 938 one in place (3) plus one misplaced (9). 329 contains 2 and 9 together (two hits for 529); 709 and 789 give 938 no in-place digit."},
        {"q": "Which of the following attempts would be scored 'two digits correct and in the right position, none in the wrong position'?", "opts": ["731", "379", "794", "973"], "ans": 0,
         "sol": "Against 739: 731 has 7 and 3 in place and 1 absent. 379 has 9 in place but 3 and 7 misplaced; 794 has 7 in place and 9 misplaced; 973 has all three digits misplaced."},
     ]},
    {"title": "Set 4",
     "intro": ["The table gives a country's exports of four groups of goods, in ₹ thousand crore, for three years."],
     "table": {"head": ["Goods", *map(str, YEARS)],
               "rows": [[g, *map(str, v)] for g, v in EXPORTS.items()]},
     "questions": [
        {"q": "Which group of goods had the highest percentage growth in exports from 2023 to 2025?", "opts": ["Textiles", "Electronics", "Spices", "Machinery"], "ans": 1,
         "sol": "Growth 2023–2025: Textiles 8.3%, Electronics 56.25%, Spices 12.5%, Machinery 50%. Electronics is highest."},
        {"q": "By how many percentage points did the share of Textiles in total exports fall between 2023 and 2025? Give your answer to the nearest whole number.", "tita": True, "ans": "7",
         "sol": "Totals: 300 in 2023 and 390 in 2025. Textiles' share fell from 120/300 = 40% to 130/390 = 33.3%, a fall of 6.7 points, which rounds to 7."},
        {"q": "Was the percentage growth in total exports higher in 2024 or in 2025?", "opts": ["2024", "2025", "Equal in both years", "Cannot be determined"], "ans": 1,
         "sol": "Totals: 300, 340, 390. Growth in 2024: 40/300 = 13.3%. Growth in 2025: 50/340 = 14.7%. Higher in 2025, even though the base was larger."},
        {"q": "If Electronics exports grew in 2026 at the same percentage rate as in 2025, what would they be in 2026, in ₹ thousand crore?", "tita": True, "ans": "156.25",
         "sol": "2025 growth = 125/100 − 1 = 25%. 125 × 1.25 = 156.25."},
        {"q": "Approximately what percentage of total exports in 2025 came from Machinery?", "opts": ["19%", "21%", "23%", "25%"], "ans": 2,
         "sol": "90 / 390 = 23.1%."},
     ]},
    {"title": "Set 5",
     "intro": ["Six families, Iyer, Kapoor, Menon, Nair, Rao and Sethi, live in a three-storey building with two flats on each floor, one on the East side and one on the West side. Floor 1 is the lowest. The families have 2, 3, 4, 5, 6 and 7 members, in some order. The following is known:",
               "1. The Iyers live directly above the Nairs, on the same side.",
               "2. The Kapoors and the Menons live on the same floor.",
               "3. The Raos live on floor 1, and the Sethis do not live on the East side.",
               "4. The largest family lives on floor 3 and the smallest on floor 1.",
               "5. The Menon family has 3 more members than the Rao family, and the Nair family is larger than the Iyer family.",
               "6. The two families on floor 2 have 9 members in all."],
     "questions": [
        {"q": "Which family lives directly above the Raos?", "opts": ["Iyer", "Kapoor", "Nair", "Sethi"], "ans": 3,
         "sol": "Kapoor and Menon share a floor, the Raos are on floor 1, and the Iyers sit directly above the Nairs, so the Nairs are on floor 1 with the Raos, the Iyers on floor 2, and Kapoor and Menon on floor 3. The Sethis, also on floor 2, are on the West side, so the Iyers (and the Nairs below them) are on the East. The Raos are on floor 1 West, directly below the Sethis."},
        {"q": "How many members does the Sethi family have?", "tita": True, "ans": "6",
         "sol": "The smallest family (2) is on floor 1 and the largest (7) on floor 3. Menon = Rao + 3, Nair > Iyer and floor 2 (Iyer + Sethi) totals 9. The only assignment that fits is Rao 2, Nair 4, Iyer 3, Sethi 6, Menon 5, Kapoor 7."},
        {"q": "How many people in all live on floor 3?", "tita": True, "ans": "12",
         "sol": "Floor 3 holds the Kapoors (7) and the Menons (5): 12."},
        {"q": "Which family lives on the East side of floor 1?", "opts": ["Rao", "Nair", "Iyer", "Sethi"], "ans": 1,
         "sol": "The Nairs are below the Iyers, who are on the East side of floor 2."},
        {"q": "Which of the following cannot be determined from the information given?", "opts": ["The side on which the Kapoors live", "The floor on which the Iyers live", "The size of the Rao family", "The side on which the Nairs live"], "ans": 0,
         "sol": "Everything is fixed except which of the Kapoors and Menons takes the East flat on floor 3; both arrangements satisfy every clue."},
     ]},
]


def verify():
    assert duration(TASKS) == 26
    slack_ok = [t for t in ("Design", "Permits", "Plumbing", "Wiring") if delayed(t, 2) == 26]
    assert slack_ok == ["Design"]
    assert delayed("Plumbing", 2) == 28
    seq = dict(TASKS, Plumbing=(4, ("Wiring",)))
    seq2 = dict(TASKS, Wiring=(3, ("Plumbing",)))
    assert min(duration(seq), duration(seq2)) == 29

    gs = gift_solutions()
    assert len(gs) == 4
    assert {g["J"] for g in gs} == {"L", "M"}
    assert sum(1 for g in gs if g["K"] == "J") == 2
    nj = [g for g in gs if g["N"] == "J"]
    assert len(nj) == 1 and nj[0]["M"] == "K"

    assert codes(CLUES) == ["739"]
    without_164 = codes({g: v for g, v in CLUES.items() if g != "164"})
    assert sorted(without_164) == ["139", "739"] and [o for o in ("139", "329", "709", "789") if o in without_164] == ["139"]
    good = [g for g in ("731", "379", "794", "973") if score("739", g) == (2, 0)]
    assert good == ["731"]

    growth = {g: Fr(v[2], v[0]) for g, v in EXPORTS.items()}
    assert max(growth, key=growth.get) == "Electronics"
    assert round((Fr(120, 300) - Fr(130, 390)) * 100) == 7
    assert Fr(total(2), total(1)) > Fr(total(1), total(0))
    assert EXPORTS["Electronics"][2] * Fr(EXPORTS["Electronics"][2], EXPORTS["Electronics"][1]) == Fr(15625, 100)
    assert round(Fr(90, total(2)) * 100) == 23

    aps = apartment_solutions()
    assert len(aps) == 2
    for pos, m in aps:
        above_rao = [f for f in FAMILIES if pos[f] == (2, pos["Rao"][1])]
        assert above_rao == ["Sethi"] and m["Sethi"] == 6
        assert sum(m[f] for f in FAMILIES if pos[f][0] == 3) == 12
        assert [f for f in FAMILIES if pos[f] == (1, "East")] == ["Nair"]
    assert len({pos["Kapoor"][1] for pos, _ in aps}) == 2
    assert len({pos["Iyer"][0] for pos, _ in aps}) == 1 and len({m["Rao"] for _, m in aps}) == 1 and len({pos["Nair"][1] for pos, _ in aps}) == 1
    return "DILR: all 22 keys match the solvers"
