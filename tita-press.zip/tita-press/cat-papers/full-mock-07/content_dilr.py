"""Full Mock 07 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import combinations, permutations, product

# ---------- Set 1: logic grid ----------
NAMES = ["Ira", "Jai", "Kavi", "Leela"]

def grid_solutions():
    sols = []
    for city in permutations(["Pune", "Agra", "Goa", "Surat"]):
        c = dict(zip(NAMES, city))
        if c["Ira"] in ("Goa", "Surat") or c["Jai"] == "Pune" or c["Kavi"] == "Pune": continue
        for job in permutations(["doctor", "lawyer", "pilot", "chef"]):
            j = dict(zip(NAMES, job)); by_job = {v: k for k, v in j.items()}
            if c[by_job["pilot"]] != "Agra" or j["Kavi"] in ("doctor", "pilot"): continue
            for sport in permutations(["tennis", "chess", "golf", "swimming"]):
                s = dict(zip(NAMES, sport)); by_sport = {v: k for k, v in s.items()}
                if j[by_sport["chess"]] != "lawyer" or j[by_sport["golf"]] != "doctor": continue
                if c[by_sport["golf"]] != "Surat": continue
                if s["Leela"] == "tennis" or s["Ira"] == "swimming" or s["Jai"] == "golf": continue
                sols.append((c, j, s))
    return sols

# ---------- Set 2: two counters ----------
ARRIVE = (0, 2, 3, 5, 6, 9, 10, 14)
SERVICE = (6, 4, 5, 3, 4, 2, 5, 3)

def simulate(service=SERVICE):
    free = {"X": 0, "Y": 0}
    rows = []
    for a, d in zip(ARRIVE, service):
        counter = min(free, key=lambda k: (max(free[k], a), k))  # first free; X on a tie
        start = max(free[counter], a)
        free[counter] = start + d
        rows.append(dict(counter=counter, start=start, wait=start - a, end=start + d))
    return rows

# ---------- Set 3: pair weights ----------
PAIR_SUMS = (27, 31, 34, 35, 38, 38, 41, 42, 45, 49)

def weight_solutions():
    return [w for w in combinations(range(1, 60), 5) if tuple(sorted(a + b for a, b in combinations(w, 2))) == PAIR_SUMS]

# ---------- Set 4: phone plans ----------
PLANS = {"Basic": (199, 10, 20), "Plus": (299, 20, 15), "Max": (449, 40, 10), "Unlimited": (599, None, 0)}
def bill(plan, gb):
    fee, incl, extra = PLANS[plan]
    return fee if incl is None else fee + max(0, gb - incl) * extra
def cheapest(gb): return min(PLANS, key=lambda p: bill(p, gb))

# ---------- Set 5: coin game ----------
PLAYERS = "FGHMR"

def coin_solutions():
    sols = []
    for wins in product(PLAYERS, repeat=4):
        if any(wins[i] == wins[i + 1] for i in range(3)) or wins[0] == "G": continue
        coins = {p: 6 + 5 * wins.count(p) for p in PLAYERS}  # 10 − 4 losses, +5 for each win instead of a loss
        if coins["F"] != 16 or coins["H"] != 6: continue
        if coins["M"] <= coins["R"] or coins["G"] <= coins["H"]: continue
        sols.append((wins, coins))
    return sols


SETS = [
    {"title": "Set 1",
     "intro": ["Four friends, Ira, Jai, Kavi and Leela, live in four different cities (Pune, Agra, Goa and Surat), have four different jobs (doctor, lawyer, pilot and chef) and each plays a different sport (tennis, chess, golf and swimming). The following is known:",
               "1. The pilot lives in Agra.",
               "2. The chess player is the lawyer, and the golfer is the doctor, who lives in Surat.",
               "3. Ira lives neither in Goa nor in Surat; Jai does not live in Pune; Kavi does not live in Pune.",
               "4. Kavi is neither the doctor nor the pilot.",
               "5. Leela does not play tennis, Ira does not swim, and Jai does not play golf."],
     "questions": [
        {"q": "Who is the pilot?", "opts": ["Ira", "Jai", "Kavi", "Leela"], "ans": 1,
         "sol": "The golfer is the doctor and lives in Surat. That is not Ira (not in Surat), not Jai (doesn't play golf) and not Kavi (not the doctor), so it is Leela. Pune is then Ira's, since Jai and Kavi are not in Pune. Jai and Kavi share Agra and Goa; the pilot lives in Agra and Kavi is not the pilot, so Kavi is in Goa and Jai in Agra. Jai is the pilot."},
        {"q": "In which city does Kavi live?", "opts": ["Pune", "Agra", "Goa", "Surat"], "ans": 2,
         "sol": "From the reasoning above: Ira in Pune, Jai in Agra, Kavi in Goa, Leela in Surat."},
        {"q": "How many complete assignments of city, job and sport satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "Fixed: Leela (Surat, doctor, golf) and Jai (Agra, pilot). Ira and Kavi share lawyer and chef; the lawyer plays chess. If Ira is the lawyer (chess), Jai and Kavi split tennis and swimming either way: 2 assignments. If Kavi is the lawyer, Ira (who doesn't swim) plays tennis and Jai swims: 1 more. Three in all."},
        {"q": "If Ira plays tennis, what is Kavi's job?", "opts": ["Doctor", "Lawyer", "Pilot", "Chef"], "ans": 1,
         "sol": "If Ira plays tennis, Ira is not the chess player, so Ira is not the lawyer. The lawyer must be Kavi."},
     ]},
    {"title": "Set 2",
     "intro": ["A bank opens two counters, X and Y, at 10:00. Eight customers arrive during the morning. Customers are served in order of arrival; each goes to whichever counter becomes free first, and if both are free (or become free at the same moment) the customer goes to counter X. The table shows each customer's arrival time, in minutes after 10:00, and the time their service takes."],
     "table": {"head": ["Customer", *[str(i) for i in range(1, 9)]],
               "rows": [["Arrives (min)", *map(str, ARRIVE)], ["Service (min)", *map(str, SERVICE)]]},
     "questions": [
        {"q": "What was the total time, in minutes, that the eight customers spent waiting before being served?", "tita": True, "ans": "12",
         "sol": "Following the rule: 1 at X 0–6; 2 at Y 2–6; 3 at X 6–11 (waits 3); 4 at Y 6–9 (waits 1); 5 at Y 9–13 (waits 3); 6 at X 11–13 (waits 2); 7 at X 13–18 (waits 3, counters tie at 13); 8 at Y 14–17 (no wait). Total 3 + 1 + 3 + 2 + 3 = 12."},
        {"q": "How many of the eight customers had to wait before being served?", "opts": ["3", "4", "5", "6"], "ans": 2,
         "sol": "Customers 3, 4, 5, 6 and 7 waited; 1, 2 and 8 did not. Five."},
        {"q": "How many minutes after 10:00 did the last customer finish being served?", "tita": True, "ans": "18",
         "sol": "Customer 7 is served at X from 13 to 18; customer 8 finishes at 17. The last service ends at 10:18."},
        {"q": "Which customers were served at counter X?", "opts": ["1, 3, 6 and 7", "1, 3, 5 and 7", "1, 4, 6 and 8", "1, 3, 6 and 8"], "ans": 0,
         "sol": "From the timeline above, X served 1, 3, 6 and 7."},
        {"q": "If customer 1's service had taken 3 minutes instead of 6, what would the total waiting time have been, in minutes?", "tita": True, "ans": "4",
         "sol": "Now 1 at X 0–3; 2 at Y 2–6; 3 at X 3–8 (no wait); 4 at Y 6–9 (waits 1); 5 at X 8–12 (waits 2); 6 at Y 9–11; 7 at Y 11–16 (waits 1); 8 at X 14–17. Total 1 + 2 + 1 = 4."},
     ]},
    {"title": "Set 3",
     "intro": ["Five boxes have different weights, each a whole number of kilograms. The boxes were weighed two at a time in every possible pair, and the ten totals, in kilograms and in no particular order, were: 27, 31, 34, 35, 38, 38, 41, 42, 45, 49."],
     "questions": [
        {"q": "What is the total weight of the five boxes, in kg?", "tita": True, "ans": "95",
         "sol": "Each box appears in four of the ten pairs, so the ten totals add to 4 × (total weight). 380 / 4 = 95 kg."},
        {"q": "What is the weight of the heaviest box, in kg?", "tita": True, "ans": "26",
         "sol": "The lightest pair (27) is the two lightest boxes and the heaviest pair (49) the two heaviest. The middle box is 95 − 27 − 49 = 19. The second-lightest total, 31, is lightest + middle, so the lightest is 12 and the second is 15; the second-heaviest total, 45, is middle + heaviest, so the heaviest is 26 and the fourth is 23."},
        {"q": "What is the weight of the second-lightest box, in kg?", "opts": ["12", "15", "19", "23"], "ans": 1,
         "sol": "The weights are 12, 15, 19, 23 and 26."},
        {"q": "How many different pairs of boxes together weigh 38 kg?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "12 + 26 = 38 and 15 + 23 = 38: two pairs."},
     ]},
    {"title": "Set 4",
     "intro": ["A mobile company offers four monthly plans. Each includes some data; data beyond that is charged per GB (part GBs are not charged, as usage is billed in whole GB)."],
     "table": {"head": ["Plan", "Monthly fee (₹)", "Data included", "Extra data (₹ per GB)"],
               "rows": [["Basic", "199", "10 GB", "20"], ["Plus", "299", "20 GB", "15"], ["Max", "449", "40 GB", "10"], ["Unlimited", "599", "Unlimited", "–"]]},
     "questions": [
        {"q": "Which plan is cheapest for a customer who uses 25 GB in a month?", "opts": ["Basic", "Plus", "Max", "Unlimited"], "ans": 1,
         "sol": "Basic: 199 + 15 × 20 = 499. Plus: 299 + 5 × 15 = 374. Max: 449. Unlimited: 599. Plus is cheapest."},
        {"q": "What is the smallest whole number of GB per month for which Max costs less than Plus?", "tita": True, "ans": "31",
         "sol": "Up to 40 GB, Max costs 449. Plus costs 299 + 15(g − 20), which exceeds 449 when g − 20 > 10, i.e. g > 30. At 31 GB, Plus costs 464 and Max 449."},
        {"q": "What is the smallest whole number of GB per month for which Unlimited costs less than Max?", "tita": True, "ans": "56",
         "sol": "Above 40 GB, Max costs 449 + 10(g − 40), which exceeds 599 when g − 40 > 15, i.e. g > 55. At 56 GB, Max costs 609."},
        {"q": "Three members of a family use 15 GB, 25 GB and 45 GB a month, and each chooses the cheapest plan for their own usage. What is the family's total monthly bill, in rupees?", "tita": True, "ans": "1172",
         "sol": "15 GB: Basic 299 and Plus 299 tie at ₹299. 25 GB: Plus ₹374. 45 GB: Max 449 + 50 = ₹499 (Plus 674, Unlimited 599). Total 299 + 374 + 499 = ₹1,172."},
     ]},
    {"title": "Set 5",
     "intro": ["Five players, F, G, H, M and R, start a game with 10 coins each and play four rounds. Each round has exactly one winner, and every other player gives the winner one coin. The following is known:",
               "1. Nobody won two consecutive rounds, and G did not win the first round.",
               "2. At the end, F had 16 coins and H had 6.",
               "3. At the end, M had more coins than R, and G had more coins than H."],
     "questions": [
        {"q": "How many rounds did F win?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "A player who wins w of the four rounds ends with 10 + 4w − (4 − w) = 6 + 5w coins. F's 16 means w = 2; H's 6 means w = 0."},
        {"q": "How many players finished with exactly 11 coins?", "opts": ["0", "1", "2", "3"], "ans": 2,
         "sol": "The remaining two wins go to G (who beats H, so won at least once) and M (who beats R): one each, so G and M finish with 11 and R with 6. Two players have 11."},
        {"q": "In how many different orders could the four rounds have been won?", "tita": True, "ans": "5",
         "sol": "Arrange F, F, G, M with the two F's apart and G not first. F in rounds 1 and 3: FGFM, FMFG. F in rounds 1 and 4: FGMF, FMGF. F in rounds 2 and 4: MFGF (GFMF has G first). Five orders."},
        {"q": "If M won the last round, who won the second round?", "opts": ["F", "G", "H", "M"], "ans": 1,
         "sol": "M winning round 4 leaves only FGFM, so G won round 2."},
        {"q": "Which of the following statements must be true?", "opts": ["F won the first round.", "G won the third round.", "R won no rounds.", "M won the second round."], "ans": 2,
         "sol": "R ends with 6 coins (no wins) in every case. F won round 1 in four of the five orders but not in MFGF; the others also fail in some order."},
     ]},
]


def verify():
    gs = grid_solutions()
    assert len(gs) == 3
    assert all({v: k for k, v in j.items()}["pilot"] == "Jai" and c["Kavi"] == "Goa" for c, j, _ in gs)
    assert {j["Kavi"] for c, j, s in gs if s["Ira"] == "tennis"} == {"lawyer"}

    rows = simulate()
    assert sum(r["wait"] for r in rows) == 12 and sum(1 for r in rows if r["wait"]) == 5
    assert max(r["end"] for r in rows) == 18
    assert [i + 1 for i, r in enumerate(rows) if r["counter"] == "X"] == [1, 3, 6, 7]
    assert sum(r["wait"] for r in simulate((3,) + SERVICE[1:])) == 4

    ws = weight_solutions()
    assert ws == [(12, 15, 19, 23, 26)] and sum(ws[0]) == 95
    assert sum(1 for a, b in combinations(ws[0], 2) if a + b == 38) == 2

    assert cheapest(25) == "Plus"
    assert next(g for g in range(100) if bill("Max", g) < bill("Plus", g)) == 31
    assert next(g for g in range(100) if bill("Unlimited", g) < bill("Max", g)) == 56
    assert sum(min(bill(p, g) for p in PLANS) for g in (15, 25, 45)) == 1172

    cs = coin_solutions()
    assert len(cs) == 5
    assert all(w.count("F") == 2 and sum(1 for v in c.values() if v == 11) == 2 and w.count("R") == 0 for w, c in cs)
    assert {w[1] for w, _ in cs if w[3] == "M"} == {"G"}
    assert not all(w[0] == "F" for w, _ in cs) and not all(w[2] == "G" for w, _ in cs) and not all(w[1] == "M" for w, _ in cs)
    return "DILR: all 22 keys match the solvers"
