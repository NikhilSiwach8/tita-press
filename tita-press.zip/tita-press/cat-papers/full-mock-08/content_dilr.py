"""Full Mock 08 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations, product

# ---------- Set 1: map colouring ----------
REGIONS = "PQRSTU"
BORDERS = [("P", "Q"), ("P", "R"), ("Q", "R"), ("Q", "S"), ("R", "S"), ("R", "T"), ("S", "T"), ("S", "U"), ("T", "U")]

def colourings(colours, extra=lambda d: True):
    out = []
    for c in product(colours, repeat=len(REGIONS)):
        d = dict(zip(REGIONS, c))
        if all(d[a] != d[b] for a, b in BORDERS) and extra(d):
            out.append(d)
    return out

# ---------- Set 2: trains ----------
STATIONS = {"Kota": 0, "Lohar": 60, "Mandi": 150, "Neral": 240}

def slow_train(t):
    """Position (km from Kota) of the stopping train t minutes after 08:00: 60 km/h, 10-minute halts at Lohar and Mandi."""
    if t <= 60: return Fr(t)
    if t <= 70: return Fr(60)
    if t <= 160: return Fr(60 + (t - 70))
    if t <= 170: return Fr(150)
    return min(Fr(150 + (t - 170)), Fr(240))

def fast_train(t, start=30):
    """Position of the express from Neral (90 km/h, no stops) leaving `start` minutes after 08:00."""
    return Fr(240) - Fr(3, 2) * max(0, t - start)

def crossing(start=30):
    t = Fr(0)
    step = Fr(1, 60)
    while slow_train(t) < fast_train(t, start):
        t += step
    return t, slow_train(t)

# ---------- Set 3: heights ----------
ATHLETES = "FGHJKL"

def height_orders():
    out = []
    for perm in permutations(ATHLETES):  # tallest first
        r = {p: i for i, p in enumerate(perm)}
        if not r["H"] < r["F"] < r["G"]: continue
        if not r["J"] > r["G"] or not r["K"] < r["F"]: continue
        if not r["F"] < r["L"] < r["J"] or r["H"] == 0: continue
        out.append("".join(perm))
    return out

# ---------- Set 4: salaries ----------
SALARY = {"Asha": (600000, 10, 8), "Bilal": (720000, 5, 12), "Chen": (540000, 15, 10), "Dina": (800000, 0, 10), "Eshan": (650000, 12, 6)}
def pay(name, year):  # year 0 = 2024, 1 = 2025, 2 = 2026
    base, h1, h2 = SALARY[name]
    s = Fr(base)
    if year >= 1: s *= Fr(100 + h1, 100)
    if year >= 2: s *= Fr(100 + h2, 100)
    return s
def payroll(year): return sum(pay(n, year) for n in SALARY)

# ---------- Set 5: birthdays ----------
FRIENDS = "PQRST"
MONTHS = ["January", "February", "March", "April", "May", "June"]

def birthday_solutions():
    sols = []
    for m in permutations(range(6), 5):
        mo = dict(zip(FRIENDS, m))
        if 3 in m or mo["P"] >= mo["Q"] or abs(mo["R"] - mo["S"]) != 1 or mo["T"] != 5: continue
        for c in permutations(["Delhi", "Kochi", "Pune", "Agra", "Surat"]):
            ci = dict(zip(FRIENDS, c)); who = {v: k for k, v in ci.items()}
            if mo[who["Kochi"]] != 2 or ci["P"] in ("Kochi", "Agra", "Pune"): continue
            if mo[who["Pune"]] <= mo[who["Surat"]] or ci["T"] == "Delhi" or ci["S"] != "Agra": continue
            sols.append((mo, ci))
    return sols


SETS = [
    {"title": "Set 1",
     "intro": ["A map shows six regions, P, Q, R, S, T and U. The pairs of regions that share a border are: P–Q, P–R, Q–R, Q–S, R–S, R–T, S–T, S–U and T–U. The map is to be coloured so that regions sharing a border never have the same colour."],
     "questions": [
        {"q": "In how many different ways can the map be coloured using red, green and blue (not every colour need be used)?", "tita": True, "ans": "6",
         "sol": "P, Q and R all border one another, so they take three different colours: 3 × 2 × 1 = 6 ways. S borders Q and R, so it must match P; T borders R and S, so it matches Q; U borders S and T, so it matches R. Each choice for P, Q and R fixes the rest: 6 colourings."},
        {"q": "Which of the following pairs of regions must always have the same colour when only three colours are used?", "opts": ["P and S", "P and T", "Q and U", "R and T"], "ans": 0,
         "sol": "From the reasoning above, S always matches P, T matches Q and U matches R."},
        {"q": "If P is red and U is not blue, what colour is T?", "opts": ["Red", "Green", "Blue", "Cannot be determined"], "ans": 2,
         "sol": "U matches R, so R is not blue; R is not red (P is red), so R is green and Q is blue. T matches Q: blue."},
        {"q": "If a fourth colour, yellow, is also available (and not every colour need be used), in how many ways can the map be coloured?", "tita": True, "ans": "192",
         "sol": "P, Q, R take three different colours: 4 × 3 × 2 = 24 ways. S must differ from Q and R: 2 choices. T must differ from R and S: 2 choices. U must differ from S and T: 2 choices. 24 × 8 = 192."},
     ]},
    {"title": "Set 2",
     "intro": ["Four stations lie on a straight railway line: Kota (0 km), Lohar (60 km), Mandi (150 km) and Neral (240 km). A passenger train leaves Kota at 08:00 for Neral, running at 60 km/h and halting for 10 minutes each at Lohar and Mandi. An express leaves Neral at 08:30 for Kota, running at 90 km/h without stopping. Ignore the time taken to speed up and slow down."],
     "questions": [
        {"q": "At what time does the passenger train reach Neral?", "opts": ["11:50", "12:00", "12:10", "12:20"], "ans": 3,
         "sol": "Kota to Lohar: 60 km, 1 hour (09:00), depart 09:10. Lohar to Mandi: 90 km, 1.5 hours (10:40), depart 10:50. Mandi to Neral: 90 km, 1.5 hours: 12:20."},
        {"q": "At what time do the two trains pass each other?", "opts": ["09:46", "09:52", "09:58", "10:04"], "ans": 2,
         "sol": "The express is at Mandi at 09:30 and Lohar at 10:30, so they meet between Lohar and Mandi. t minutes after 08:00, the passenger train (after its halt) is at 60 + (t − 70) km and the express at 240 − 1.5(t − 30) km. Equal when 2.5t = 295, t = 118: 09:58."},
        {"q": "How far from Kota, in km, do the two trains pass each other?", "tita": True, "ans": "108",
         "sol": "At t = 118 minutes the passenger train is at 60 + 48 = 108 km from Kota."},
        {"q": "If the express had left Neral at 09:00 instead of 08:30, how far from Kota, in km, would the trains have passed each other?", "tita": True, "ans": "126",
         "sol": "Now the express is at 240 − 1.5(t − 60). Setting 60 + (t − 70) equal to it gives 2.5t = 340, so t = 136 minutes after 08:00, i.e. 10:16. The passenger train is then at 60 + 66 = 126 km, still short of Mandi."},
     ]},
    {"title": "Set 3",
     "intro": ["Six athletes, F, G, H, J, K and L, all have different heights. The following is known:",
               "1. F is taller than G but shorter than H.",
               "2. J is shorter than G.",
               "3. K is taller than F.",
               "4. L is taller than J but shorter than F.",
               "5. H is not the tallest of the six."],
     "questions": [
        {"q": "Who is the tallest?", "opts": ["F", "H", "K", "L"], "ans": 2,
         "sol": "H, K are taller than F; F is taller than G, L and J; J is shorter than both G and L. H is not the tallest, so K is. The order, tallest first, is K, H, F, then G and L in some order, then J."},
        {"q": "Who is the third tallest?", "opts": ["F", "G", "H", "L"], "ans": 0,
         "sol": "K and H are above F, and everyone else is below F, so F is third."},
        {"q": "How many different height orders are consistent with the information?", "tita": True, "ans": "2",
         "sol": "Only G and L can swap: K H F G L J or K H F L G J."},
        {"q": "If L is taller than G, how many of the six are shorter than L?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "The order is K H F L G J, so G and J, two athletes, are shorter than L."},
     ]},
    {"title": "Set 4",
     "intro": ["The table shows five employees' annual salaries in 2024 and the percentage increases they received in 2025 and in 2026. Each increase applies to the previous year's salary."],
     "table": {"head": ["Employee", "2024 salary (₹)", "Increase in 2025", "Increase in 2026"],
               "rows": [["Asha", "6,00,000", "10%", "8%"], ["Bilal", "7,20,000", "5%", "12%"], ["Chen", "5,40,000", "15%", "10%"],
                        ["Dina", "8,00,000", "0%", "10%"], ["Eshan", "6,50,000", "12%", "6%"]]},
     "questions": [
        {"q": "Who earned the highest salary in 2026?", "opts": ["Asha", "Bilal", "Dina", "Eshan"], "ans": 2,
         "sol": "2026 salaries: Asha 7,12,800; Bilal 8,46,720; Chen 6,83,100; Dina 8,80,000; Eshan 7,71,680. Dina is highest."},
        {"q": "Whose salary rose by the largest amount in rupees from 2024 to 2026?", "opts": ["Asha", "Bilal", "Chen", "Eshan"], "ans": 2,
         "sol": "Increases: Asha 1,12,800; Bilal 1,26,720; Chen 1,43,100; Dina 80,000; Eshan 1,21,680. Chen's is largest, despite the lowest starting salary."},
        {"q": "By what percentage did the five salaries' total rise from 2024 to 2026? Give your answer to the nearest whole number.", "tita": True, "ans": "18",
         "sol": "Totals: 33,10,000 in 2024 and 38,94,300 in 2026. 38,94,300 / 33,10,000 = 1.1765, a rise of 17.65%, which rounds to 18."},
        {"q": "For how many of the five employees did the salary rise by more than 18% over the two years?", "opts": ["1", "2", "3", "4"], "ans": 2,
         "sol": "Two-year rises: Asha 1.10 × 1.08 = 18.8%; Bilal 1.05 × 1.12 = 17.6%; Chen 1.15 × 1.10 = 26.5%; Dina 10%; Eshan 1.12 × 1.06 = 18.72%. Asha, Chen and Eshan: three."},
        {"q": "If, instead, every employee had received the same percentage increase in 2026, what percentage would have produced the same total for 2026? Give your answer to one decimal place.", "tita": True, "ans": "9.2",
         "sol": "The 2025 total is 35,65,000 and the 2026 total 38,94,300. 38,94,300 / 35,65,000 = 1.0924, an increase of 9.2%."},
     ]},
    {"title": "Set 5",
     "intro": ["Five friends, P, Q, R, S and T, were born in five different months between January and June of the same year, and each comes from a different city: Delhi, Kochi, Pune, Agra or Surat. The following is known:",
               "1. Nobody was born in April. T was born in June.",
               "2. P was born before Q.",
               "3. R and S were born in consecutive months.",
               "4. The friend from Kochi was born in March, and P is not from Kochi.",
               "5. The friend from Pune was born after the friend from Surat.",
               "6. S is from Agra, P is from neither Agra nor Pune, and T is not from Delhi."],
     "questions": [
        {"q": "Who was born in March?", "opts": ["P", "Q", "R", "S"], "ans": 2,
         "sol": "P, Q, R and S use January, February, March and May. R and S are consecutive: January–February or February–March. If January–February, P and Q take March and May, so P (earlier) is born in March and would be from Kochi, which is ruled out. So R and S take February and March, P January and Q May. The March friend is from Kochi; S is from Agra, so R was born in March and S in February."},
        {"q": "Who was born in February?", "opts": ["P", "Q", "R", "S"], "ans": 3,
         "sol": "From the reasoning above, S was born in February."},
        {"q": "Which city is T from?", "opts": ["Delhi", "Pune", "Agra", "Surat"], "ans": 1,
         "sol": "T is not from Delhi, Kochi (R) or Agra (S). If T were from Surat, the Pune friend would have to be born after June, which is impossible. So T is from Pune."},
        {"q": "How many complete arrangements of months and cities satisfy all the conditions?", "tita": True, "ans": "2",
         "sol": "Months are fixed (P Jan, S Feb, R Mar, Q May, T Jun), as are R (Kochi), S (Agra) and T (Pune). P and Q take Delhi and Surat in either order; both satisfy clue 5, since the Pune friend (T, June) is born after either. Two arrangements."},
        {"q": "Which of the following cannot be determined?", "opts": ["The city Q is from", "The month in which P was born", "The city R is from", "The month in which T was born"], "ans": 0,
         "sol": "Q could be from Delhi or Surat. Everything else is fixed."},
     ]},
]


def verify():
    assert len(colourings("RGB")) == 6
    for d in colourings("RGB"):
        assert d["P"] == d["S"] and d["Q"] == d["T"] and d["R"] == d["U"]
    assert {d["T"] for d in colourings("RGB", lambda d: d["P"] == "R" and d["U"] != "B")} == {"B"}
    assert len(colourings("RGBY")) == 192

    arrive = next(t for t in range(170, 400) if slow_train(t) == 240)
    assert arrive == 260  # 12:20
    t, pos = crossing()
    assert t == 118 and pos == 108
    t2, pos2 = crossing(start=60)
    assert t2 == 136 and pos2 == 126

    hs = height_orders()
    assert sorted(hs) == ["KHFGLJ", "KHFLGJ"]
    assert all(h[0] == "K" and h[2] == "F" for h in hs)
    assert [h for h in hs if h.index("L") < h.index("G")] == ["KHFLGJ"]

    assert max(SALARY, key=lambda n: pay(n, 2)) == "Dina"
    assert max(SALARY, key=lambda n: pay(n, 2) - pay(n, 0)) == "Chen"
    assert round((payroll(2) / payroll(0) - 1) * 100) == 18
    assert sum(1 for n in SALARY if pay(n, 2) / pay(n, 0) > Fr(118, 100)) == 3
    assert round(float(payroll(2) / payroll(1) - 1) * 100, 1) == 9.2

    bs = birthday_solutions()
    assert len(bs) == 2
    for mo, ci in bs:
        assert MONTHS[mo["R"]] == "March" and MONTHS[mo["S"]] == "February" and ci["T"] == "Pune"
    assert len({ci["Q"] for _, ci in bs}) == 2 and len({mo["P"] for mo, _ in bs}) == 1
    return "DILR: all 22 keys match the solvers"
