"""Full Mock 09 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from collections import deque
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: 4 × 4 grid ----------
def grid_solutions():
    rows = list(permutations((1, 2, 3, 4)))
    sols = []
    for a in rows:
        for b in rows:
            if any(a[i] == b[i] for i in range(4)): continue
            for c in rows:
                if any(c[i] in (a[i], b[i]) for i in range(4)): continue
                d = tuple(10 - a[i] - b[i] - c[i] for i in range(4))
                if sorted(d) != [1, 2, 3, 4]: continue
                g = (a, b, c, d)
                if g[0][0] != 1 or g[1][1] != 4 or g[2][3] != 1 or g[0][3] + g[3][0] != 6: continue
                sols.append(g)
    return sols

# ---------- Set 2: workers and machines ----------
HOURS = {"Faiz": (7, 9, 8, 5), "Gita": (6, 8, 5, 9), "Hari": (5, 6, 9, 8), "Jaya": (8, 7, 6, 5)}
WORKERS = list(HOURS)

def assignments(allowed=lambda p: True):
    return sorted((sum(HOURS[w][m] for w, m in zip(WORKERS, p)), p) for p in permutations(range(4)) if allowed(p))

# ---------- Set 3: rumour ----------
FRIENDS = [("P", "Q"), ("P", "R"), ("Q", "S"), ("R", "S"), ("R", "T"), ("S", "U"), ("T", "U"), ("U", "V"), ("T", "W")]

def days_to_hear(edges, start="P"):
    g = {}
    for a, b in edges:
        g.setdefault(a, []).append(b); g.setdefault(b, []).append(a)
    d = {start: 0}; q = deque([start])
    while q:
        x = q.popleft()
        for y in g.get(x, []):
            if y not in d:
                d[y] = d[x] + 1; q.append(y)
    return d

# ---------- Set 4: currency ----------
RATE = {"GBP": 105, "EUR": 90, "SGD": 62}
STAYS = [("London", "GBP", 120, 3), ("Paris", "EUR", 150, 2), ("Singapore", "SGD", 200, 2)]
def stay_inr(rate=RATE): return {city: n * price * rate[cur] for city, cur, price, n in STAYS}

# ---------- Set 5: marks histogram ----------
BANDS = [((0, 9), 4), ((10, 19), 7), ((20, 29), 12), ((30, 39), 10), ((40, 50), 7)]


SETS = [
    {"title": "Set 1",
     "intro": ["The numbers 1, 2, 3 and 4 are written in a 4 × 4 grid so that each appears exactly once in every row and every column. Rows are numbered 1 to 4 from top to bottom and columns 1 to 4 from left to right. The following is known:",
               "1. Row 1, column 1 contains 1.",
               "2. Row 2, column 2 contains 4.",
               "3. Row 3, column 4 contains 1.",
               "4. The numbers in the top-right and bottom-left corners add up to 6."],
     "questions": [
        {"q": "In how many ways can the grid be completed?", "tita": True, "ans": "2",
         "sol": "Column 1 has 1 on top; the corners sum to 6, so they are 2 and 4 or 4 and 2. Working through the rows with each number once per row and column leaves two grids (rows top to bottom): 1234 / 3412 / 4321 / 2143 and 1324 / 3412 / 4231 / 2143. They differ only in the middle two cells of rows 1 and 3."},
        {"q": "Which number is in row 4, column 3?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "Row 4 is 2 1 4 3 in both grids, so row 4, column 3 holds 4."},
        {"q": "Which of the following must be true?", "opts": ["Row 2 reads 3, 4, 1, 2 from left to right.", "Row 1, column 2 contains 2.", "Row 3, column 2 contains 2.", "Row 1, column 3 contains 2."], "ans": 0,
         "sol": "Row 2 is 3 4 1 2 in both grids. Each of the other cells differs between the two grids."},
        {"q": "If the diagonal from the top-left to the bottom-right corner contains four different numbers, what is in row 1, column 3?", "opts": ["1", "2", "3", "4"], "ans": 2,
         "sol": "The diagonals are 1, 4, 2, 3 in the first grid and 1, 4, 3, 3 in the second. Only the first qualifies, and its row 1, column 3 holds 3."},
     ]},
    {"title": "Set 2",
     "intro": ["Four workers, Faiz, Gita, Hari and Jaya, are to be assigned to four machines, M1 to M4, one worker per machine. The table gives the number of hours each worker would take to complete the day's job on each machine. The total time is the sum of the four workers' hours."],
     "table": {"head": ["Worker", "M1", "M2", "M3", "M4"],
               "rows": [[w, *map(str, h)] for w, h in HOURS.items()]},
     "questions": [
        {"q": "What is the smallest possible total time, in hours?", "tita": True, "ans": "22",
         "sol": "Each worker's fastest machine: Faiz M4 (5), Gita M3 (5), Hari M1 (5), Jaya M4 (5). Faiz and Jaya clash. Giving M4 to Faiz and M2 to Jaya costs 5 + 5 + 5 + 7 = 22; giving M4 to Jaya forces Faiz onto M2 (9) for 5 + 5 + 5 + 9 = 24, or other rearrangements that cost more. Checking all 24 assignments confirms 22 is the minimum, achieved only by Faiz–M4, Gita–M3, Hari–M1, Jaya–M2."},
        {"q": "In the assignment with the smallest total time, which machine does Jaya operate?", "opts": ["M1", "M2", "M3", "M4"], "ans": 1,
         "sol": "Faiz takes M4, Gita M3, Hari M1, leaving Jaya on M2 (7 hours)."},
        {"q": "If Gita cannot operate M3, what is the smallest possible total time, in hours?", "opts": ["22", "23", "24", "25"], "ans": 1,
         "sol": "The best assignment without Gita on M3 is Faiz–M4 (5), Gita–M1 (6), Hari–M2 (6), Jaya–M3 (6): 23 hours."},
        {"q": "What is the largest possible total time, in hours?", "tita": True, "ans": "35",
         "sol": "The worst assignment is Faiz–M2 (9), Gita–M4 (9), Hari–M3 (9), Jaya–M1 (8): 35 hours."},
        {"q": "How many different assignments give a total time of exactly 23 hours?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "Two: Faiz–M1, Gita–M3, Hari–M2, Jaya–M4 (7 + 5 + 6 + 5) and Faiz–M4, Gita–M1, Hari–M2, Jaya–M3 (5 + 6 + 6 + 6)."},
     ]},
    {"title": "Set 3",
     "intro": ["Eight people, P, Q, R, S, T, U, V and W, are linked by the following friendships: P–Q, P–R, Q–S, R–S, R–T, S–U, T–U, U–V and T–W. On day 0, P hears a rumour. Each day, everyone who already knows the rumour tells all of their friends, who then know it from that day on."],
     "questions": [
        {"q": "On which day does the last of the eight people hear the rumour?", "tita": True, "ans": "4",
         "sol": "Day 1: Q, R. Day 2: S (from Q or R), T (from R). Day 3: U (from S or T), W (from T). Day 4: V (from U)."},
        {"q": "Who is the last person to hear the rumour?", "opts": ["U", "V", "W", "S"], "ans": 1,
         "sol": "V hears on day 4; everyone else has heard by day 3."},
        {"q": "If the friendship between P and R did not exist, on which day would W hear the rumour?", "opts": ["3", "4", "5", "6"], "ans": 2,
         "sol": "Now the rumour goes P → Q (day 1) → S (day 2) → R and U (day 3) → T (day 4) → W (day 5)."},
        {"q": "Which single friendship, if it did not exist, would leave someone who never hears the rumour?", "opts": ["Q–S", "R–S", "S–U", "U–V"], "ans": 3,
         "sol": "V's only friend is U, so without U–V, V never hears it. Each of the other friendships has an alternative route around it."},
     ]},
    {"title": "Set 4",
     "intro": ["A traveller books hotels in three cities. The exchange rates and bookings are shown below. Assume these rates hold throughout."],
     "table": {"head": ["City", "Currency", "₹ per unit", "Room rate per night", "Nights"],
               "rows": [["London", "Pound (GBP)", "105", "120", "3"], ["Paris", "Euro (EUR)", "90", "150", "2"], ["Singapore", "Singapore dollar (SGD)", "62", "200", "2"]]},
     "questions": [
        {"q": "What is the total cost of the three hotel stays, in rupees?", "tita": True, "ans": "89600",
         "sol": "London 3 × 120 × 105 = 37,800; Paris 2 × 150 × 90 = 27,000; Singapore 2 × 200 × 62 = 24,800. Total ₹89,600."},
        {"q": "In which city is the cost of one night the highest, in rupees?", "opts": ["London", "Paris", "Singapore", "Equal in London and Paris"], "ans": 1,
         "sol": "Per night: London 12,600, Paris 13,500, Singapore 12,400. Paris is highest."},
        {"q": "If the traveller's card adds a 3.5% fee to every foreign payment, how much in rupees will the fees on the three stays come to?", "tita": True, "ans": "3136",
         "sol": "3.5% of ₹89,600 = ₹3,136."},
        {"q": "If the rupee weakened by 5% against the euro only (so that a euro cost ₹94.50), by how many rupees would the total cost of the stays rise?", "opts": ["900", "1,350", "1,890", "4,480"], "ans": 1,
         "sol": "Only the Paris stay is in euros: 300 euros × ₹4.50 more per euro = ₹1,350."},
     ]},
    {"title": "Set 5",
     "intro": ["In a test marked out of 50, every one of 40 students scored a whole number of marks. The table shows how many students scored in each band."],
     "table": {"head": ["Marks", "0–9", "10–19", "20–29", "30–39", "40–50"],
               "rows": [["Students", *[str(n) for _, n in BANDS]]]},
     "questions": [
        {"q": "What is the largest possible total of the 40 students' marks?", "tita": True, "ans": "1257",
         "sol": "Give everyone the top of their band: 4 × 9 + 7 × 19 + 12 × 29 + 10 × 39 + 7 × 50 = 36 + 133 + 348 + 390 + 350 = 1,257."},
        {"q": "What is the smallest possible class average?", "opts": ["20.5", "22.25", "23", "24.75"], "ans": 1,
         "sol": "Give everyone the bottom of their band: 0 + 70 + 240 + 300 + 280 = 890, and 890 / 40 = 22.25."},
        {"q": "In which band do the middle two scores (the 20th and 21st when sorted) lie?", "opts": ["10–19", "20–29", "30–39", "40–50"], "ans": 1,
         "sol": "From the bottom, the first two bands hold 11 students, and the third brings the count to 23. The 20th and 21st scores are in the 20–29 band."},
        {"q": "What percentage of the students scored 30 or more?", "tita": True, "ans": "42.5",
         "sol": "10 + 7 = 17 students out of 40: 42.5%."},
        {"q": "If the class average was exactly 31, what is the smallest possible total of the marks scored by the 7 students in the 40–50 band?", "tita": True, "ans": "333",
         "sol": "The class total is 31 × 40 = 1,240. The other 33 students can score at most 36 + 133 + 348 + 390 = 907. So the top band needs at least 1,240 − 907 = 333, which is possible (it is between 7 × 40 = 280 and 7 × 50 = 350)."},
     ]},
]


def verify():
    gs = grid_solutions()
    assert len(gs) == 2
    assert all(g[3][2] == 4 and g[1] == (3, 4, 1, 2) for g in gs)
    assert len({g[0][1] for g in gs}) == 2 and len({g[2][1] for g in gs}) == 2 and len({g[0][2] for g in gs}) == 2
    diag = [g for g in gs if len({g[i][i] for i in range(4)}) == 4]
    assert len(diag) == 1 and diag[0][0][2] == 3

    best = assignments()
    assert best[0][0] == 22 and best[1][0] > 22
    assert best[0][1] == (3, 2, 0, 1)  # Faiz M4, Gita M3, Hari M1, Jaya M2
    assert assignments(lambda p: p[1] != 2)[0][0] == 23
    assert best[-1][0] == 35
    assert sum(1 for t, _ in best if t == 23) == 2

    d = days_to_hear(FRIENDS)
    assert max(d.values()) == 4 and [k for k, v in d.items() if v == 4] == ["V"]
    assert days_to_hear([e for e in FRIENDS if e != ("P", "R")])["W"] == 5
    cut = [e for e in [("Q", "S"), ("R", "S"), ("S", "U"), ("U", "V")] if len(days_to_hear([x for x in FRIENDS if x != e])) < 8]
    assert cut == [("U", "V")]

    cost = stay_inr()
    assert sum(cost.values()) == 89600
    per_night = {city: price * RATE[cur] for city, cur, price, _ in STAYS}
    assert max(per_night, key=per_night.get) == "Paris"
    assert Fr(35, 1000) * 89600 == 3136
    assert sum(stay_inr(dict(RATE, EUR=Fr(189, 2))).values()) - 89600 == 1350

    hi = sum(b[1] * n for b, n in BANDS); lo = sum(b[0] * n for b, n in BANDS)
    assert hi == 1257 and Fr(lo, 40) == Fr(2225, 100)
    cum, band = 0, None
    for (b, n) in BANDS:
        cum += n
        if band is None and cum >= 21: band = b
    assert band == (20, 29)
    assert Fr(17, 40) * 100 == Fr(425, 10)
    rest_max = sum(b[1] * n for b, n in BANDS[:-1])
    assert 31 * 40 - rest_max == 333 and 280 <= 333 <= 350
    return "DILR: all 22 keys match the solvers"
