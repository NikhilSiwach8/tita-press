# Full Mock 10 — design notes (work in progress, nothing built yet)

Only the DILR set designs below exist. VARC, QA, paper.py and the content_*.py files are still to be written.

## DILR sets (explored with a scratch solver; must be re-verified in content_dilr.py)

1. **Time zones** (4 Q). Offices work 09:00–18:00 local. Mumbai UTC+5:30, London UTC+1, New York UTC−4, Tokyo UTC+9.
   - Mumbai + London + Tokyo common window: 60 min (UTC 08:00–09:00 = 13:30 Mumbai time).
   - Mumbai & New York overlap: 0 min. London & New York overlap: 4 h.
   - If Mumbai worked until 20:00, overlap with New York = 90 min.
2. **Switches and bulbs** (4 Q). 4 bulbs, all off. S1 toggles B1,B2; S2 B2,B3; S3 B3,B4; S4 B1,B4.
   - Only B1 and B3 on: 2 presses (S1 + S2). Odd numbers of lit bulbs are impossible. 8 reachable patterns.
3. **Seat allocation, divisor rule** (5 Q). Votes: Red 42,000; Blue 31,000; Green 15,000; Orange 8,000; Violet 4,000; 10 seats.
   - Divisor rule: Red 5, Blue 3, Green 1, Orange 1, Violet 0. Largest remainder: Red 4, Green 2 (2 parties differ).
   - 12 seats: Red 5, Blue 4, Green 2, Orange 1.
   - CAUTION: Violet at exactly 8,000 ties Orange; ask for votes needed to win "outright" (8,001) or avoid the question.
   - Red: 42% of votes, 50% of seats (8 points).
4. **Shop stock** (4 Q). Opening: Notebooks 50, Pens 120, Bags 20. Received / sold Mon–Fri:
   Notebooks rec (0,30,0,20,0) sold (15,12,18,10,14) → ends 35,53,35,45,31.
   Pens rec (0,0,60,0,0) sold (35,30,25,40,20) → ends 85,55,90,50,30.
   Bags rec (10,0,0,10,0) sold (6,8,5,9,7) → ends 24,16,11,12,5.
5. **Message table** (5 Q). Sent: K 12, L 9, M 7, N 8. Received: K 10, L 11, M 9, N 6. Everyone sent ≥1 to each other person;
   K sent L twice what K sent M; M sent N more than L sent N; N sent K more than anyone else; N sent L and M equal numbers.
   → 2 tables. Fixed: K→L 6, K→M 3, K→N 3, L→N 1, M→N 2. If N→K > 5: L→M = 5. L→K could be 3 or 4.

## Next steps
Write content_dilr.py with solvers + verify(), content_varc.py (4 new passages, 8 VA), content_qa.py (22 checked Qs),
paper.py (NAME "Full Mock 10", SEED 1010), then `python3 build.py full-mock-10` and review rendered pages.
