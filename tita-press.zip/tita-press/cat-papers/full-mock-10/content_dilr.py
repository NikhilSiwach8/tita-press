"""Full Mock 10 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from collections import Counter
from fractions import Fraction as Fr
from itertools import product

# ---------- Set 1: time zones ----------
OFFICES = {"Mumbai": Fr(11, 2), "London": Fr(1), "New York": Fr(-4), "Tokyo": Fr(9)}  # hours ahead of UTC

def window(city, start=9, end=18):
    """Working hours in UTC hours."""
    return (start - OFFICES[city], end - OFFICES[city])

def overlap_minutes(*wins):
    lo = max(w[0] for w in wins); hi = min(w[1] for w in wins)
    return max(0, (hi - lo) * 60)

# ---------- Set 2: switches ----------
SWITCHES = {"S1": (1, 1, 0, 0), "S2": (0, 1, 1, 0), "S3": (0, 0, 1, 1), "S4": (1, 0, 0, 1)}

def reachable():
    """Bulb pattern -> fewest presses (each switch pressed 0 or 1 times suffices, since pressing twice cancels)."""
    best = {}
    for picks in product((0, 1), repeat=4):
        state = [0] * 4
        for p, s in zip(picks, SWITCHES.values()):
            if p: state = [(a + b) % 2 for a, b in zip(state, s)]
        t = tuple(state)
        best[t] = min(best.get(t, 9), sum(picks))
    return best

# ---------- Set 3: seats ----------
VOTES = {"Red": 42000, "Blue": 31000, "Green": 15000, "Orange": 8000, "Violet": 4000}

def divisor_rule(votes, seats):
    q = sorted(((Fr(n, d), p) for p, n in votes.items() for d in range(1, seats + 1)), key=lambda x: -x[0])
    assert q[seats - 1][0] != q[seats][0], "tie at the last seat"
    won = Counter(p for _, p in q[:seats])
    return {p: won[p] for p in votes}

def remainder_rule(votes, seats):
    quota = Fr(sum(votes.values()), seats)
    s = {p: int(n // quota) for p, n in votes.items()}
    order = sorted(votes, key=lambda p: -(votes[p] / quota - s[p]))
    for p in order[: seats - sum(s.values())]: s[p] += 1
    return s

# ---------- Set 4: stock ----------
OPEN = {"Notebooks": 50, "Pens": 120, "Bags": 20}
RECEIVED = {"Notebooks": (0, 30, 0, 20, 0), "Pens": (0, 0, 60, 0, 0), "Bags": (10, 0, 0, 10, 0)}
SOLD = {"Notebooks": (15, 12, 18, 10, 14), "Pens": (35, 30, 25, 40, 20), "Bags": (6, 8, 5, 9, 7)}
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

def closing(item):
    s, out = OPEN[item], []
    for r, d in zip(RECEIVED[item], SOLD[item]):
        s += r - d; out.append(s)
    return out

# ---------- Set 5: messages ----------
PEOPLE = "KLMN"
SENT = {"K": 12, "L": 9, "M": 7, "N": 8}
RECV = {"K": 10, "L": 11, "M": 9, "N": 6}

def message_tables():
    def rows(p, total):
        others = [q for q in PEOPLE if q != p]
        for a in range(1, total):
            for b in range(1, total - a):
                if total - a - b >= 1: yield dict(zip(others, (a, b, total - a - b)))
    out = []
    for k in rows("K", 12):
        if k["L"] != 2 * k["M"]: continue
        for l in rows("L", 9):
            for m in rows("M", 7):
                for n in rows("N", 8):
                    g = {"K": k, "L": l, "M": m, "N": n}
                    if any(sum(g[s][r] for s in PEOPLE if s != r) != RECV[r] for r in PEOPLE): continue
                    if g["M"]["N"] <= g["L"]["N"] or n["L"] != n["M"]: continue
                    if any(n["K"] <= v for q, v in n.items() if q != "K"): continue
                    out.append(g)
    return out


SETS = [
    {"title": "Set 1",
     "intro": ["A company has offices in four cities. Each office works from 09:00 to 18:00 local time. Local time is ahead of Coordinated Universal Time (UTC) by 5 hours 30 minutes in Mumbai, 1 hour in London and 9 hours in Tokyo, and behind UTC by 4 hours in New York. A meeting can include an office only during its working hours."],
     "questions": [
        {"q": "For how many minutes in a day are the Mumbai, London and Tokyo offices all working at the same time?", "tita": True, "ans": "60",
         "sol": "In UTC, Mumbai works 03:30–12:30, London 08:00–17:00 and Tokyo 00:00–09:00. All three overlap from 08:00 to 09:00 UTC: 60 minutes."},
        {"q": "What is the local time in Mumbai at the start of that common window?", "opts": ["13:30", "14:00", "14:30", "15:00"], "ans": 0,
         "sol": "08:00 UTC plus 5 hours 30 minutes is 13:30 in Mumbai."},
        {"q": "For how many hours a day are the London and New York offices both working?", "opts": ["2", "3", "4", "5"], "ans": 2,
         "sol": "New York works 13:00–22:00 UTC and London 08:00–17:00 UTC. They overlap from 13:00 to 17:00: 4 hours. (Mumbai and New York never overlap: Mumbai closes at 12:30 UTC.)"},
        {"q": "If the Mumbai office extended its day to end at 20:00 local time, for how many minutes would it overlap with the New York office?", "tita": True, "ans": "90",
         "sol": "Mumbai would close at 14:30 UTC. New York opens at 13:00 UTC, so they would overlap for 90 minutes."},
     ]},
    {"title": "Set 2",
     "intro": ["A panel has four bulbs, B1 to B4, all initially off, and four switches. Pressing a switch changes the state (off to on, or on to off) of exactly two bulbs: S1 changes B1 and B2; S2 changes B2 and B3; S3 changes B3 and B4; S4 changes B1 and B4. Switches may be pressed any number of times, in any order."],
     "questions": [
        {"q": "After S1 and then S3 are pressed once each, how many bulbs are on?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "S1 turns on B1 and B2; S3 turns on B3 and B4. All four are on."},
        {"q": "What is the smallest number of presses needed to have exactly B1 and B3 on?", "tita": True, "ans": "2",
         "sol": "S1 then S2: B2 is changed twice and ends off, leaving B1 and B3 on. A single press always lights two adjacent bulbs, so one press is not enough."},
        {"q": "Which of the following can never be achieved?", "opts": ["Only B1 and B2 on", "Only B1 and B3 on", "Only B1 on", "All four on"], "ans": 2,
         "sol": "Every press changes exactly two bulbs, so the number of bulbs that are on is always even. A single lit bulb is impossible; the other patterns are each reachable."},
        {"q": "How many different on/off patterns of the four bulbs can be produced?", "tita": True, "ans": "8",
         "sol": "Exactly the patterns with an even number of lit bulbs are reachable: 1 with none, 6 with two, 1 with all four. 8 patterns. (Pressing all four switches once returns every bulb to off, so the four switches produce only 2³ = 8 patterns.)"},
     ]},
    {"title": "Set 3",
     "intro": ["Five parties contested 10 seats and received the votes shown below. Seats are allocated by the divisor rule: each party's votes are divided by 1, 2, 3, …, and the 10 largest of all these quotients each win a seat for the party they came from.",
               "Red 42,000; Blue 31,000; Green 15,000; Orange 8,000; Violet 4,000."],
     "questions": [
        {"q": "How many seats does Red win?", "opts": ["2", "3", "4", "5"], "ans": 3,
         "sol": "The 10 largest quotients: Red 42,000, 21,000, 14,000, 10,500, 8,400; Blue 31,000, 15,500, 10,333; Green 15,000; Orange 8,000. Red wins 5, Blue 3, Green 1, Orange 1. The next quotient, Blue's 7,750, misses out."},
        {"q": "Under a different rule, each party first receives one seat for every full 10,000 votes, and the remaining seats go to the parties with the largest leftover votes. How many parties would end up with a different number of seats from the divisor rule?", "opts": ["0", "1", "2", "3"], "ans": 2,
         "sol": "Full 10,000s: Red 4, Blue 3, Green 1, others 0 (8 seats). Leftovers: Orange 8,000, Green 5,000, Violet 4,000, Red 2,000, Blue 1,000. The two remaining seats go to Orange and Green: Red 4, Blue 3, Green 2, Orange 1. Red and Green differ: two parties."},
        {"q": "If 12 seats had been available under the divisor rule, how many would Blue have won?", "opts": ["4", "5", "6", "7"], "ans": 0,
         "sol": "The 11th and 12th largest quotients are Blue's 7,750 and Green's 7,500 (Red's next is 7,000). Blue wins 4."},
        {"q": "What is the smallest number of votes Violet would need (all other votes unchanged) to win a seat outright under the divisor rule with 10 seats?", "tita": True, "ans": "8001",
         "sol": "Violet's quotient must beat the 10th largest, Orange's 8,000. At exactly 8,000 the two tie, so 8,001 votes are needed."},
        {"q": "By how many percentage points does Red's share of seats exceed its share of votes under the divisor rule?", "tita": True, "ans": "8",
         "sol": "Red has 42,000 of 1,00,000 votes (42%) and 5 of 10 seats (50%): 8 percentage points."},
     ]},
    {"title": "Set 4",
     "intro": ["A stationery shop opened on Monday with 50 notebooks, 120 pens and 20 bags. The table shows the units it received and sold each day; no other changes occurred."],
     "table": {"head": ["Item", "Mon", "Tue", "Wed", "Thu", "Fri"],
               "rows": [["Notebooks received", "0", "30", "0", "20", "0"], ["Notebooks sold", "15", "12", "18", "10", "14"],
                        ["Pens received", "0", "0", "60", "0", "0"], ["Pens sold", "35", "30", "25", "40", "20"],
                        ["Bags received", "10", "0", "0", "10", "0"], ["Bags sold", "6", "8", "5", "9", "7"]]},
     "questions": [
        {"q": "How many notebooks were left at the end of Friday?", "tita": True, "ans": "31",
         "sol": "50 + 30 + 20 − (15 + 12 + 18 + 10 + 14) = 100 − 69 = 31."},
        {"q": "At the end of which day was the stock of pens the lowest?", "opts": ["Tuesday", "Wednesday", "Thursday", "Friday"], "ans": 3,
         "sol": "Pens at the end of each day: 85, 55, 90, 50, 30. Lowest on Friday."},
        {"q": "The shop reorders an item whenever its stock at the end of a day is below 20. On how many of the five days did at least one item need reordering?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "Bags end the days at 24, 16, 11, 12 and 5: below 20 on Tuesday to Friday. Notebooks (lowest 31) and pens (lowest 30) never fall below 20. Four days."},
        {"q": "What was the total number of units of all three items sold during the week?", "tita": True, "ans": "254",
         "sol": "Notebooks 69 + pens 150 + bags 35 = 254."},
     ]},
    {"title": "Set 5",
     "intro": ["Four colleagues, K, L, M and N, exchanged messages during a week. The table shows how many messages each sent and received in all (only messages among the four are counted). In addition:",
               "1. Each colleague sent at least one message to each of the other three.",
               "2. K sent exactly twice as many messages to L as to M.",
               "3. M sent more messages to N than L did.",
               "4. N sent more messages to K than to anyone else, and the same number to L as to M."],
     "table": {"head": ["Colleague", "K", "L", "M", "N"],
               "rows": [["Sent", "12", "9", "7", "8"], ["Received", "10", "11", "9", "6"]]},
     "questions": [
        {"q": "How many messages did K send to L?", "tita": True, "ans": "6",
         "sol": "N received only 6, at least 1 from each of K, L, M, and M sent N more than L did. K's 12 messages split as 2x to L, x to M and the rest to N; the received totals force x = 3, so K sent 6 to L, 3 to M and 3 to N, leaving L → N = 1 and M → N = 2."},
        {"q": "How many messages did M send to N?", "opts": ["1", "2", "3", "4"], "ans": 1,
         "sol": "N's 6 received messages are K 3 + L 1 + M 2."},
        {"q": "How many different tables of messages satisfy all the conditions?", "tita": True, "ans": "2",
         "sol": "With the fixed entries, N's 8 messages are split as k to K and equal amounts e to L and M, with k > e: (6, 1, 1) or (4, 2, 2). Each leads to exactly one consistent completion of L's and M's messages: two tables."},
        {"q": "If N sent more than 5 messages to K, how many messages did L send to M?", "opts": ["2", "3", "4", "5"], "ans": 3,
         "sol": "N → K = 6 gives N → L = N → M = 1. Then M must receive 9 − 3 − 1 = 5 from L."},
        {"q": "Which of the following could be the number of messages L sent to K?", "opts": ["2", "3", "5", "6"], "ans": 1,
         "sol": "In the two tables L sent K 3 or 4 messages. Of the options, only 3 is possible."},
     ]},
]


def verify():
    w = {c: window(c) for c in OFFICES}
    assert overlap_minutes(w["Mumbai"], w["London"], w["Tokyo"]) == 60
    assert max(w["Mumbai"][0], w["London"][0], w["Tokyo"][0]) + OFFICES["Mumbai"] == Fr(27, 2)
    assert overlap_minutes(w["London"], w["New York"]) == 240 and overlap_minutes(w["Mumbai"], w["New York"]) == 0
    assert overlap_minutes(window("Mumbai", 9, 20), w["New York"]) == 90

    r = reachable()
    assert len(r) == 8 and r[(1, 0, 1, 0)] == 2 and (1, 0, 0, 0) not in r and (1, 1, 1, 1) in r and (1, 1, 0, 0) in r

    s = divisor_rule(VOTES, 10)
    assert s == {"Red": 5, "Blue": 3, "Green": 1, "Orange": 1, "Violet": 0}
    full = {p: n // 10000 for p, n in VOTES.items()}
    left = sorted(VOTES, key=lambda p: -(VOTES[p] % 10000))
    alt = dict(full)
    for p in left[: 10 - sum(full.values())]: alt[p] += 1
    assert sum(1 for p in VOTES if alt[p] != s[p]) == 2
    assert divisor_rule(VOTES, 12)["Blue"] == 4
    assert divisor_rule(dict(VOTES, Violet=8001), 10)["Violet"] == 1
    assert (Fr(s["Red"], 10) - Fr(VOTES["Red"], sum(VOTES.values()))) * 100 == 8

    assert closing("Notebooks")[-1] == 31
    pens = closing("Pens"); assert DAYS[pens.index(min(pens))] == "Friday"
    assert sum(1 for d in range(5) if any(closing(i)[d] < 20 for i in OPEN)) == 4
    assert sum(sum(v) for v in SOLD.values()) == 254

    ts = message_tables()
    assert len(ts) == 2 and all(g["K"]["L"] == 6 and g["M"]["N"] == 2 for g in ts)
    assert {g["L"]["M"] for g in ts if g["N"]["K"] > 5} == {5}
    assert {g["L"]["K"] for g in ts} == {3, 4}
    return "DILR: all 22 keys match the solvers"
