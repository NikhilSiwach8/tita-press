"""Full Mock 11 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from itertools import permutations, product

# ---------- Set 1: seating with professions ----------
PEOPLE = "GHJKMN"
JOBS = ["teacher", "nurse", "coder", "chef", "pilot", "judge"]

def seatings():
    out = []
    for perm in permutations(PEOPLE):
        pos = {p: i for i, p in enumerate(perm)}
        if pos["G"] not in (0, 5) or abs(pos["H"] - pos["J"]) != 2 or pos["K"] != pos["M"] + 1: continue
        if pos["N"] in (0, 5) or abs(pos["G"] - pos["N"]) == 1: continue
        for jobs in permutations(JOBS):
            j = dict(zip(PEOPLE, jobs)); w = {v: k for k, v in j.items()}
            if abs(pos[w["teacher"]] - pos[w["nurse"]]) != 1 or pos[w["coder"]] not in (0, 5): continue
            if j["H"] in ("chef", "pilot") or pos[w["judge"]] != pos["N"] + 1: continue
            if j["K"] != "pilot" or j["M"] == "teacher" or pos[w["chef"]] < pos[w["pilot"]]: continue
            out.append(("".join(perm), j))
    return out

# ---------- Set 2: rainfall ----------
MONTHS = ["June", "July", "August", "September"]
RAIN = {"Kochi": (650, 720, 420, 300), "Mumbai": (520, 840, 580, 310), "Pune": (140, 190, 120, 130), "Chennai": (50, 90, 120, 150)}

# ---------- Set 3: three sports ----------
def sport_solutions():
    sols = []
    for cf, ch, fh in product(range(5, 41), repeat=3):
        if cf + ch + fh != 30: continue
        c, f, h = 80 - 10 - cf - ch, 70 - 10 - cf - fh, 50 - 10 - ch - fh
        if min(c, f, h) < 0 or c + f + h + 30 + 10 != 150: continue
        sols.append(dict(c=c, f=f, h=h, cf=cf, ch=ch, fh=fh))
    return sols

# ---------- Set 4: fruit boxes ----------
def fruit_solutions():
    out = []
    for a1, o1 in product(range(2, 21), repeat=2):
        b1 = (a1, o1, 20 - a1 - o1)
        if b1[2] < 2 or not b1[0] > b1[1] or not b1[2] < b1[1]: continue
        for a2, o2 in product(range(2, 26), repeat=2):
            b2 = (a2, o2, 25 - a2 - o2)
            if b2[2] < 2 or b2[1] != b2[2]: continue
            b3 = tuple(t - x - y for t, x, y in zip((22, 18, 20), b1, b2))
            if min(b3) < 2 or sum(b3) != 15 or b3[2] != 2 * b3[0]: continue
            out.append((b1, b2, b3))
    return out

# ---------- Set 5: exams ----------
EXAMS = ["Law", "Math", "Physics", "Stats", "Econ"]
WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

def exam_solutions():
    out = []
    for perm in permutations(EXAMS):
        d = {e: i for i, e in enumerate(perm)}
        if d["Math"] >= d["Stats"] or d["Stats"] - d["Math"] == 1 or d["Law"] in (0, 4): continue
        if abs(d["Physics"] - d["Econ"]) == 1 or d["Physics"] != 1: continue
        for halls in product((1, 2), repeat=5):
            h = {perm[i]: halls[i] for i in range(5)}
            if h["Physics"] != h["Math"] or halls.count(1) != 3 or h["Law"] != 2: continue
            if halls[0] != 1 or h["Econ"] == h["Stats"]: continue
            out.append((perm, h))
    return out


SETS = [
    {"title": "Set 1",
     "intro": ["Six people, G, H, J, K, M and N, sit in a row of six seats facing north, numbered 1 to 6 from west to east. Each has a different profession: teacher, nurse, coder, chef, pilot or judge. The following is known:",
               "1. G sits at one end, and N does not sit at an end or next to G.",
               "2. Exactly one person sits between H and J.",
               "3. K sits immediately east of M. K is the pilot, and M is not the teacher.",
               "4. The teacher and the nurse sit next to each other, and the coder sits at an end.",
               "5. The judge sits immediately east of N, and H is neither the chef nor the pilot.",
               "6. The chef sits somewhere east of the pilot."],
     "questions": [
        {"q": "Who sits in seat 1, at the west end?", "opts": ["G", "H", "M", "N"], "ans": 2,
         "sol": "The coder is at an end, and the chef is east of the pilot (K). Working through the clues, G must be at the east end as the chef, the coder at the west end must be M (immediately west of K), and N sits in seat 4 with the judge in seat 5. The order is M, K, (H or J), N, (J or H), G."},
        {"q": "What is G's profession?", "opts": ["Coder", "Chef", "Judge", "Nurse"], "ans": 1,
         "sol": "G sits at the east end, and the only profession left for that seat is chef."},
        {"q": "How many complete arrangements of seats and professions satisfy all the conditions?", "tita": True, "ans": "4",
         "sol": "H and J can take seats 3 and 5 in either order, and the teacher and nurse (seats 3 and 4) can swap: 2 × 2 = 4."},
        {"q": "If H is the judge, who sits in seat 3?", "opts": ["H", "J", "K", "N"], "ans": 1,
         "sol": "The judge is in seat 5, so H is in seat 5 and J in seat 3."},
     ]},
    {"title": "Set 2",
     "intro": ["The table shows rainfall, in millimetres, in four cities during the four monsoon months of a year."],
     "table": {"head": ["City", *MONTHS], "rows": [[c, *map(str, v)] for c, v in RAIN.items()]},
     "questions": [
        {"q": "Which city received the most rainfall over the four months?", "opts": ["Kochi", "Mumbai", "Pune", "Chennai"], "ans": 1,
         "sol": "Totals: Kochi 2,090, Mumbai 2,250, Pune 580, Chennai 410. Mumbai, despite Kochi's wetter June."},
        {"q": "In which month was the combined rainfall of the four cities the highest?", "opts": ["June", "July", "August", "September"], "ans": 1,
         "sol": "Combined: June 1,360, July 1,840, August 1,240, September 890. July."},
        {"q": "What percentage of Pune's four-month rainfall fell in July? Give your answer to the nearest whole number.", "tita": True, "ans": "33",
         "sol": "190 / 580 = 32.8%, which rounds to 33."},
        {"q": "In how many of the cities did rainfall increase every month from June to September?", "opts": ["0", "1", "2", "3"], "ans": 1,
         "sol": "Only Chennai (50, 90, 120, 150) rose every month. The others peaked in July."},
        {"q": "Chennai's September rainfall was what fraction of Mumbai's July rainfall?", "opts": ["5/28", "1/5", "3/14", "1/4"], "ans": 0,
         "sol": "150 / 840 = 5/28."},
     ]},
    {"title": "Set 3",
     "intro": ["Each of the 150 students in a school plays at least one of cricket, football and hockey. 80 play cricket, 70 play football and 50 play hockey; 10 play all three. For each pair of sports, at least 5 students play exactly that pair and not the third."],
     "questions": [
        {"q": "How many students play exactly two of the three sports?", "tita": True, "ans": "30",
         "sol": "With S playing exactly one and D exactly two: S + D + 10 = 150 and S + 2D + 3 × 10 = 200. Subtracting the first from the second, D + 20 = 50, so D = 30."},
        {"q": "How many students play exactly one sport?", "opts": ["80", "90", "100", "110"], "ans": 3,
         "sol": "S = 150 − 30 − 10 = 110, whatever the split among the sports."},
        {"q": "What is the largest possible number of students who play only hockey?", "tita": True, "ans": "30",
         "sol": "Only hockey = 40 − (cricket–hockey only) − (football–hockey only) = 40 − (30 − cricket–football only) = 10 + cricket–football only. Cricket–football only is at most 30 − 5 − 5 = 20, so only hockey is at most 30."},
        {"q": "What is the smallest possible number of students who play only cricket?", "opts": ["40", "45", "50", "55"], "ans": 1,
         "sol": "Only cricket = 70 − (cricket–football only) − (cricket–hockey only) = 70 − (30 − football–hockey only) = 40 + football–hockey only, which is smallest when football–hockey only is 5: 45."},
        {"q": "If 20 students play only hockey, how many play both cricket and football (including those who also play hockey)?", "tita": True, "ans": "20",
         "sol": "Only hockey = 10 + cricket–football only, so cricket–football only is 10. Adding the 10 who play all three gives 20."},
     ]},
    {"title": "Set 4",
     "intro": ["Three boxes contain apples, oranges and mangoes. Box 1 holds 20 fruits, box 2 holds 25 and box 3 holds 15. Altogether there are 22 apples, 18 oranges and 20 mangoes. Every box contains at least 2 of each fruit. In addition:",
               "1. Box 1 has more apples than oranges and fewer mangoes than oranges.",
               "2. Box 2 has as many oranges as mangoes.",
               "3. Box 3 has twice as many mangoes as apples."],
     "questions": [
        {"q": "How many apples are in box 3?", "tita": True, "ans": "4",
         "sol": "Box 3 holds a apples and 2a mangoes, so its oranges are 15 − 3a. Combining with the other boxes and totals, only a = 4 works: box 3 has 4 apples, 3 oranges and 8 mangoes."},
        {"q": "In how many different ways can the fruits be distributed?", "opts": ["3", "4", "5", "6"], "ans": 0,
         "sol": "With box 3 fixed, box 2 has o oranges and o mangoes; box 1's numbers follow. The conditions allow (box 1, box 2) = (9, 7, 4; 9, 8, 8), (11, 6, 3; 7, 9, 9) and (13, 5, 2; 5, 10, 10): three ways."},
        {"q": "What is the largest possible number of oranges in box 2?", "opts": ["7", "8", "9", "10"], "ans": 3,
         "sol": "From the three distributions, box 2 holds 8, 9 or 10 oranges. The largest is 10."},
        {"q": "If box 1 has 9 apples, how many mangoes are in box 2?", "tita": True, "ans": "8",
         "sol": "That is the first distribution, in which box 2 holds 9 apples, 8 oranges and 8 mangoes."},
     ]},
    {"title": "Set 5",
     "intro": ["Five exams, Law, Math, Physics, Stats and Econ, are held on the five weekdays from Monday to Friday, one a day, in either Hall 1 or Hall 2. Three exams are held in Hall 1 and two in Hall 2. The following is known:",
               "1. Math is held before Stats, but not on the day immediately before it.",
               "2. Law is held neither on Monday nor on Friday, and in Hall 2.",
               "3. Physics is on Tuesday, and Physics and Econ are not on consecutive days.",
               "4. Physics and Math are in the same hall, and Monday's exam is in Hall 1.",
               "5. Econ and Stats are in different halls."],
     "questions": [
        {"q": "Which exam is held on Monday?", "opts": ["Law", "Math", "Stats", "Econ"], "ans": 1,
         "sol": "Monday cannot be Law, Physics (Tuesday) or Econ (next to Physics). It cannot be Stats, which must follow Math. So Math is on Monday, in Hall 1 with Physics."},
        {"q": "How many complete schedules (day and hall for every exam) satisfy all the conditions?", "tita": True, "ans": "6",
         "sol": "Wednesday to Friday hold Law, Stats and Econ, with Econ not on Wednesday and Law not on Friday, and Stats not on Tuesday: orders Law–Stats–Econ, Law–Econ–Stats and Stats–Law–Econ. Hall 1 has one place left, which Stats or Econ takes (they differ): 2 hall choices for each order. 3 × 2 = 6."},
        {"q": "If Stats is on Wednesday, which exam is on Friday?", "opts": ["Law", "Physics", "Stats", "Econ"], "ans": 3,
         "sol": "With Stats on Wednesday, Law must be Thursday (not Friday), so Econ is on Friday."},
        {"q": "In how many of the possible schedules is Law held on Wednesday?", "opts": ["4", "5", "6", "7"], "ans": 0,
         "sol": "Law is on Wednesday in the orders Law–Stats–Econ and Law–Econ–Stats, each with 2 hall choices: 4 schedules."},
     ]},
]


def verify():
    ss = seatings()
    assert len(ss) == 4 and all(p[0] == "M" and j["G"] == "chef" for p, j in ss)
    assert {p[2] for p, j in ss if j["H"] == "judge"} == {"J"}

    tot = {c: sum(v) for c, v in RAIN.items()}
    assert max(tot, key=tot.get) == "Mumbai"
    month = [sum(v[i] for v in RAIN.values()) for i in range(4)]
    assert MONTHS[month.index(max(month))] == "July"
    assert round(RAIN["Pune"][1] * 100 / tot["Pune"]) == 33
    assert sum(1 for v in RAIN.values() if all(v[i] < v[i + 1] for i in range(3))) == 1
    from fractions import Fraction as Fr
    assert Fr(RAIN["Chennai"][3], RAIN["Mumbai"][1]) == Fr(5, 28)

    sp = sport_solutions()
    assert {s["cf"] + s["ch"] + s["fh"] for s in sp} == {30} and {s["c"] + s["f"] + s["h"] for s in sp} == {110}
    assert max(s["h"] for s in sp) == 30 and min(s["c"] for s in sp) == 45
    assert {s["cf"] + 10 for s in sp if s["h"] == 20} == {20}

    fs = fruit_solutions()
    assert len(fs) == 3 and {b3 for _, _, b3 in fs} == {(4, 3, 8)}
    assert max(b2[1] for _, b2, _ in fs) == 10
    assert {b2[2] for b1, b2, _ in fs if b1[0] == 9} == {8}

    ex = exam_solutions()
    assert len(ex) == 6 and all(p[0] == "Math" for p, _ in ex)
    assert {p[4] for p, _ in ex if p[2] == "Stats"} == {"Econ"}
    assert sum(1 for p, _ in ex if p[2] == "Law") == 4
    return "DILR: all 22 keys match the solvers"
