"""Full Mock 12 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import combinations, permutations, product

# ---------- Set 1: floors and pets ----------
RESIDENTS = "RSTVW"
PETS = ["cat", "dog", "fish", "parrot", "rabbit"]

def floor_solutions():
    out = []
    for perm in permutations(RESIDENTS):  # index 0 = floor 1
        f = {p: i + 1 for i, p in enumerate(perm)}
        if f["R"] <= f["S"] or abs(f["T"] - f["V"]) != 2 or f["W"] in (1, 5) or f["T"] != 1: continue
        for pets in permutations(PETS):
            pt = dict(zip(RESIDENTS, pets)); w = {v: k for k, v in pt.items()}
            if f[w["dog"]] != f[w["cat"]] + 1 or f[w["fish"]] != 5 or f[w["parrot"]] % 2: continue
            if pt["W"] == "rabbit" or pt["R"] == "cat": continue
            out.append((f, pt))
    return out

# ---------- Set 2: league ----------
TEAMS = "PQRSU"
MATCHES = list(combinations(TEAMS, 2))

def league_solutions():
    out = []
    for res in product((0, 1, 2), repeat=10):
        pts = dict.fromkeys(TEAMS, 0); wins = dict.fromkeys(TEAMS, 0)
        for (a, b), r in zip(MATCHES, res):
            if r == 0: pts[a] += 2; wins[a] += 1
            elif r == 2: pts[b] += 2; wins[b] += 1
            else: pts[a] += 1; pts[b] += 1
        if [pts[t] for t in TEAMS] != [7, 6, 4, 2, 1] or res.count(1) != 2 or wins["Q"] != 3: continue
        out.append({(a, b): {0: a, 1: "draw", 2: b}[r] for (a, b), r in zip(MATCHES, res)})
    return out

# ---------- Set 3: hospital ----------
ADMIT = {"Cardiology": (420, 460, 510, 480), "Orthopaedics": (380, 350, 400, 450), "Paediatrics": (300, 340, 280, 360), "Oncology": (200, 230, 250, 270)}

# ---------- Set 4: banking app ----------
AGE = {"18–24": (200, 45), "25–34": (250, 60), "35–49": (220, 50), "50 and over": (130, 30)}
def users(g, pct=None): n, p = AGE[g]; return Fr(n * (pct if pct is not None else p), 100)

# ---------- Set 5: defects ----------
LINES = {"Line 1": (5000, Fr(2)), "Line 2": (4000, Fr(7, 2)), "Line 3": (6000, Fr(3, 2))}
def defects(line, rate=None): n, r = LINES[line]; return n * (rate if rate is not None else r) / 100


SETS = [
    {"title": "Set 1",
     "intro": ["Five people, R, S, T, V and W, live in a five-storey building, one on each floor (floor 1 is the lowest). Each keeps a different pet: a cat, a dog, a fish, a parrot or a rabbit. The following is known:",
               "1. T lives on floor 1, and exactly one floor lies between T and V.",
               "2. R lives above S, and W lives neither on the top floor nor on floor 1.",
               "3. The fish is kept on the top floor, and the parrot on an even-numbered floor.",
               "4. The dog lives directly above the cat.",
               "5. W does not keep the rabbit, and R does not keep the cat."],
     "questions": [
        {"q": "Who lives on the top floor?", "opts": ["R", "S", "V", "W"], "ans": 0,
         "sol": "T is on floor 1, so V is on floor 3. R is above S and W is not on floor 5, so R is on floor 5, with S and W on floors 2 and 4 in some order."},
        {"q": "Which pet does R keep?", "opts": ["Cat", "Dog", "Fish", "Parrot"], "ans": 2,
         "sol": "R is on the top floor, where the fish is kept."},
        {"q": "How many complete arrangements of people and pets satisfy all the conditions?", "tita": True, "ans": "6",
         "sol": "S and W can take floors 2 and 4 either way. With fish on 5 and the parrot on 2 or 4, the cat–dog pair takes floors 1–2, 2–3 or 3–4, and the rabbit the remaining floor; W must not end up with the rabbit. Checking both placements of S and W gives 3 pet arrangements each: 6 in all."},
        {"q": "If S keeps the cat, who keeps the dog?", "opts": ["T", "V", "W", "R"], "ans": 1,
         "sol": "S with the cat must be on floor 2 (on floor 4 the dog would be on the fish's floor), so the dog is on floor 3, which is V's."},
     ]},
    {"title": "Set 2",
     "intro": ["Five teams, P, Q, R, S and U, played a league in which each team played every other team once. A win earned 2 points, a draw 1 point to each team and a loss 0. The final points were P 7, Q 6, R 4, S 2 and U 1. Exactly two matches were drawn, and Q won three matches."],
     "questions": [
        {"q": "Which team beat Q?", "opts": ["P", "R", "S", "U"], "ans": 0,
         "sol": "Q has 6 points from 3 wins, so it lost its fourth match and drew none. P (7 points: 3 wins and a draw) is the only team that can have beaten it: P beat Q."},
        {"q": "How many matches did P win?", "tita": True, "ans": "3",
         "sol": "7 points from 4 matches with draws worth 1 means 3 wins and 1 draw."},
        {"q": "If S and U drew their match, what was the result of the match between P and R?", "opts": ["P won", "R won", "It was a draw", "Cannot be determined"], "ans": 0,
         "sol": "There are two possible tables. In the one where S and U drew, P's draw was against S, and P beat R."},
        {"q": "Which of the following results is certain?", "opts": ["R beat S", "P beat R", "S beat U", "R beat U"], "ans": 0,
         "sol": "R beat S in both possible tables. P beat R, S beat U and R beat U each hold in only one."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the number of patients admitted to four departments of a hospital in each quarter of a year."],
     "table": {"head": ["Department", "Q1", "Q2", "Q3", "Q4"], "rows": [[d, *map(str, v)] for d, v in ADMIT.items()]},
     "questions": [
        {"q": "Which department admitted the most patients over the year?", "opts": ["Cardiology", "Orthopaedics", "Paediatrics", "Oncology"], "ans": 0,
         "sol": "Annual totals: Cardiology 1,870, Orthopaedics 1,580, Paediatrics 1,280, Oncology 950."},
        {"q": "In which quarter was the total number of admissions the highest?", "opts": ["Q1", "Q2", "Q3", "Q4"], "ans": 3,
         "sol": "Totals: Q1 1,300, Q2 1,380, Q3 1,440, Q4 1,560."},
        {"q": "By what percentage did Oncology admissions grow from Q1 to Q4?", "tita": True, "ans": "35",
         "sol": "(270 − 200)/200 = 35%."},
        {"q": "In how many departments did admissions rise in every quarter?", "opts": ["1", "2", "3", "4"], "ans": 0,
         "sol": "Only Oncology (200, 230, 250, 270). Cardiology fell in Q4, Orthopaedics in Q2 and Paediatrics in Q3."},
        {"q": "What percentage of all Q3 admissions were in Paediatrics? Give your answer to the nearest whole number.", "tita": True, "ans": "19",
         "sol": "280 / 1,440 = 19.4%, which rounds to 19."},
     ]},
    {"title": "Set 4",
     "intro": ["A bank surveyed 800 customers about whether they use its mobile banking app. The table shows the number surveyed in each age group and the percentage of each group who use the app."],
     "table": {"head": ["Age group", "Surveyed", "Use the app"], "rows": [[g, str(n), f"{p}%"] for g, (n, p) in AGE.items()]},
     "questions": [
        {"q": "How many of the surveyed customers use the app?", "tita": True, "ans": "389",
         "sol": "90 + 150 + 110 + 39 = 389."},
        {"q": "Approximately what percentage of all surveyed customers use the app?", "opts": ["43%", "45%", "47%", "49%"], "ans": 3,
         "sol": "389 / 800 = 48.6%, approximately 49%."},
        {"q": "Which age group contains the largest number of app users?", "opts": ["18–24", "25–34", "35–49", "50 and over"], "ans": 1,
         "sol": "Users: 90, 150, 110 and 39. The 25–34 group has the most."},
        {"q": "In how many age groups is the percentage of app users higher than the overall percentage for all surveyed customers?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "The overall figure is 48.6%. 25–34 (60%) and 35–49 (50%) are above it; 18–24 (45%) and 50 and over (30%) are not."},
        {"q": "If the percentage of app users in the 50-and-over group rose to 50%, by how many would the number of app users increase?", "tita": True, "ans": "26",
         "sol": "130 × (50% − 30%) = 26."},
     ]},
    {"title": "Set 5",
     "intro": ["A factory runs three production lines. Last month, Line 1 made 5,000 units with a defect rate of 2%, Line 2 made 4,000 units with a defect rate of 3.5%, and Line 3 made 6,000 units with a defect rate of 1.5%."],
     "questions": [
        {"q": "How many defective units did the factory make in all?", "tita": True, "ans": "330",
         "sol": "Line 1: 100; Line 2: 140; Line 3: 90. Total 330."},
        {"q": "What was the factory's overall defect rate?", "opts": ["2.0%", "2.2%", "2.33%", "2.5%"], "ans": 1,
         "sol": "330 / 15,000 = 2.2%. (The simple average of the three rates, 2.33%, ignores the different volumes.)"},
        {"q": "Which line made the largest number of defective units?", "opts": ["Line 1", "Line 2", "Line 3", "Lines 1 and 2 equally"], "ans": 1,
         "sol": "Line 2 made 140, more than Line 1 (100) and Line 3 (90), despite making the fewest units."},
        {"q": "If Line 2 cut its defect rate to 2%, by how many would the total number of defective units fall?", "tita": True, "ans": "60",
         "sol": "Line 2 would make 80 defective units instead of 140: 60 fewer."},
     ]},
]


def verify():
    fs = floor_solutions()
    assert len(fs) == 6
    assert all(f["R"] == 5 and pt["R"] == "fish" for f, pt in fs)
    s_cat = [(f, pt) for f, pt in fs if pt["S"] == "cat"]
    assert s_cat and {next(p for p in RESIDENTS if pt[p] == "dog") for _, pt in s_cat} == {"V"}

    ls = league_solutions()
    assert len(ls) == 2 and all(t[("P", "Q")] == "P" and t[("R", "S")] == "R" for t in ls)
    assert {t[("P", "R")] for t in ls if t[("S", "U")] == "draw"} == {"P"}
    assert not all(t[("P", "R")] == "P" for t in ls) and not all(t[("S", "U")] == "S" for t in ls) and not all(t[("R", "U")] == "R" for t in ls)

    tot = {d: sum(v) for d, v in ADMIT.items()}
    assert max(tot, key=tot.get) == "Cardiology"
    q = [sum(v[i] for v in ADMIT.values()) for i in range(4)]
    assert q.index(max(q)) == 3 and q[2] == 1440
    assert Fr(270 - 200, 200) * 100 == 35
    assert sum(1 for v in ADMIT.values() if all(v[i] < v[i + 1] for i in range(3))) == 1
    assert round(Fr(280, 1440) * 100) == 19

    total = sum(users(g) for g in AGE)
    assert total == 389 and round(total * 100 / 800) == 49
    assert max(AGE, key=users) == "25–34"
    assert sum(1 for g in AGE if AGE[g][1] > total * 100 / 800) == 2
    assert users("50 and over", 50) - users("50 and over") == 26

    d = {l: defects(l) for l in LINES}
    assert sum(d.values()) == 330 and Fr(330, 15000) * 100 == Fr(22, 10)
    assert max(d, key=d.get) == "Line 2"
    assert d["Line 2"] - defects("Line 2", 2) == 60
    return "DILR: all 22 keys match the solvers"
