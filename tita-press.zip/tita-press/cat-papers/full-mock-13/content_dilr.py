"""Full Mock 13 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: round table with drinks ----------
DINERS = "FGHJKL"
DRINKS = ["tea", "coffee", "juice", "water", "milk", "soda"]
def nxt(s): return (s + 1) % 6
def adj(a, b): return nxt(a) == b or nxt(b) == a
def opp(a, b): return (a - b) % 6 == 3

def table_solutions():
    out = []
    for rest in permutations("GHJKL"):
        seat = {"F": 0, **{p: i + 1 for i, p in enumerate(rest)}}
        if not opp(seat["F"], seat["J"]) or not adj(seat["G"], seat["H"]) or adj(seat["K"], seat["F"]): continue
        if seat["L"] not in (1, 5): continue
        for dr in permutations(DRINKS):
            d = dict(zip(DINERS, dr)); w = {v: k for k, v in d.items()}
            if not opp(seat[w["tea"]], seat[w["coffee"]]) or seat[w["juice"]] != nxt(seat["L"]): continue
            if d["F"] in ("tea", "coffee") or not adj(seat[w["milk"]], seat["J"]): continue
            if d["G"] != "soda" or d["K"] == "water" or d["H"] == "milk": continue
            out.append((seat, d))
    return out

# ---------- Set 2: tourists ----------
ARRIVALS = {"UK": (120, 150, 165), "USA": (90, 110, 130), "Germany": (60, 66, 72), "Japan": (40, 38, 44), "UAE": (30, 45, 63)}

# ---------- Set 3: electricity ----------
SLABS = [(100, 3), (100, 5), (200, 7), (None, 9)]
FIXED = 100
def bill(units):
    total, left = FIXED, units
    for size, rate in SLABS:
        use = left if size is None else min(left, size)
        total += use * rate; left -= use
        if left == 0: break
    return total

# ---------- Set 4: phone market ----------
MARKET = {2023: 200, 2024: 220}  # million units
SHARE = {"Alpha": (25, 22), "Bravo": (20, 23), "Coral": (18, 18), "Delta": (15, 14), "Others": (22, 23)}
def units(brand, i): return Fr(SHARE[brand][i] * MARKET[2023 + i], 100)

# ---------- Set 5: medals ----------
MEDALS = {"Teal": (8, 3, 5), "Rust": (6, 9, 4), "Plum": (7, 4, 6), "Sage": (5, 6, 10), "Ochre": (4, 8, 7)}
def points(team, g=3, s=2, b=1): x = MEDALS[team]; return g * x[0] + s * x[1] + b * x[2]


SETS = [
    {"title": "Set 1",
     "intro": ["Six friends, F, G, H, J, K and L, sit around a round table with six equally spaced seats, and each orders a different drink: tea, coffee, juice, water, milk or soda. 'Next clockwise' means the neighbouring seat in the clockwise direction. The following is known:",
               "1. F sits directly opposite J, and L sits next to F.",
               "2. G and H sit next to each other, and K does not sit next to F.",
               "3. The tea and coffee drinkers sit directly opposite each other, and F orders neither.",
               "4. The juice drinker sits next clockwise to L.",
               "5. The milk drinker sits next to J. G orders soda, K does not order water, and H does not order milk."],
     "questions": [
        {"q": "Who sits directly opposite G?", "opts": ["H", "J", "K", "L"], "ans": 2,
         "sol": "Number seats clockwise from F (seat 0); J is in seat 3. K is not next to F, so K is in seat 2 or 4, and L in seat 1 or 5. G and H must be adjacent in the remaining seats. Working through the drink clues leaves one seating: F, G, H, J, K, L clockwise. G (seat 1) is opposite K (seat 4)."},
        {"q": "What does J drink?", "opts": ["Tea", "Water", "Milk", "Juice"], "ans": 1,
         "sol": "The juice drinker sits next clockwise to L, which is F's seat, so F has juice. G has soda; K, next to J, has milk; H and L, opposite each other, have tea and coffee. J has water."},
        {"q": "Who orders juice?", "opts": ["F", "G", "K", "L"], "ans": 0,
         "sol": "L is in seat 5, and the next clockwise seat is F's."},
        {"q": "How many complete arrangements of seats and drinks satisfy all the conditions?", "tita": True, "ans": "2",
         "sol": "The seating is fixed, and only the tea and coffee of H and L can be swapped: two arrangements."},
     ]},
    {"title": "Set 2",
     "intro": ["The table shows tourist arrivals in a country, in thousands, from five source countries over three years."],
     "table": {"head": ["Source", "2022", "2023", "2024"], "rows": [[c, *map(str, v)] for c, v in ARRIVALS.items()]},
     "questions": [
        {"q": "Which source country showed the highest percentage growth in arrivals from 2022 to 2024?", "opts": ["UK", "USA", "Germany", "UAE"], "ans": 3,
         "sol": "Growth: UK 37.5%, USA 44.4%, Germany 20%, Japan 10%, UAE 110%."},
        {"q": "What were the total arrivals from the five countries in 2024, in thousands?", "tita": True, "ans": "474",
         "sol": "165 + 130 + 72 + 44 + 63 = 474."},
        {"q": "From how many of the source countries did arrivals rise in both 2023 and 2024?", "opts": ["4", "5", "6", "7"], "ans": 0,
         "sol": "All except Japan, whose arrivals fell in 2023: four."},
        {"q": "What percentage of the 2024 total came from the UK? Give your answer to the nearest whole number.", "tita": True, "ans": "35",
         "sol": "165 / 474 = 34.8%, which rounds to 35."},
        {"q": "By how many thousand did total arrivals rise from 2023 to 2024?", "opts": ["50", "55", "60", "65"], "ans": 3,
         "sol": "2023 total: 409; 2024 total: 474. A rise of 65 thousand."},
     ]},
    {"title": "Set 3",
     "intro": ["An electricity company charges households a fixed ₹100 a month plus a charge for the units used: ₹3 per unit for the first 100 units, ₹5 per unit for the next 100, ₹7 per unit for the next 200, and ₹9 per unit for every unit above 400."],
     "questions": [
        {"q": "What is the monthly bill, in rupees, for a household that uses 250 units?", "tita": True, "ans": "1250",
         "sol": "100 + 100 × 3 + 100 × 5 + 50 × 7 = 100 + 300 + 500 + 350 = ₹1,250."},
        {"q": "What is the monthly bill, in rupees, for 450 units?", "opts": ["2,300", "2,650", "2,750", "3,150"], "ans": 2,
         "sol": "100 + 300 + 500 + 200 × 7 + 50 × 9 = 100 + 300 + 500 + 1,400 + 450 = ₹2,750."},
        {"q": "A household's bill is ₹1,950. How many units did it use?", "tita": True, "ans": "350",
         "sol": "The first 200 units cost 100 + 300 + 500 = 900 including the fixed charge. The remaining 1,050 at ₹7 per unit is 150 units: 350 in all."},
        {"q": "At 400 units, what is the average cost per unit, including the fixed charge, in rupees?", "opts": ["5.25", "5.5", "5.75", "6"], "ans": 2,
         "sol": "Bill: 100 + 300 + 500 + 1,400 = 2,300. 2,300 / 400 = ₹5.75."},
        {"q": "Two neighbouring households use 150 and 350 units on separate meters. If they shared one meter recording 500 units instead, by how many rupees would their total monthly payment rise?", "tita": True, "ans": "600",
         "sol": "Separately: 150 units cost 650 and 350 units cost 1,950, total 2,600. Together: 500 units cost 100 + 300 + 500 + 1,400 + 900 = 3,200. The shared meter costs ₹600 more, because more units fall into the expensive slabs."},
     ]},
    {"title": "Set 4",
     "intro": ["A country's smartphone market sold 200 million units in 2023 and 220 million in 2024. The table shows each brand's percentage share of units sold."],
     "table": {"head": ["Brand", "2023 share", "2024 share"], "rows": [[b, f"{s[0]}%", f"{s[1]}%"] for b, s in SHARE.items()]},
     "questions": [
        {"q": "How many of the four named brands (excluding Others) sold fewer units in 2024 than in 2023?", "opts": ["0", "1", "2", "3"], "ans": 1,
         "sol": "Units in millions: Alpha 50 → 48.4 (fell); Bravo 40 → 50.6; Coral 36 → 39.6; Delta 30 → 30.8. Only Alpha fell; Delta's share dropped but the market grew enough to lift its sales."},
        {"q": "How many million units did Bravo sell in 2024?", "tita": True, "ans": "50.6",
         "sol": "23% of 220 million = 50.6 million."},
        {"q": "By what percentage did Bravo's unit sales grow from 2023 to 2024?", "tita": True, "ans": "26.5",
         "sol": "50.6 / 40 = 1.265, a growth of 26.5%."},
        {"q": "Which of the following gained the most units from 2023 to 2024?", "opts": ["Bravo", "Coral", "Delta", "Others"], "ans": 0,
         "sol": "Gains in millions: Bravo 10.6, Coral 3.6, Delta 0.8, Others 6.6."},
     ]},
    {"title": "Set 5",
     "intro": ["The table shows the medals won by five teams at a regional games. Teams can be ranked either by golds (with silvers and then bronzes breaking ties) or by points, with 3 points for a gold, 2 for a silver and 1 for a bronze."],
     "table": {"head": ["Team", "Gold", "Silver", "Bronze"], "rows": [[t, *map(str, m)] for t, m in MEDALS.items()]},
     "questions": [
        {"q": "Which team ranks first when ranked by golds?", "opts": ["Teal", "Rust", "Plum", "Sage"], "ans": 0,
         "sol": "Teal has the most golds, 8."},
        {"q": "Which team ranks first when ranked by points?", "opts": ["Teal", "Rust", "Plum", "Sage"], "ans": 1,
         "sol": "Points: Teal 35, Rust 40, Plum 35, Sage 37, Ochre 35. Rust's 9 silvers carry it to the top."},
        {"q": "How many teams finish with exactly 35 points?", "opts": ["3", "4", "5", "6"], "ans": 0,
         "sol": "Teal, Plum and Ochre each have 35."},
        {"q": "Keeping silver at 2 points and bronze at 1, what is the smallest whole number of points a gold would have to be worth for Teal to score more than Rust?", "tita": True, "ans": "6",
         "sol": "With g points per gold: Teal 8g + 11, Rust 6g + 22. Teal leads when 2g > 11, i.e. g ≥ 6."},
     ]},
]


def verify():
    ts = table_solutions()
    assert len(ts) == 2
    for seat, d in ts:
        by = {v: k for k, v in seat.items()}
        assert by[(seat["G"] + 3) % 6] == "K" and d["J"] == "water" and d["F"] == "juice"

    grow = {c: Fr(v[2], v[0]) for c, v in ARRIVALS.items()}
    assert max(grow, key=grow.get) == "UAE"
    t = [sum(v[i] for v in ARRIVALS.values()) for i in range(3)]
    assert t[2] == 474 and t[2] - t[1] == 65
    assert sum(1 for v in ARRIVALS.values() if v[0] < v[1] < v[2]) == 4
    assert round(Fr(165, 474) * 100) == 35

    assert bill(250) == 1250 and bill(450) == 2750 and bill(350) == 1950
    assert Fr(bill(400), 400) == Fr(575, 100)
    assert bill(500) - (bill(150) + bill(350)) == 600

    assert sum(1 for b in SHARE if b != "Others" and units(b, 1) < units(b, 0)) == 1
    assert units("Bravo", 1) == Fr(506, 10) and (units("Bravo", 1) / units("Bravo", 0) - 1) * 100 == Fr(265, 10)
    gains = {b: units(b, 1) - units(b, 0) for b in ("Bravo", "Coral", "Delta", "Others")}
    assert max(gains, key=gains.get) == "Bravo"

    assert max(MEDALS, key=lambda t: MEDALS[t]) == "Teal" and max(MEDALS, key=points) == "Rust"
    assert sum(1 for t in MEDALS if points(t) == 35) == 3
    assert next(g for g in range(1, 20) if points("Teal", g) > points("Rust", g)) == 6
    return "DILR: all 22 keys match the solvers"
