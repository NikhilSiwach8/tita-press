"""Full Mock 14 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: chores ----------
FRIENDS = "VWXYZ"
CHORES = ["cook", "clean", "shop", "laundry", "garden"]
WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

def chore_solutions():
    out = []
    for days in permutations(range(5)):
        d = dict(zip(FRIENDS, days))
        if d["V"] >= d["W"] or d["W"] != 2 or abs(d["X"] - d["Y"]) != 3: continue
        for ch in permutations(CHORES):
            c = dict(zip(FRIENDS, ch)); w = {v: k for k, v in c.items()}
            if c["Z"] != "garden" or d["Z"] != 4: continue
            if d[w["shop"]] != d[w["cook"]] - 1 or c["V"] != "cook": continue
            if c["Y"] in ("garden", "laundry") or d[w["laundry"]] == 0 or c["X"] == "cook": continue
            out.append((d, c))
    return out

# ---------- Set 2: roads ----------
ROADS = {("K", "L"): 12, ("K", "M"): 20, ("L", "M"): 6, ("L", "N"): 15, ("M", "N"): 8, ("M", "O"): 14, ("N", "O"): 5, ("N", "P"): 18, ("O", "P"): 10}

def routes(roads, s="K", t="P"):
    g = {}
    for (a, b), w in roads.items():
        g.setdefault(a, []).append((b, w)); g.setdefault(b, []).append((a, w))
    out = []
    def walk(u, seen, dist):
        if u == t: out.append(dist); return
        for v, w in g[u]:
            if v not in seen: walk(v, seen | {v}, dist + w)
    walk(s, {s}, 0)
    return sorted(out)

# ---------- Set 3: enrolment ----------
COURSES = {"BBA": (240, 35), "BCom": (300, 50), "BSc": (180, 40), "BA": (280, 65)}
def women(c): n, p = COURSES[c]; return Fr(n * p, 100)

# ---------- Set 4: restaurant ----------
PRICE = {"Dosa": 80, "Thali": 150, "Biryani": 220, "Coffee": 40}
ORDERS = {"Dosa": (60, 80, 90), "Thali": (40, 55, 70), "Biryani": (30, 50, 45), "Coffee": (100, 120, 150)}
DAYS = ["Friday", "Saturday", "Sunday"]
def revenue(dish, day): return PRICE[dish] * ORDERS[dish][day]

# ---------- Set 5: savings ----------
PRINCIPAL = 100000
def saral(years): return PRINCIPAL * (1 + Fr(8, 100) * years)              # 8% simple
def vriddhi(years): return PRINCIPAL * Fr(1075, 1000) ** years             # 7.5% compounded yearly
def nidhi(years): return PRINCIPAL * Fr(1035, 1000) ** (2 * years)         # 7% compounded half-yearly


SETS = [
    {"title": "Set 1",
     "intro": ["Five friends, V, W, X, Y and Z, share five household chores: cooking, cleaning, shopping, laundry and gardening. Each does exactly one chore, on a different weekday from Monday to Friday. The following is known:",
               "1. V works on an earlier day than W, and W works on Wednesday.",
               "2. X and Y work exactly three days apart.",
               "3. Z does the gardening, on Friday.",
               "4. The shopping is done on the day immediately before the cooking, and V does the cooking.",
               "5. Y does neither the gardening nor the laundry; the laundry is not done on Monday; X does not cook."],
     "questions": [
        {"q": "On which day does V work?", "opts": ["Monday", "Tuesday", "Wednesday", "Thursday"], "ans": 1,
         "sol": "Z is on Friday and W on Wednesday, so X and Y, three days apart, take Monday and Thursday. V, before W, works on Tuesday."},
        {"q": "On which day is the shopping done?", "opts": ["Monday", "Tuesday", "Wednesday", "Thursday"], "ans": 0,
         "sol": "V cooks on Tuesday, so the shopping is done on Monday."},
        {"q": "How many complete schedules (day and chore for everyone) satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "Monday's shopper is X or Y. W (Wednesday) and the Thursday worker share cleaning and laundry. If X shops on Monday, Y is on Thursday and must clean (not laundry), so W does laundry: 1 schedule. If Y shops, X is on Thursday and either chore order works: 2 schedules. Three in all."},
        {"q": "If Y works on Thursday, which chore does W do?", "opts": ["Cleaning", "Laundry", "Shopping", "Cooking"], "ans": 1,
         "sol": "Then X shops on Monday, and Y on Thursday must clean, leaving the laundry to W."},
     ]},
    {"title": "Set 2",
     "intro": ["Six towns, K, L, M, N, O and P, are joined by the two-way roads listed below with their lengths in km. A route may not pass through the same town twice.",
               "K–L 12; K–M 20; L–M 6; L–N 15; M–N 8; M–O 14; N–O 5; N–P 18; O–P 10."],
     "questions": [
        {"q": "What is the length of the shortest route from K to P, in km?", "tita": True, "ans": "41",
         "sol": "K–L–M–N–O–P = 12 + 6 + 8 + 5 + 10 = 41. The next best routes, K–L–M–O–P and K–L–N–O–P, are 42."},
        {"q": "How many different routes from K to P have a length of 42 km or less?", "opts": ["3", "4", "5", "6"], "ans": 0,
         "sol": "41 (K–L–M–N–O–P) and two of 42 (K–L–M–O–P and K–L–N–O–P): three routes."},
        {"q": "If the road N–O were closed, what would the shortest route from K to P be, in km?", "opts": ["42", "43", "44", "45"], "ans": 0,
         "sol": "K–L–M–O–P = 12 + 6 + 14 + 10 = 42 is still available and is now the shortest."},
        {"q": "If the road L–M were closed, what would the shortest route from K to P be, in km?", "tita": True, "ans": "42",
         "sol": "K–L–N–O–P = 12 + 15 + 5 + 10 = 42; K–M–N–O–P is 43."},
        {"q": "What is the shortest distance from L to O, in km?", "opts": ["17", "19", "20", "22"], "ans": 1,
         "sol": "L–M–N–O = 6 + 8 + 5 = 19, shorter than L–N–O (20) and L–M–O (20)."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the number of students in four undergraduate courses at a college and the percentage of them who are women."],
     "table": {"head": ["Course", "Students", "Women"], "rows": [[c, str(n), f"{p}%"] for c, (n, p) in COURSES.items()]},
     "questions": [
        {"q": "How many women study in the four courses together?", "tita": True, "ans": "488",
         "sol": "84 + 150 + 72 + 182 = 488."},
        {"q": "Which course has the most men?", "opts": ["BBA", "BCom", "BSc", "BA"], "ans": 0,
         "sol": "Men: BBA 156, BCom 150, BSc 108, BA 98. BBA has the most, though BCom is larger."},
        {"q": "Approximately what percentage of all the students are women?", "opts": ["46%", "47%", "48%", "49%"], "ans": 3,
         "sol": "488 / 1,000 = 48.8%, approximately 49%."},
        {"q": "If 60 more women joined BSc, what percentage of BSc students would be women?", "tita": True, "ans": "55",
         "sol": "(72 + 60)/(180 + 60) = 132/240 = 55%."},
     ]},
    {"title": "Set 4",
     "intro": ["A restaurant sells four items at fixed prices: Dosa ₹80, Thali ₹150, Biryani ₹220 and Coffee ₹40. The table shows the number of orders for each over a weekend."],
     "table": {"head": ["Item", "Friday", "Saturday", "Sunday"], "rows": [[d, *map(str, o)] for d, o in ORDERS.items()]},
     "questions": [
        {"q": "What was the restaurant's revenue on Saturday, in rupees?", "tita": True, "ans": "30450",
         "sol": "80 × 80 + 55 × 150 + 50 × 220 + 120 × 40 = 6,400 + 8,250 + 11,000 + 4,800 = ₹30,450."},
        {"q": "Which item brought in the most revenue over the three days?", "opts": ["Dosa", "Thali", "Biryani", "Coffee"], "ans": 2,
         "sol": "Three-day revenue: Dosa 18,400; Thali 24,750; Biryani 27,500; Coffee 14,800."},
        {"q": "On which day was the revenue the highest?", "opts": ["Friday", "Saturday", "Sunday", "Saturday and Sunday equally"], "ans": 2,
         "sol": "Friday 21,400; Saturday 30,450; Sunday 33,600."},
        {"q": "What percentage of Sunday's revenue came from Thali? Give your answer to the nearest whole number.", "tita": True, "ans": "31",
         "sol": "70 × 150 = 10,500 of 33,600 = 31.25%, which rounds to 31."},
        {"q": "If the Biryani price were cut by 10% and Sunday's Biryani orders rose by 20% as a result, by how many rupees would Sunday's Biryani revenue change?", "opts": ["Fall of 792", "No change", "Rise of 792", "Rise of 1,980"], "ans": 2,
         "sol": "New revenue: 54 × 198 = 10,692 versus 45 × 220 = 9,900. A rise of ₹792 (the factor is 0.9 × 1.2 = 1.08)."},
     ]},
    {"title": "Set 5",
     "intro": ["A bank offers three schemes for a deposit of ₹1,00,000. Saral pays 8% a year simple interest. Vriddhi pays 7.5% a year compounded annually. Nidhi pays 7% a year compounded every six months (3.5% per half-year)."],
     "questions": [
        {"q": "Which scheme gives the largest amount after 3 years?", "opts": ["Saral", "Vriddhi", "Nidhi", "Saral and Vriddhi equally"], "ans": 1,
         "sol": "After 3 years: Saral 1,24,000; Vriddhi 1,00,000 × 1.075³ = 1,24,229.69; Nidhi 1,00,000 × 1.035⁶ = 1,22,925.53."},
        {"q": "Which scheme gives the largest amount after 2 years?", "opts": ["Saral", "Vriddhi", "Nidhi", "Vriddhi and Nidhi equally"], "ans": 0,
         "sol": "After 2 years: Saral 1,16,000; Vriddhi 1,15,562.50; Nidhi 1,00,000 × 1.035⁴ = 1,14,752.30. Simple interest is ahead early; compounding catches up later."},
        {"q": "After 3 years, what is the difference between the largest and smallest amounts, to the nearest rupee?", "tita": True, "ans": "1304",
         "sol": "1,24,229.69 − 1,22,925.53 = 1,304.16, about ₹1,304."},
        {"q": "How much interest, in rupees, does Saral pay in total over 3 years?", "tita": True, "ans": "24000",
         "sol": "8% of 1,00,000 for 3 years: 3 × 8,000 = ₹24,000."},
     ]},
]


def verify():
    cs = chore_solutions()
    assert len(cs) == 3 and all(d["V"] == 1 for d, _ in cs)
    assert all(d[next(p for p in FRIENDS if c[p] == "shop")] == 0 for d, c in cs)
    assert {c["W"] for d, c in cs if d["Y"] == 3} == {"laundry"}

    r = routes(ROADS)
    assert r[0] == 41 and sum(1 for x in r if x <= 42) == 3
    assert routes({k: v for k, v in ROADS.items() if k != ("N", "O")})[0] == 42
    assert routes({k: v for k, v in ROADS.items() if k != ("L", "M")})[0] == 42
    assert routes(ROADS, "L", "O")[0] == 19

    tw = sum(women(c) for c in COURSES)
    assert tw == 488 and round(tw * 100 / 1000) == 49
    men = {c: COURSES[c][0] - women(c) for c in COURSES}
    assert max(men, key=men.get) == "BBA"
    assert Fr(72 + 60, 240) * 100 == 55

    day = [sum(revenue(d, i) for d in PRICE) for i in range(3)]
    assert day == [21400, 30450, 33600] and day.index(max(day)) == 2
    three = {d: sum(revenue(d, i) for i in range(3)) for d in PRICE}
    assert max(three, key=three.get) == "Biryani"
    assert round(Fr(revenue("Thali", 2) * 100, day[2])) == 31
    assert Fr(220 * 9, 10) * Fr(45 * 12, 10) - revenue("Biryani", 2) == 792

    three_yr = {"Saral": saral(3), "Vriddhi": vriddhi(3), "Nidhi": nidhi(3)}
    assert max(three_yr, key=three_yr.get) == "Vriddhi"
    two_yr = {"Saral": saral(2), "Vriddhi": vriddhi(2), "Nidhi": nidhi(2)}
    assert max(two_yr, key=two_yr.get) == "Saral"
    assert round(max(three_yr.values()) - min(three_yr.values())) == 1304
    assert saral(3) - PRINCIPAL == 24000
    return "DILR: all 22 keys match the solvers"
