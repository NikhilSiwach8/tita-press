"""Full Mock 15 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import combinations, permutations
from math import comb

# ---------- Set 1: bookshelf ----------
SUBJECTS = ["History", "Poetry", "Science", "Travel", "Art"]
COLOURS = ["red", "blue", "green", "black", "white"]

def shelf_solutions():
    out = []
    for subj in permutations(SUBJECTS):
        p = {s: i for i, s in enumerate(subj)}
        if p["History"] != 0 or p["Poetry"] != 1 or p["Science"] in (0, 4) or abs(p["Art"] - p["Travel"]) == 1: continue
        for col in permutations(COLOURS):
            c = dict(zip(subj, col)); w = {v: k for k, v in c.items()}
            if p[w["red"]] != 0 or abs(p[w["blue"]] - p[w["green"]]) != 2 or p[w["white"]] < p[w["black"]]: continue
            if c["Science"] != "white" or c["Art"] in ("red", "white") or c["History"] == "blue": continue
            out.append((subj, c))
    return out

# ---------- Set 2: air quality ----------
AQI = {"Delhi": (180, 320, 380, 300), "Mumbai": (110, 150, 170, 140), "Kolkata": (120, 190, 230, 200),
       "Bengaluru": (70, 90, 100, 95), "Chennai": (60, 85, 95, 80)}
MONTHS = ["October", "November", "December", "January"]
def band(v): return "good" if v <= 50 else "satisfactory" if v <= 100 else "moderate" if v <= 200 else "poor" if v <= 300 else "very poor"

# ---------- Set 3: trips ----------
TRIPS = {"Mumbai": (150, 320), "Nashik": (210, 150), "Satara": (110, 120)}  # km, toll each way
def trip_cost(dest, price=100, mileage=15):
    km, toll = TRIPS[dest]
    return Fr(km * price, mileage) + toll

# ---------- Set 4: ratings ----------
RATINGS = {"Students": (120, Fr(42, 10)), "Professionals": (200, Fr(36, 10)), "Retirees": (80, Fr(39, 10)), "Homemakers": (100, Fr(4))}
def overall(extra_n=0, extra_score=0):
    pts = sum(n * r for n, r in RATINGS.values()) + extra_n * extra_score
    return pts / (sum(n for n, _ in RATINGS.values()) + extra_n)

# ---------- Set 5: chess club ----------
GAMES = 45
def members(): return next(n for n in range(2, 100) if comb(n, 2) == GAMES)


SETS = [
    {"title": "Set 1",
     "intro": ["Five books, on History, Poetry, Science, Travel and Art, stand in a row on a shelf, in positions 1 to 5 from left to right. Each has a different cover colour: red, blue, green, black or white. The following is known:",
               "1. The History book is at the left end, with the Poetry book immediately to its right.",
               "2. The Science book is at neither end, and the Art and Travel books are not next to each other.",
               "3. The red book is at the left end, and the white book is somewhere to the right of the black book.",
               "4. Exactly one book stands between the blue book and the green book.",
               "5. The Science book is white; the Art book is neither red nor white; the History book is not blue."],
     "questions": [
        {"q": "What colour is the Poetry book?", "opts": ["Blue", "Green", "Black", "White"], "ans": 2,
         "sol": "History (position 1) is red. Science, not at an end, sits in position 3 or 4, and Art and Travel, not adjacent, need positions 3 and 5, so Science is in position 4. Science is white, so black must be to its left: in position 2 or 3. Blue and green are two apart; with red in 1 and white in 4, they must be in 3 and 5, leaving black for position 2, the Poetry book."},
        {"q": "Which book is in position 4?", "opts": ["Poetry", "Science", "Travel", "Art"], "ans": 1,
         "sol": "From the reasoning above, Science is in position 4."},
        {"q": "How many complete arrangements of books and colours satisfy all the conditions?", "tita": True, "ans": "4",
         "sol": "Art and Travel can take positions 3 and 5 either way, and blue and green can take positions 3 and 5 either way: 2 × 2 = 4."},
        {"q": "If the Art book is in position 5 and is green, what colour is the Travel book?", "opts": ["Red", "Blue", "Black", "White"], "ans": 1,
         "sol": "Travel is then in position 3, which holds the other of blue and green: blue."},
     ]},
    {"title": "Set 2",
     "intro": ["The table shows the average Air Quality Index (AQI) in five cities over four months. AQI bands are: up to 50 good, 51–100 satisfactory, 101–200 moderate, 201–300 poor, and 301–400 very poor."],
     "table": {"head": ["City", *MONTHS], "rows": [[c, *map(str, v)] for c, v in AQI.items()]},
     "questions": [
        {"q": "In how many of the twenty city-months was the air quality poor or very poor?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "Delhi in November (320), December (380) and January (300), and Kolkata in December (230): four."},
        {"q": "Which city's AQI rose by the largest percentage from October to December?", "opts": ["Delhi", "Mumbai", "Kolkata", "Chennai"], "ans": 0,
         "sol": "Delhi 111%, Mumbai 55%, Kolkata 92%, Bengaluru 43%, Chennai 58%."},
        {"q": "What was Bengaluru's average AQI over the four months?", "tita": True, "ans": "88.75",
         "sol": "(70 + 90 + 100 + 95)/4 = 355/4 = 88.75."},
        {"q": "In how many cities was the air quality satisfactory or better in all four months?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "Bengaluru (highest 100) and Chennai (highest 95): two."},
        {"q": "In which month was the average AQI across the five cities the highest?", "opts": ["October", "November", "December", "January"], "ans": 2,
         "sol": "Totals: October 540, November 835, December 975, January 815."},
     ]},
    {"title": "Set 3",
     "intro": ["A family drives from Pune to one of three cities. Their car runs 15 km on a litre of petrol, which costs ₹100 a litre. Each one-way trip also pays a toll. Distances and one-way tolls: Mumbai 150 km, ₹320; Nashik 210 km, ₹150; Satara 110 km, ₹120."],
     "questions": [
        {"q": "What is the total cost of a return trip to Mumbai, in rupees?", "tita": True, "ans": "2640",
         "sol": "One way: 150/15 = 10 litres = ₹1,000, plus ₹320 toll = ₹1,320. Return: ₹2,640."},
        {"q": "Which destination has the lowest one-way cost per km?", "opts": ["Mumbai", "Nashik", "Satara", "Mumbai and Satara equally"], "ans": 1,
         "sol": "Per km: Mumbai 1,320/150 = ₹8.80; Nashik (1,400 + 150)/210 = ₹7.38; Satara (733.33 + 120)/110 = ₹7.76."},
        {"q": "If petrol rose to ₹110 a litre, by how many rupees would the one-way cost to Mumbai rise?", "tita": True, "ans": "100",
         "sol": "10 litres × ₹10 more = ₹100."},
        {"q": "Which one-way trip has the highest total cost?", "opts": ["Mumbai", "Nashik", "Satara", "Mumbai and Nashik equally"], "ans": 1,
         "sol": "Mumbai 1,320; Nashik 1,550; Satara 853.33."},
     ]},
    {"title": "Set 4",
     "intro": ["A product was rated on a scale of 1 to 5 by four groups of customers. The table gives the number of customers in each group and the group's average rating."],
     "table": {"head": ["Group", "Customers", "Average rating"], "rows": [[g, str(n), f"{float(r):.1f}"] for g, (n, r) in RATINGS.items()]},
     "questions": [
        {"q": "What is the average rating across all 500 customers? Give your answer to three decimal places.", "tita": True, "ans": "3.872",
         "sol": "Total points: 504 + 720 + 312 + 400 = 1,936. 1,936 / 500 = 3.872."},
        {"q": "Which group contributed the most rating points in total?", "opts": ["Students", "Professionals", "Retirees", "Homemakers"], "ans": 1,
         "sol": "Professionals: 200 × 3.6 = 720, the most despite the lowest average."},
        {"q": "How many of the four groups gave an average rating above the overall average?", "opts": ["0", "1", "2", "3"], "ans": 3,
         "sol": "Students (4.2), Retirees (3.9) and Homemakers (4.0) are above 3.872: three."},
        {"q": "If 50 more professionals each rated the product 5, what would the overall average become? Give your answer to two decimal places.", "tita": True, "ans": "3.97",
         "sol": "(1,936 + 250)/550 = 2,186/550 = 3.9745, which is 3.97 to two decimal places."},
     ]},
    {"title": "Set 5",
     "intro": ["In a chess club tournament, every member played every other member exactly once. 45 games were played in all. A win earned 1 point, a draw ½ point to each player, and a loss 0."],
     "questions": [
        {"q": "How many members took part?", "tita": True, "ans": "10",
         "sol": "n(n − 1)/2 = 45 gives n = 10."},
        {"q": "If two more members had joined and also played everyone once, how many additional games would have been played?", "opts": ["21", "24", "33", "45"], "ans": 0,
         "sol": "With 12 members: C(12, 2) = 66 games, which is 21 more."},
        {"q": "How many points were awarded in total across the tournament?", "opts": ["9", "10", "40", "45"], "ans": 3,
         "sol": "Every game awards exactly 1 point in total (1 + 0 or ½ + ½): 45 points."},
        {"q": "What is the smallest number of points the tournament winner (the member with the most points) could have scored?", "opts": ["4", "4.5", "5", "9"], "ans": 1,
         "sol": "The 45 points are shared among 10 players, an average of 4.5, so the top scorer has at least 4.5. If every game were drawn, everyone would have exactly 4.5."},
        {"q": "What is the largest number of points any single member could have scored?", "tita": True, "ans": "9",
         "sol": "Each member plays 9 games, so at most 9 points."},
     ]},
]


def verify():
    ss = shelf_solutions()
    assert len(ss) == 4 and all(c["Poetry"] == "black" and s[3] == "Science" for s, c in ss)
    assert {c["Travel"] for s, c in ss if s[4] == "Art" and c["Art"] == "green"} == {"blue"}

    assert sum(1 for v in AQI.values() for x in v if band(x) in ("poor", "very poor")) == 4
    g = {c: Fr(v[2], v[0]) for c, v in AQI.items()}
    assert max(g, key=g.get) == "Delhi"
    assert Fr(sum(AQI["Bengaluru"]), 4) == Fr(8875, 100)
    assert sum(1 for v in AQI.values() if all(x <= 100 for x in v)) == 2
    m = [sum(v[i] for v in AQI.values()) for i in range(4)]
    assert MONTHS[m.index(max(m))] == "December"

    assert 2 * trip_cost("Mumbai") == 2640
    per_km = {d: trip_cost(d) / TRIPS[d][0] for d in TRIPS}
    assert min(per_km, key=per_km.get) == "Nashik"
    assert trip_cost("Mumbai", 110) - trip_cost("Mumbai") == 100
    assert max(TRIPS, key=trip_cost) == "Nashik"

    assert overall() == Fr(3872, 1000)
    assert max(RATINGS, key=lambda g: RATINGS[g][0] * RATINGS[g][1]) == "Professionals"
    assert sum(1 for n, r in RATINGS.values() if r > overall()) == 3
    assert round(float(overall(50, 5)), 2) == 3.97

    n = members()
    assert n == 10 and comb(12, 2) - 45 == 21 and Fr(GAMES, n) == Fr(9, 2) and n - 1 == 9
    return "DILR: all 22 keys match the solvers"
