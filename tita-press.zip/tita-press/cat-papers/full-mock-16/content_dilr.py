"""Full Mock 16 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: ranks ----------
STUDENTS = "PQRSTU"

def rank_solutions():
    out = []
    for m in permutations(range(1, 7)):
        M = dict(zip(STUDENTS, m))
        if M["P"] not in (1, 2) or M["Q"] <= M["R"] or M["U"] != 6 or M["R"] not in (2, 3): continue
        for e in permutations(range(1, 7)):
            E = dict(zip(STUDENTS, e))
            if any(M[s] == E[s] for s in STUDENTS) or E["P"] != 6 or E["Q"] != 1: continue
            if M["S"] + E["S"] != 7 or abs(M["T"] - E["T"]) != 1 or E["R"] >= E["S"]: continue
            out.append((M, E))
    return out

# ---------- Set 2: hotel ----------
ROOMS = 120
HOTEL = {"January": (31, 65, 4000), "February": (28, 70, 4000), "March": (31, 80, 4500),
         "April": (30, 90, 5000), "May": (31, 75, 4500), "June": (30, 60, 3800)}  # days, occupancy %, rate
def nights(m): d, o, _ = HOTEL[m]; return Fr(ROOMS * d * o, 100)
def revenue(m): return nights(m) * HOTEL[m][2]

# ---------- Set 3: staff ----------
STAFF = {"Sales": (120, 30, 36), "Tech": (200, 50, 30), "HR": (30, 5, 6), "Operations": (150, 20, 24)}  # start, joined, left

# ---------- Set 4: cabs ----------
CABS = {"X": (50, 12), "Y": (80, 10), "Z": (0, 15)}  # base fare, per km
def fare(c, km, wait=0): b, r = CABS[c]; return b + r * km + 2 * wait

# ---------- Set 5: tank ----------
INFLOW = (3000, 0, 4000, 0, 2500)
OUTFLOW = (2500, 2800, 3200, 2600, 2900)
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
def levels(start=8000):
    out, s = [], start
    for i, o in zip(INFLOW, OUTFLOW): s += i - o; out.append(s)
    return out


SETS = [
    {"title": "Set 1",
     "intro": ["Six students, P, Q, R, S, T and U, were ranked 1 (best) to 6 in Maths and separately 1 to 6 in English, with no ties in either subject. The following is known:",
               "1. No student had the same rank in both subjects.",
               "2. P ranked first or second in Maths but last in English. U ranked last in Maths.",
               "3. Q ranked first in English, and R ranked above Q in Maths.",
               "4. R ranked second or third in Maths, and above S in English.",
               "5. S's two ranks add up to 7, and T's two ranks differ by exactly 1."],
     "questions": [
        {"q": "Who ranked first in Maths?", "opts": ["P", "Q", "R", "S"], "ans": 0,
         "sol": "Suppose P were second in Maths. First place cannot go to U (last), R (second or third), Q (below R) or S (first in Maths would need sixth in English, which is P's). So T would be first in Maths and second in English, and R third in Maths. Q and S would then share Maths ranks 4 and 5: S fourth means S third in English, but R must be above S and English ranks 1 and 2 are taken; S fifth means S second in English, which is T's. Both fail, so P is first in Maths."},
        {"q": "How many different pairs of rankings (Maths and English) satisfy all the conditions?", "tita": True, "ans": "4",
         "sol": "Enumerating the cases with P first in Maths and U last gives exactly four consistent combinations."},
        {"q": "If Q ranked fourth in Maths, what was T's rank in English?", "opts": ["4", "5", "6", "7"], "ans": 0,
         "sol": "Q fourth in Maths leaves only one combination: Maths P1 S2 R3 Q4 T5 U6, English Q1 R2 U3 T4 S5 P6. T is fourth in English."},
        {"q": "Which of the following must be true?", "opts": ["S ranked higher in Maths than in English.", "R ranked second in English.", "T ranked fourth in Maths.", "U ranked second in English."], "ans": 0,
         "sol": "In all four combinations S's Maths rank (2 or 3) is better than its English rank (5 or 4). Each of the other statements fails in at least one combination."},
     ]},
    {"title": "Set 2",
     "intro": ["A 120-room hotel recorded its average occupancy (percentage of rooms filled each night) and average room rate for six months. A room-night is one room occupied for one night. January, March and May have 31 days; April and June 30; February 28."],
     "table": {"head": ["Month", "Occupancy", "Average rate (₹)"], "rows": [[m, f"{o}%", f"{r:,}"] for m, (_, o, r) in HOTEL.items()]},
     "questions": [
        {"q": "How many room-nights were sold in April?", "tita": True, "ans": "3240",
         "sol": "120 × 30 × 90% = 3,240."},
        {"q": "In which month was the hotel's room revenue the highest?", "opts": ["March", "April", "May", "June"], "ans": 1,
         "sol": "Revenue (₹ lakh): January 96.7, February 94.1, March 133.9, April 162.0, May 125.6, June 82.1. April."},
        {"q": "Which month had a higher occupancy than January but a lower room revenue?", "opts": ["February", "March", "May", "June"], "ans": 0,
         "sol": "February's occupancy (70%) beat January's (65%), but with 3 fewer days and the same rate its revenue was 94.08 lakh against 96.72 lakh."},
        {"q": "How many room-nights were sold in the six months altogether?", "tita": True, "ans": "15936",
         "sol": "2,418 + 2,352 + 2,976 + 3,240 + 2,790 + 2,160 = 15,936."},
        {"q": "What was the hotel's overall occupancy for the six months, to the nearest whole percent?", "opts": ["70%", "71%", "72%", "73%"], "ans": 3,
         "sol": "Available room-nights: 120 × 181 = 21,720. 15,936 / 21,720 = 73.4%, about 73%."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows, for each department of a company, the number of employees at the start of a year, the number who joined during the year and the number who left. The attrition rate is the number who left as a percentage of the starting number."],
     "table": {"head": ["Department", "At start", "Joined", "Left"], "rows": [[d, *map(str, v)] for d, v in STAFF.items()]},
     "questions": [
        {"q": "Which department had the highest attrition rate?", "opts": ["Sales", "Tech", "HR", "Operations"], "ans": 0,
         "sol": "Sales 30%, Tech 15%, HR 20%, Operations 16%."},
        {"q": "How many employees did the company have at the end of the year?", "tita": True, "ans": "509",
         "sol": "Sales 114, Tech 220, HR 29, Operations 146: 509."},
        {"q": "What was the company's overall attrition rate, in percent?", "tita": True, "ans": "19.2",
         "sol": "96 left out of 500 at the start: 19.2%."},
        {"q": "Which department's headcount grew by the largest percentage over the year?", "opts": ["Sales", "Tech", "HR", "Operations"], "ans": 1,
         "sol": "Only Tech grew (200 to 220, 10%); the others shrank."},
     ]},
    {"title": "Set 4",
     "intro": ["Three cab companies charge as follows. X: ₹50 base fare plus ₹12 per km. Y: ₹80 base fare plus ₹10 per km. Z: no base fare, ₹15 per km. All three charge ₹2 per minute of waiting."],
     "questions": [
        {"q": "What does company Y charge for a 10 km trip with no waiting, in rupees?", "tita": True, "ans": "180",
         "sol": "80 + 10 × 10 = ₹180."},
        {"q": "For what trip length, in km, do X and Y charge the same (with no waiting)?", "tita": True, "ans": "15",
         "sol": "50 + 12d = 80 + 10d gives d = 15 km."},
        {"q": "Which company is cheapest for a 20 km trip with no waiting?", "opts": ["X", "Y", "Z", "X and Y equally"], "ans": 1,
         "sol": "X 290, Y 280, Z 300."},
        {"q": "Which company is cheapest for a 4 km trip with 10 minutes of waiting?", "opts": ["X", "Y", "Z", "X and Z equally"], "ans": 2,
         "sol": "Waiting adds ₹20 to each. X 118, Y 140, Z 80."},
     ]},
    {"title": "Set 5",
     "intro": ["A water tank holding up to 10,000 litres contained 8,000 litres on Monday morning. The table shows the litres pumped in and used each day; the tank never overflowed."],
     "table": {"head": ["Litres", *DAYS], "rows": [["Pumped in", *map(str, INFLOW)], ["Used", *map(str, OUTFLOW)]]},
     "questions": [
        {"q": "How many litres were in the tank at the end of Friday?", "tita": True, "ans": "3500",
         "sol": "End-of-day levels: 8,500, 5,700, 6,500, 3,900, 3,500."},
        {"q": "On which day did the level fall by the most?", "opts": ["Tuesday", "Wednesday", "Thursday", "Friday"], "ans": 0,
         "sol": "Net changes: Monday +500, Tuesday −2,800, Wednesday +800, Thursday −2,600, Friday −400."},
        {"q": "On how many days did the level fall?", "opts": ["3", "4", "5", "6"], "ans": 0,
         "sol": "Tuesday, Thursday and Friday: three."},
        {"q": "What was the average amount used per day, in litres?", "opts": ["2,600", "2,700", "2,800", "2,900"], "ans": 2,
         "sol": "(2,500 + 2,800 + 3,200 + 2,600 + 2,900)/5 = 14,000/5 = 2,800."},
        {"q": "If 2,700 litres are used on Saturday, how many litres must be pumped in on Saturday for the tank to be at least half full at the end of the day?", "tita": True, "ans": "4200",
         "sol": "Half full is 5,000 litres. 3,500 + x − 2,700 ≥ 5,000 gives x ≥ 4,200."},
     ]},
]


def verify():
    rs = rank_solutions()
    assert len(rs) == 4 and all(M["P"] == 1 for M, _ in rs)
    assert {E["T"] for M, E in rs if M["Q"] == 4} == {4}
    assert all(M["S"] < E["S"] for M, E in rs)
    assert not all(E["R"] == 2 for _, E in rs) and not all(M["T"] == 4 for M, _ in rs) and not all(E["U"] == 2 for _, E in rs)

    assert nights("April") == 3240
    assert max(HOTEL, key=revenue) == "April"
    assert [m for m in HOTEL if HOTEL[m][1] > 65 and revenue(m) < revenue("January")] == ["February"]
    total = sum(nights(m) for m in HOTEL)
    assert total == 15936 and round(total * 100 / (ROOMS * 181)) == 73

    rate = {d: Fr(v[2], v[0]) for d, v in STAFF.items()}
    assert max(rate, key=rate.get) == "Sales"
    assert sum(a + j - l for a, j, l in STAFF.values()) == 509
    assert Fr(sum(v[2] for v in STAFF.values()) * 100, sum(v[0] for v in STAFF.values())) == Fr(192, 10)
    g = {d: Fr(a + j - l, a) for d, (a, j, l) in STAFF.items()}
    assert max(g, key=g.get) == "Tech"

    assert fare("Y", 10) == 180 and next(d for d in range(100) if fare("X", d) == fare("Y", d)) == 15
    assert min(CABS, key=lambda c: fare(c, 20)) == "Y" and min(CABS, key=lambda c: fare(c, 4, 10)) == "Z"

    lv = levels()
    assert lv[-1] == 3500 and max(lv) <= 10000
    change = [b - a for a, b in zip([8000] + lv, lv)]
    assert DAYS[change.index(min(change))] == "Tuesday" and sum(1 for c in change if c < 0) == 3
    assert Fr(sum(OUTFLOW), 5) == 2800
    assert 5000 - lv[-1] + 2700 == 4200
    return "DILR: all 22 keys match the solvers"
