"""Full Mock 17 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: box stack ----------
BOXES = "JKLMN"

def stack_solutions():
    out = []
    for order in permutations(BOXES):  # index 0 = bottom
        pos = {b: i for i, b in enumerate(order)}
        if order[0] != "M" or pos["J"] != pos["K"] + 1 or pos["L"] in (0, 4): continue
        for w in permutations((2, 4, 6, 8, 10)):
            wt = dict(zip(BOXES, w))
            if wt["M"] != 10 or wt["N"] <= wt["L"] or wt[order[4]] != 2 or wt["J"] == 4: continue
            if sum(1 for i in range(4) if wt[order[i + 1]] > wt[order[i]]) != 1: continue
            out.append(("".join(order), wt))
    return out

# ---------- Set 2: batteries ----------
PHONES = {"Nova": (5000, Fr(20), 80), "Pixo": (4500, Fr(39, 2), 60), "Quark": (6000, Fr(22), 100), "Zen": (4000, Fr(18), 45)}
def per_1000(p): mah, h, _ = PHONES[p]; return h * 1000 / mah
def charge_rate(p): mah, _, mins = PHONES[p]; return Fr(mah, mins)

# ---------- Set 3: batting ----------
RUNS = {"Iqbal": (45, 12, 78, 30), "Joshi": (60, 55, 8, 41), "Kumar": (5, 88, 34, 50), "Lobo": (22, 40, 61, 19)}

# ---------- Set 4: wheat ----------
WHEAT = {"Punjab": (35, Fr(5)), "Haryana": (25, Fr(46, 10)), "Uttar Pradesh": (98, Fr(34, 10)), "Madhya Pradesh": (60, Fr(32, 10))}
def output(s): a, y = WHEAT[s]; return a * y

# ---------- Set 5: coins ----------
def ways(total=50, coins=(5, 10, 20), at_least_one=False):
    out = []
    a5, a10, a20 = coins[0], coins[1], coins[2] if len(coins) > 2 else None
    for c in range(0, total // 20 + 1 if a20 else 1):
        for b in range(0, (total - 20 * c) // 10 + 1):
            rest = total - 20 * c - 10 * b
            if rest % 5: continue
            a = rest // 5
            if at_least_one and min(a, b, c) < 1: continue
            out.append((a, b, c))
    return out


SETS = [
    {"title": "Set 1",
     "intro": ["Five boxes, J, K, L, M and N, weighing 2, 4, 6, 8 and 10 kg (each a different weight), are stacked in a single pile. The following is known:",
               "1. M is at the bottom of the pile and weighs 10 kg.",
               "2. J sits directly on top of K, and L is not at the top.",
               "3. N is heavier than L.",
               "4. The box at the top weighs 2 kg, and J does not weigh 4 kg.",
               "5. In exactly one place in the pile does a box rest on a box lighter than itself."],
     "questions": [
        {"q": "Which box is at the top of the pile?", "opts": ["J", "K", "L", "N"], "ans": 0,
         "sol": "The top box is not M (bottom) or L (clue 2), and not K, since J sits on K. If N were on top it would weigh 2 kg, but N must be heavier than L, which is impossible. So J is on top, with K directly below it."},
        {"q": "Which box is directly below J?", "opts": ["K", "L", "M", "N"], "ans": 0,
         "sol": "Clue 2: J sits directly on K."},
        {"q": "How many complete arrangements (order and weights) satisfy all the conditions?", "tita": True, "ans": "4",
         "sol": "M (10) is at the bottom and J (2) at the top with K below it. L and N take the two middle places in either order, and their weights, with K's, must create exactly one heavier-on-lighter step and keep N heavier than L. Checking the cases leaves four arrangements: M L N K J with weights 10 6 8 4 2 or 10 4 8 6 2, and M N L K J with weights 10 8 4 6 2 or 10 6 4 8 2."},
        {"q": "If L weighs 6 kg, which box is second from the bottom?", "opts": ["J", "K", "L", "N"], "ans": 2,
         "sol": "Only the arrangement M L N K J with weights 10, 6, 8, 4, 2 gives L 6 kg, and there L is second from the bottom."},
     ]},
    {"title": "Set 2",
     "intro": ["A review site tested four phones. The table gives each phone's battery capacity, the hours of continuous video it played on a full charge, and the minutes taken to charge from empty to full."],
     "table": {"head": ["Phone", "Battery (mAh)", "Video playback (hours)", "Full charge (minutes)"],
               "rows": [[p, f"{m:,}", f"{float(h):g}", str(c)] for p, (m, h, c) in PHONES.items()]},
     "questions": [
        {"q": "Which phone gives the most hours of playback per 1,000 mAh of battery?", "opts": ["Nova", "Pixo", "Quark", "Zen"], "ans": 3,
         "sol": "Hours per 1,000 mAh: Nova 4.0, Pixo 4.33, Quark 3.67, Zen 4.5."},
        {"q": "What is the average playback time of the four phones, in hours?", "tita": True, "ans": "19.875",
         "sol": "(20 + 19.5 + 22 + 18)/4 = 79.5/4 = 19.875."},
        {"q": "Which phone charges fastest, in mAh per minute?", "opts": ["Nova", "Pixo", "Quark", "Zen"], "ans": 3,
         "sol": "Nova 62.5, Pixo 75, Quark 60, Zen 88.9 mAh per minute."},
        {"q": "How many of the phones give more than 4 hours of playback per 1,000 mAh?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "Pixo (4.33) and Zen (4.5). Nova gives exactly 4."},
        {"q": "If Quark used its battery as efficiently as Zen does, how many hours of playback would it give?", "tita": True, "ans": "27",
         "sol": "At 4.5 hours per 1,000 mAh, 6,000 mAh gives 27 hours."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the runs scored by four batters in four matches of a series."],
     "table": {"head": ["Batter", "Match 1", "Match 2", "Match 3", "Match 4"], "rows": [[b, *map(str, r)] for b, r in RUNS.items()]},
     "questions": [
        {"q": "Which batter scored the most runs in the series?", "opts": ["Iqbal", "Joshi", "Kumar", "Lobo"], "ans": 2,
         "sol": "Totals: Iqbal 165, Joshi 164, Kumar 177, Lobo 142."},
        {"q": "In which match did the four batters together score the most runs?", "opts": ["Match 1", "Match 2", "Match 3", "Match 4"], "ans": 1,
         "sol": "Match totals: 132, 195, 181, 140."},
        {"q": "How many individual scores of 50 or more were made in the series?", "tita": True, "ans": "6",
         "sol": "Iqbal 78; Joshi 60, 55; Kumar 88, 50; Lobo 61: six."},
        {"q": "What is Joshi's average if his lowest score is left out?", "tita": True, "ans": "52",
         "sol": "(60 + 55 + 41)/3 = 156/3 = 52."},
     ]},
    {"title": "Set 4",
     "intro": ["The table shows the area under wheat and the average yield in four states in one year. Production equals area times yield."],
     "table": {"head": ["State", "Area (lakh hectares)", "Yield (tonnes per hectare)"],
               "rows": [[s, str(a), f"{float(y):g}"] for s, (a, y) in WHEAT.items()]},
     "questions": [
        {"q": "Which state produced the most wheat?", "opts": ["Punjab", "Haryana", "Uttar Pradesh", "Madhya Pradesh"], "ans": 2,
         "sol": "Production (lakh tonnes): Punjab 175, Haryana 115, Uttar Pradesh 333.2, Madhya Pradesh 192."},
        {"q": "What was the total production of the four states, in lakh tonnes?", "tita": True, "ans": "815.2",
         "sol": "175 + 115 + 333.2 + 192 = 815.2."},
        {"q": "What was the average yield of the four states taken together, in tonnes per hectare, to two decimal places?", "tita": True, "ans": "3.74",
         "sol": "815.2 lakh tonnes from 218 lakh hectares: 3.739, which is 3.74."},
        {"q": "If Madhya Pradesh's yield rose to Haryana's level, by how many lakh tonnes would its production increase?", "opts": ["84", "96", "108", "120"], "ans": 0,
         "sol": "60 lakh hectares × (4.6 − 3.2) = 84 lakh tonnes."},
        {"q": "In how many of the states is the share of total production greater than the share of total area?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "Punjab (21.5% of output vs 16.1% of area) and Haryana (14.1% vs 11.5%). Uttar Pradesh and Madhya Pradesh have lower yields than average, so their output shares are below their area shares. Two."},
     ]},
    {"title": "Set 5",
     "intro": ["A shopkeeper has an unlimited supply of ₹5, ₹10 and ₹20 coins. Two ways of paying are the same if they use the same number of each kind of coin, whatever the order."],
     "questions": [
        {"q": "In how many different ways can exactly ₹50 be paid?", "tita": True, "ans": "12",
         "sol": "With c twenty-rupee coins and b ten-rupee coins, the rest in fives: c = 0 allows b = 0 to 5 (6 ways); c = 1 allows b = 0 to 3 (4 ways); c = 2 allows b = 0 or 1 (2 ways). Total 12."},
        {"q": "What is the smallest number of coins with which ₹50 can be paid?", "opts": ["0", "1", "2", "3"], "ans": 3,
         "sol": "20 + 20 + 10: three coins. Two coins can make at most ₹40."},
        {"q": "In how many ways can ₹50 be paid using at least one coin of each kind?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "One ₹20 coin: 20 + 10 + four fives, or 20 + 2 × 10 + two fives. Two ₹20 coins leave ₹10, which cannot include both a ten and a five. Two ways."},
        {"q": "If no ₹20 coins were available, in how many ways could ₹50 be paid?", "opts": ["5", "6", "7", "11"], "ans": 1,
         "sol": "The number of ₹10 coins can be 0 to 5, with fives making up the rest: 6 ways."},
     ]},
]


def verify():
    ss = stack_solutions()
    assert len(ss) == 4 and all(o[4] == "J" and o[3] == "K" for o, _ in ss)
    assert {o[1] for o, w in ss if w["L"] == 6} == {"L"}

    assert max(PHONES, key=per_1000) == "Zen" and max(PHONES, key=charge_rate) == "Zen"
    assert sum(h for _, h, _ in PHONES.values()) / 4 == Fr(19875, 1000)
    assert sum(1 for p in PHONES if per_1000(p) > 4) == 2
    assert per_1000("Zen") * 6 == 27

    tot = {b: sum(r) for b, r in RUNS.items()}
    assert max(tot, key=tot.get) == "Kumar"
    m = [sum(r[i] for r in RUNS.values()) for i in range(4)]
    assert m.index(max(m)) == 1
    assert sum(1 for r in RUNS.values() for x in r if x >= 50) == 6
    assert Fr(sum(RUNS["Joshi"]) - min(RUNS["Joshi"]), 3) == 52

    prod = {s: output(s) for s in WHEAT}
    assert max(prod, key=prod.get) == "Uttar Pradesh" and sum(prod.values()) == Fr(8152, 10)
    area = sum(a for a, _ in WHEAT.values())
    assert round(float(sum(prod.values()) / area), 2) == 3.74
    assert 60 * (Fr(46, 10) - Fr(32, 10)) == 84
    assert sum(1 for s in WHEAT if prod[s] / sum(prod.values()) > Fr(WHEAT[s][0], area)) == 2

    assert len(ways()) == 12
    assert min(a + b + c for a, b, c in ways()) == 3
    assert len(ways(at_least_one=True)) == 2
    assert len([w for w in ways() if w[2] == 0]) == 6
    return "DILR: all 22 keys match the solvers"
