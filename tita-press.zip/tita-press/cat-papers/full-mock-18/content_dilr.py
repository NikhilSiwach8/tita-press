"""Full Mock 18 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
import calendar
import datetime as dt
from fractions import Fraction as Fr

# ---------- Set 1: calendar ----------
def weekday(y, m, d): return calendar.day_name[dt.date(y, m, d).weekday()]

# ---------- Set 2: ages ----------
def ages():
    for s in range(1, 100):
        f = 3 * s
        if f - 5 == 4 * (s - 5): return dict(father=f, son=s, mother=f - 4, daughter=s - 3)

# ---------- Set 3: library ----------
LOANS = {"Fiction": (420, 380, 450), "Non-fiction": (260, 300, 280), "Children's": (310, 290, 360), "Reference": (90, 110, 70)}
MONTHS = ["January", "February", "March"]

# ---------- Set 4: taxis ----------
ZONES = {"North": (1200, 8), "South": (1500, 6), "East": (900, 10), "West": (1400, 5)}  # booked, % cancelled
def cancelled(z, pct=None): n, p = ZONES[z]; return Fr(n * (p if pct is None else pct), 100)

# ---------- Set 5: budget ----------
INCOME = 80000
BUDGET = {"Rent": 25, "Food": 20, "Transport": 10, "Education": 15, "Savings": 18, "Others": 12}


SETS = [
    {"title": "Set 1",
     "intro": ["1 January 2025 was a Wednesday. 2025 is not a leap year, so it has 365 days. Answer the following without consulting a calendar."],
     "questions": [
        {"q": "On which day of the week did 26 January 2025 fall?", "opts": ["Saturday", "Sunday", "Monday", "Tuesday"], "ans": 1,
         "sol": "26 January is 25 days after 1 January. 25 = 3 weeks + 4 days, and 4 days after Wednesday is Sunday."},
        {"q": "On which day of the week did 15 August 2025 fall?", "opts": ["Thursday", "Friday", "Saturday", "Sunday"], "ans": 1,
         "sol": "Days from 1 January to 15 August: 31 + 28 + 31 + 30 + 31 + 30 + 31 + 14 = 226. 226 = 32 weeks + 2 days. Two days after Wednesday is Friday."},
        {"q": "How many Mondays were there in 2025?", "tita": True, "ans": "52",
         "sol": "365 days = 52 weeks + 1 day. Only the day the year starts on, Wednesday, occurs 53 times; every other day, Monday included, occurs 52 times."},
        {"q": "On which day of the week will 1 January 2026 fall?", "opts": ["Wednesday", "Thursday", "Friday", "Saturday"], "ans": 1,
         "sol": "A non-leap year moves the weekday forward by one: Thursday."},
     ]},
    {"title": "Set 2",
     "intro": ["A family has four members: a father, a mother, a son and a daughter. The father is three times as old as the son. Five years ago, the father was four times as old as the son was then. The mother is 4 years younger than the father, and the daughter is 3 years younger than the son."],
     "questions": [
        {"q": "How old is the father?", "tita": True, "ans": "45",
         "sol": "With the son aged s: 3s − 5 = 4(s − 5), so s = 15 and the father is 45."},
        {"q": "What is the total of the four family members' present ages?", "tita": True, "ans": "113",
         "sol": "Father 45, mother 41, son 15, daughter 12: 113."},
        {"q": "In how many years will the father be exactly twice as old as the son?", "opts": ["10", "12", "15", "20"], "ans": 2,
         "sol": "45 + x = 2(15 + x) gives x = 15."},
        {"q": "How old was the mother when the daughter was born?", "opts": ["23", "25", "27", "29"], "ans": 3,
         "sol": "41 − 12 = 29."},
     ]},
    {"title": "Set 3",
     "intro": ["The table shows the number of books a public library lent in four categories over three months."],
     "table": {"head": ["Category", *MONTHS], "rows": [[c, *map(str, v)] for c, v in LOANS.items()]},
     "questions": [
        {"q": "How many books were lent in March?", "tita": True, "ans": "1160",
         "sol": "450 + 280 + 360 + 70 = 1,160."},
        {"q": "Which category's loans grew by the largest percentage from January to March?", "opts": ["Fiction", "Non-fiction", "Children's", "Reference"], "ans": 2,
         "sol": "Fiction 7.1%, Non-fiction 7.7%, Children's 16.1%, Reference fell 22.2%."},
        {"q": "What percentage of February's loans were fiction? Give your answer to the nearest whole number.", "tita": True, "ans": "35",
         "sol": "380 / 1,080 = 35.2%, which rounds to 35."},
        {"q": "In which month were the fewest books lent?", "opts": ["January", "February", "March", "January and February equally"], "ans": 3,
         "sol": "January 1,080, February 1,080, March 1,160. January and February tie."},
        {"q": "What was the average number of reference books lent per month?", "opts": ["90", "95", "100", "105"], "ans": 0,
         "sol": "(90 + 110 + 70)/3 = 90."},
     ]},
    {"title": "Set 4",
     "intro": ["A taxi app recorded, for four zones of a city, the number of trips booked in a week and the percentage of bookings that were cancelled. All other bookings were completed."],
     "table": {"head": ["Zone", "Trips booked", "Cancelled"], "rows": [[z, f"{n:,}", f"{p}%"] for z, (n, p) in ZONES.items()]},
     "questions": [
        {"q": "How many trips were completed in all?", "tita": True, "ans": "4654",
         "sol": "Completed: North 1,104, South 1,410, East 810, West 1,330. Total 4,654."},
        {"q": "Which zone had the most cancelled trips?", "opts": ["North", "South", "East", "West"], "ans": 0,
         "sol": "Cancelled: North 96, South 90, East 90, West 70."},
        {"q": "What was the overall cancellation rate, in percent?", "tita": True, "ans": "6.92",
         "sol": "346 cancelled out of 5,000 booked: 6.92%."},
        {"q": "If the East zone had cut its cancellation rate to 5%, how many more trips would have been completed there?", "opts": ["30", "45", "60", "90"], "ans": 1,
         "sol": "Cancellations would fall from 90 to 45: 45 more completed trips."},
     ]},
    {"title": "Set 5",
     "intro": ["A family's monthly income is ₹80,000. They spend or save it in the following proportions: rent 25%, food 20%, transport 10%, education 15%, savings 18% and other expenses 12%."],
     "questions": [
        {"q": "How many rupees a month go on education?", "tita": True, "ans": "12000",
         "sol": "15% of 80,000 = ₹12,000."},
        {"q": "What is the ratio of the family's savings to its spending on food?", "opts": ["3 : 4", "9 : 10", "10 : 9", "6 : 5"], "ans": 1,
         "sol": "18% : 20% = 9 : 10."},
        {"q": "If the family's income rose by 10% but the rent stayed the same in rupees, approximately what percentage of the new income would the rent be?", "opts": ["17%", "19%", "21%", "23%"], "ans": 3,
         "sol": "Rent is ₹20,000; the new income is ₹88,000. 20,000/88,000 = 22.7%, about 23%."},
        {"q": "If the family raised its savings to ₹18,000 a month by cutting only its other expenses, what percentage of income would other expenses then be?", "tita": True, "ans": "7.5",
         "sol": "Savings rise from 14,400 to 18,000, a cut of 3,600 in other expenses: 9,600 − 3,600 = 6,000, which is 7.5% of 80,000."},
        {"q": "How much more does the family spend on rent than on transport each month, in rupees?", "opts": ["8,000", "10,000", "12,000", "15,000"], "ans": 2,
         "sol": "Rent 20,000 minus transport 8,000 = ₹12,000."},
     ]},
]


def verify():
    assert weekday(2025, 1, 1) == "Wednesday" and weekday(2025, 1, 26) == "Sunday" and weekday(2025, 8, 15) == "Friday"
    assert sum(1 for d in range(365) if (dt.date(2025, 1, 1) + dt.timedelta(d)).weekday() == 0) == 52
    assert weekday(2026, 1, 1) == "Thursday"

    a = ages()
    assert a == dict(father=45, son=15, mother=41, daughter=12) and sum(a.values()) == 113
    assert next(x for x in range(100) if a["father"] + x == 2 * (a["son"] + x)) == 15
    assert a["mother"] - a["daughter"] == 29

    tot = [sum(v[i] for v in LOANS.values()) for i in range(3)]
    assert tot == [1080, 1080, 1160]
    g = {c: Fr(v[2], v[0]) for c, v in LOANS.items()}
    assert max(g, key=g.get) == "Children's"
    assert round(Fr(380 * 100, 1080)) == 35 and Fr(sum(LOANS["Reference"]), 3) == 90

    done = sum(n - cancelled(z) for z, (n, _) in ZONES.items())
    assert done == 4654
    assert max(ZONES, key=cancelled) == "North"
    assert Fr(sum(cancelled(z) for z in ZONES) * 100, 5000) == Fr(692, 100)
    assert cancelled("East") - cancelled("East", 5) == 45

    amt = {k: Fr(INCOME * v, 100) for k, v in BUDGET.items()}
    assert amt["Education"] == 12000 and Fr(BUDGET["Savings"], BUDGET["Food"]) == Fr(9, 10)
    assert round(amt["Rent"] * 100 / (INCOME * Fr(11, 10))) == 23
    assert (amt["Others"] - (18000 - amt["Savings"])) * 100 / INCOME == Fr(15, 2)
    assert amt["Rent"] - amt["Transport"] == 12000
    return "DILR: all 22 keys match the solvers"
