"""Full Mock 19 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: seating ----------
def seatings():
    out = []
    for o in permutations("PQRSTU"):  # index 0 = leftmost
        p = {c: i for i, c in enumerate(o)}
        if p["Q"] not in (0, 5) or p["R"] != p["P"] + 1 or abs(p["S"] - p["T"]) == 1: continue
        if p["U"] != 2 or p["T"] > p["P"]: continue
        out.append("".join(o))
    return out

# ---------- Set 2: hotel ----------
ROOMS = {"Standard": (80, 75, 3000), "Deluxe": (50, 80, 5000), "Suite": (20, 60, 9000), "Family": (30, 90, 6000)}
def occupied(t): n, pct, _ = ROOMS[t]; return Fr(n * pct, 100)
def revenue(t): return occupied(t) * ROOMS[t][2]

# ---------- Set 3: languages ----------
def venn():
    H, E, F, HE, EF, HF, HEF = 120, 90, 40, 50, 20, 15, 10
    only = (H - HE - HF + HEF) + (E - HE - EF + HEF) + (F - EF - HF + HEF)
    two = (HE - HEF) + (EF - HEF) + (HF - HEF)
    return dict(none=200 - (only + two + HEF), one=only, two=two, e_not_h=E - HE)

# ---------- Set 4: shares ----------
SHARES = {"Alpha": (100, 250, 300), "Beta": (200, 120, 108), "Gamma": (50, 800, 920), "Delta": (150, 400, 380)}
def pct_gain(s): _, b, c = SHARES[s]; return Fr(c - b, b) * 100

# ---------- Set 5: train ----------
KM = {"A": 0, "B": 60, "C": 150, "D": 210, "E": 300}
TIMES = {"A": (None, "06:00"), "B": ("07:00", "07:10"), "C": ("08:25", "08:35"), "D": ("09:25", "09:35"), "E": ("11:15", None)}
def mins(t): h, m = map(int, t.split(":")); return 60 * h + m
def speed(a, b): return Fr(KM[b] - KM[a], mins(TIMES[b][0]) - mins(TIMES[a][1])) * 60


SETS = [
    {"title": "Set 1",
     "intro": ["Six friends, P, Q, R, S, T and U, sit in a row of six seats, all facing north. 'Left' and 'right' are from their point of view. The following is known:",
               "1. Q sits at one of the two ends of the row.",
               "2. R sits immediately to the right of P.",
               "3. S does not sit next to T.",
               "4. U sits in the third seat from the left.",
               "5. T sits somewhere to the left of P."],
     "questions": [
        {"q": "Who sits at the left end of the row?", "opts": ["Q", "S", "T", "U"], "ans": 0,
         "sol": "Suppose Q sat at the right end. With U third, P and R would take seats 1–2 or 4–5. In seats 1–2 no one could sit left of P; in seats 4–5, S and T would fill seats 1 and 2 and sit side by side. Both fail, so Q is at the left end."},
        {"q": "How many different arrangements satisfy all the conditions?", "tita": True, "ans": "3",
         "sol": "With Q first and U third, the possibilities are Q S U T P R, Q T U P R S and Q T U S P R."},
        {"q": "If S sits at the right end, who sits immediately to S's left?", "opts": ["P", "R", "T", "U"], "ans": 1,
         "sol": "Only Q T U P R S has S at the right end; R is next to S."},
        {"q": "Which of the following can NOT sit immediately to the right of U?", "opts": ["P", "R", "S", "T"], "ans": 1,
         "sol": "The seat to U's right is taken by T, P or S in the three arrangements. R always sits right of P, and P is never third, so R is never fourth."},
     ]},
    {"title": "Set 2",
     "intro": ["A hotel has four types of room. The table gives, for one night, the number of rooms of each type, the percentage that were occupied and the rate charged per occupied room."],
     "table": {"head": ["Room type", "Rooms", "Occupied", "Rate per room (₹)"],
               "rows": [[t, str(n), f"{p}%", f"{r:,}"] for t, (n, p, r) in ROOMS.items()]},
     "questions": [
        {"q": "Which type of room earned the most revenue that night?", "opts": ["Standard", "Deluxe", "Suite", "Family"], "ans": 1,
         "sol": "Revenue: Standard 60 × 3,000 = 1,80,000; Deluxe 40 × 5,000 = 2,00,000; Suite 12 × 9,000 = 1,08,000; Family 27 × 6,000 = 1,62,000."},
        {"q": "What was the hotel's total room revenue that night, in rupees?", "tita": True, "ans": "650000",
         "sol": "1,80,000 + 2,00,000 + 1,08,000 + 1,62,000 = ₹6,50,000."},
        {"q": "What percentage of all rooms were occupied? Give your answer to one decimal place.", "tita": True, "ans": "77.2",
         "sol": "60 + 40 + 12 + 27 = 139 occupied rooms out of 180: 77.2%."},
        {"q": "What was the average revenue per occupied room, to the nearest rupee?", "tita": True, "ans": "4676",
         "sol": "6,50,000 / 139 = 4,676.3, which is ₹4,676."},
        {"q": "If the suite rate were cut to ₹7,500 and suite occupancy rose to 85%, by how many rupees would suite revenue change?", "opts": ["Fall of 4,500", "No change", "Rise of 12,000", "Rise of 19,500"], "ans": 3,
         "sol": "17 suites × 7,500 = 1,27,500, against 1,08,000 before: a rise of ₹19,500."},
     ]},
    {"title": "Set 3",
     "intro": ["Each of 200 students in a college was asked which of three languages, Hindi, English and French, they could speak. 120 could speak Hindi, 90 English and 40 French. 50 could speak both Hindi and English, 20 both English and French, and 15 both Hindi and French. 10 could speak all three."],
     "questions": [
        {"q": "How many students could speak none of the three languages?", "tita": True, "ans": "25",
         "sol": "At least one: 120 + 90 + 40 − 50 − 20 − 15 + 10 = 175. None: 25."},
        {"q": "How many students could speak exactly one of the languages?", "tita": True, "ans": "110",
         "sol": "Hindi only 65, English only 30, French only 15: 110."},
        {"q": "How many students could speak exactly two of the languages?", "opts": ["55", "60", "65", "70"], "ans": 0,
         "sol": "(50 − 10) + (20 − 10) + (15 − 10) = 55."},
        {"q": "How many students could speak English but not Hindi?", "opts": ["40", "50", "60", "70"], "ans": 0,
         "sol": "90 − 50 = 40."},
     ]},
    {"title": "Set 4",
     "intro": ["An investor holds four shares. The table gives the number of shares of each company held, the price at which they were bought and their current price."],
     "table": {"head": ["Company", "Shares held", "Buying price (₹)", "Current price (₹)"],
               "rows": [[s, str(q), str(b), str(c)] for s, (q, b, c) in SHARES.items()]},
     "questions": [
        {"q": "Which holding has gained the most in percentage terms?", "opts": ["Alpha", "Beta", "Gamma", "Delta"], "ans": 0,
         "sol": "Alpha +20%, Beta −10%, Gamma +15%, Delta −5%."},
        {"q": "What is the investor's overall gain, in rupees?", "tita": True, "ans": "5600",
         "sol": "Invested 25,000 + 24,000 + 40,000 + 60,000 = 1,49,000. Now worth 30,000 + 21,600 + 46,000 + 57,000 = 1,54,600. Gain ₹5,600."},
        {"q": "What is the overall percentage gain, to two decimal places?", "tita": True, "ans": "3.76",
         "sol": "5,600 / 1,49,000 = 3.758%, which is 3.76."},
        {"q": "In how many of the holdings has the investor lost money?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "Beta and Delta: two."},
     ]},
    {"title": "Set 5",
     "intro": ["A train runs from station A to station E, stopping at B, C and D. The distances of the stations from A and the train's timetable are given below."],
     "table": {"head": ["Station", "Distance from A (km)", "Arrives", "Departs"],
               "rows": [[s, str(KM[s]), a or "—", d or "—"] for s, (a, d) in TIMES.items()]},
     "questions": [
        {"q": "How long does the whole journey from A to E take?", "opts": ["5 h 5 min", "5 h 15 min", "5 h 25 min", "5 h 35 min"], "ans": 1,
         "sol": "06:00 to 11:15: 5 hours 15 minutes."},
        {"q": "What is the train's average speed for the whole journey, including stops, in km/h? Give your answer to two decimal places.", "tita": True, "ans": "57.14",
         "sol": "300 km in 5.25 hours: 57.14 km/h."},
        {"q": "On which section is the train's running speed lowest?", "opts": ["A–B", "B–C", "C–D", "D–E"], "ans": 3,
         "sol": "A–B 60, B–C 72, C–D 72, D–E 54 km/h."},
        {"q": "Approximately what is the train's average running speed, excluding time at stations, in km/h?", "opts": ["54", "57", "60", "63"], "ans": 3,
         "sol": "The three stops take 30 minutes, so the train runs for 4 h 45 min. 300 / 4.75 = 63.2 km/h."},
        {"q": "One day the train leaves A 20 minutes late and keeps to its usual running times and stops as far as D, but then runs from D to E at 72 km/h. At what time does it reach E?", "opts": ["11:00", "11:10", "11:15", "11:25"], "ans": 1,
         "sol": "It leaves D at 09:55. 90 km at 72 km/h takes 75 minutes: 11:10."},
     ]},
]


def verify():
    s = seatings()
    assert sorted(s) == ["QSUTPR", "QTUPRS", "QTUSPR"] and all(x[0] == "Q" for x in s)
    assert [x[4] for x in s if x[5] == "S"] == ["R"]
    assert {x[3] for x in s} == {"T", "P", "S"}

    rev = {t: revenue(t) for t in ROOMS}
    assert max(rev, key=rev.get) == "Deluxe" and sum(rev.values()) == 650000
    occ = sum(occupied(t) for t in ROOMS)
    assert occ == 139 and round(float(occ * 100 / 180), 1) == 77.2
    assert round(650000 / 139) == 4676
    assert Fr(20 * 85, 100) * 7500 - rev["Suite"] == 19500

    v = venn()
    assert v == dict(none=25, one=110, two=55, e_not_h=40)

    g = {x: pct_gain(x) for x in SHARES}
    assert max(g, key=g.get) == "Alpha"
    inv = sum(q * b for q, b, _ in SHARES.values()); now = sum(q * c for q, _, c in SHARES.values())
    assert now - inv == 5600 and round(5600 * 100 / inv, 2) == 3.76
    assert sum(1 for x in g.values() if x < 0) == 2

    assert mins(TIMES["E"][0]) - mins(TIMES["A"][1]) == 315
    assert round(float(Fr(300 * 60, 315)), 2) == 57.14
    sp = {f"{a}–{b}": speed(a, b) for a, b in zip("ABCD", "BCDE")}
    assert min(sp, key=sp.get) == "D–E" and sp == {"A–B": 60, "B–C": 72, "C–D": 72, "D–E": 54}
    assert round(300 / 4.75) == 63
    t = mins(TIMES["D"][1]) + 20 + 90 * 60 // 72
    assert t == mins("11:10")
    return "DILR: all 22 keys match the solvers"
