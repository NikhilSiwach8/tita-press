"""Full Mock 20 DILR: 5 sets, 22 questions. Each set has a solver; verify() checks every key against it."""
from fractions import Fraction as Fr
from itertools import permutations

# ---------- Set 1: lecture schedule ----------
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
def schedules(rule4=True):
    out = []
    for o in permutations("VWXYZ"):  # index 0 = Monday
        p = {c: i for i, c in enumerate(o)}
        if p["W"] <= p["Y"] + 1 or p["Z"] not in (0, 4) or p["V"] != p["X"] + 1: continue
        if rule4 and p["Y"] == 0: continue
        out.append("".join(o))
    return out

# ---------- Set 2: electricity ----------
SLABS = [(100, 3), (100, 5), (None, 8)]  # (units in slab, ₹ per unit)
HOMES = {"H1": 80, "H2": 150, "H3": 240, "H4": 310}
def bill(units):
    total, left = 0, units
    for size, rate in SLABS:
        used = left if size is None else min(left, size)
        total += used * rate; left -= used
    return total

# ---------- Set 3: exam ----------
MARKS = {"Asha": (72, 58, 81), "Bilal": (45, 90, 66), "Chen": (88, 39, 74), "Divya": (60, 62, 59), "Elan": (95, 71, 40)}
def passed(m, floor=40, agg=180): return min(m) >= floor and sum(m) >= agg

# ---------- Set 4: data plans ----------
PLANS = {"P1": (299, Fr(3, 2), 28), "P2": (479, Fr(3, 2), 56), "P3": (719, Fr(2), 84), "P4": (2999, Fr(5, 2), 365)}
def per_day(p): price, _, days = PLANS[p]; return Fr(price, days)
def per_gb(p): price, gb, days = PLANS[p]; return price / (gb * days)


SETS = [
    {"title": "Set 1",
     "intro": ["Five speakers, V, W, X, Y and Z, each give one lecture in a series running from Monday to Friday of the same week, one lecture a day. The following is known:",
               "1. W speaks after Y, but not on the day immediately after Y.",
               "2. Z speaks on Monday or on Friday.",
               "3. X speaks on the day immediately before V.",
               "4. Y does not speak on Monday."],
     "questions": [
        {"q": "Who speaks on Wednesday?", "opts": ["V", "W", "X", "Y"], "ans": 2,
         "sol": "If Z spoke on Friday, Y (not Monday) and W two or more days later would need Tuesday and Thursday, leaving Monday and Wednesday for X and V, which are not consecutive. So Z speaks on Monday. If Y spoke on Wednesday, W would take Friday and leave Tuesday and Thursday for X and V, which fails. So Y speaks on Tuesday. W on Thursday would leave Wednesday and Friday for X and V, which fails too, so W speaks on Friday, with X on Wednesday and V on Thursday: Z, Y, X, V, W."},
        {"q": "On which day does W speak?", "opts": ["Tuesday", "Wednesday", "Thursday", "Friday"], "ans": 3,
         "sol": "The unique schedule is Z, Y, X, V, W: W speaks on Friday."},
        {"q": "How many speakers speak on days between Y's lecture and W's?", "opts": ["2", "3", "4", "5"], "ans": 0,
         "sol": "X (Wednesday) and V (Thursday) fall between Y (Tuesday) and W (Friday): two."},
        {"q": "If condition 4 were removed, how many different schedules would satisfy the remaining conditions?", "tita": True, "ans": "2",
         "sol": "Besides Z, Y, X, V, W, the order Y, X, V, W, Z now also works, with Y on Monday and Z on Friday. Two schedules."},
     ]},
    {"title": "Set 2",
     "intro": ["An electricity company charges ₹3 per unit for the first 100 units used in a month, ₹5 per unit for the next 100 units, and ₹8 per unit for every unit above 200. Four households used the following numbers of units in one month: H1 80, H2 150, H3 240 and H4 310."],
     "questions": [
        {"q": "What was the total of the four households' bills, in rupees?", "tita": True, "ans": "3590",
         "sol": "H1 240; H2 300 + 250 = 550; H3 300 + 500 + 320 = 1,120; H4 300 + 500 + 880 = 1,680. Total ₹3,590."},
        {"q": "What was H3's average cost per unit, to the nearest rupee?", "opts": ["2", "3", "4", "5"], "ans": 3,
         "sol": "1,120 / 240 = 4.67, which rounds to ₹5."},
        {"q": "How many units did a household use if its bill was ₹1,000?", "tita": True, "ans": "225",
         "sol": "The first 200 units cost 800. The remaining 200 rupees buy 200/8 = 25 units at the top rate: 225 units."},
        {"q": "If H2's consumption rose by 20%, by how many rupees would its bill rise?", "opts": ["150", "180", "210", "240"], "ans": 0,
         "sol": "180 units cost 300 + 80 × 5 = 700, against 550 before: a rise of ₹150."},
     ]},
    {"title": "Set 3",
     "intro": ["Five students took tests in three subjects, each marked out of 100. To pass, a student needs at least 40 in every subject and an aggregate of at least 180. Their marks are shown below."],
     "table": {"head": ["Student", "Subject 1", "Subject 2", "Subject 3"], "rows": [[s, *map(str, m)] for s, m in MARKS.items()]},
     "questions": [
        {"q": "How many of the students passed?", "opts": ["1", "2", "3", "4"], "ans": 3,
         "sol": "Aggregates: Asha 211, Bilal 201, Chen 201, Divya 181, Elan 206, all at least 180. Chen fails with 39 in Subject 2. Four pass."},
        {"q": "Which student had the highest aggregate?", "opts": ["Asha", "Bilal", "Chen", "Elan"], "ans": 0,
         "sol": "Asha, with 211."},
        {"q": "What was the average mark in Subject 2?", "tita": True, "ans": "64",
         "sol": "(58 + 90 + 39 + 62 + 71)/5 = 320/5 = 64."},
        {"q": "If the minimum mark in each subject were raised to 45, with the aggregate requirement unchanged, how many students would pass?", "opts": ["3", "4", "5", "6"], "ans": 0,
         "sol": "Elan (40) and Chen (39) fall short; Asha, Bilal (lowest 45) and Divya pass. Three."},
        {"q": "In which subject was the average mark highest?", "opts": ["Subject 1", "Subject 2", "Subject 3", "Subjects 2 and 3 equally"], "ans": 0,
         "sol": "Averages: Subject 1 72, Subject 2 64, Subject 3 64."},
     ]},
    {"title": "Set 4",
     "intro": ["A mobile operator offers four prepaid plans. Each gives a fixed amount of data per day for the validity period. Unused data does not carry over."],
     "table": {"head": ["Plan", "Price (₹)", "Data per day (GB)", "Validity (days)"],
               "rows": [[p, f"{c:,}", f"{float(g):g}", str(d)] for p, (c, g, d) in PLANS.items()]},
     "questions": [
        {"q": "Which plan has the lowest cost per day?", "opts": ["P1", "P2", "P3", "P4"], "ans": 3,
         "sol": "Per day: P1 ₹10.68, P2 ₹8.55, P3 ₹8.56, P4 ₹8.22."},
        {"q": "What is the cost per GB of plan P3, in rupees, to two decimal places?", "tita": True, "ans": "4.28",
         "sol": "P3 gives 2 × 84 = 168 GB for ₹719: 719/168 = 4.28."},
        {"q": "How many of the plans cost less than ₹9 per day?", "opts": ["0", "1", "2", "3"], "ans": 3,
         "sol": "P2, P3 and P4: three."},
        {"q": "How many GB of data does plan P4 provide in all?", "tita": True, "ans": "912.5",
         "sol": "2.5 × 365 = 912.5 GB."},
        {"q": "A user buys plan P1 thirteen times in a row, covering 364 days. How many rupees more does this cost than buying P4 once?", "tita": True, "ans": "888",
         "sol": "13 × 299 = 3,887. 3,887 − 2,999 = ₹888."},
     ]},
    {"title": "Set 5",
     "intro": ["A water tank holds 12,000 litres and is full at 6 a.m. Water is drawn from it at a steady 800 litres per hour from 6 a.m. to 10 a.m., and at 500 litres per hour from 10 a.m. to 6 p.m. A pump adds 600 litres per hour, but only from 2 p.m. to 6 p.m."],
     "questions": [
        {"q": "How many litres are in the tank at 2 p.m.?", "tita": True, "ans": "6800",
         "sol": "By 10 a.m. 4 × 800 = 3,200 litres have been drawn, and by 2 p.m. a further 4 × 500 = 2,000. 12,000 − 5,200 = 6,800."},
        {"q": "How many litres are in the tank at 6 p.m.?", "opts": ["6,800", "7,200", "7,600", "8,000"], "ans": 1,
         "sol": "From 2 p.m. the level rises by 600 − 500 = 100 litres an hour for 4 hours: 6,800 + 400 = 7,200."},
        {"q": "If the pump instead ran from 10 a.m. to 6 p.m., how many litres would the tank hold at 6 p.m.?", "opts": ["8,800", "9,200", "9,600", "10,000"], "ans": 2,
         "sol": "At 10 a.m. the tank holds 8,800. A net gain of 100 litres an hour for 8 hours adds 800: 9,600."},
        {"q": "At what time does the tank first hold 10,000 litres?", "opts": ["8:00 a.m.", "8:30 a.m.", "9:00 a.m.", "9:30 a.m."], "ans": 1,
         "sol": "2,000 litres at 800 litres an hour takes 2.5 hours from 6 a.m.: 8:30 a.m."},
     ]},
]


def tank(t, pump_from=14):  # t in hours on a 24-hour clock, 6 <= t <= 18
    level = Fr(12000)
    for h in range(6 * 60, int(t * 60)):
        hr = h / 60
        level -= Fr(800 if hr < 10 else 500, 60)
        if hr >= pump_from: level += Fr(600, 60)
    return level


def verify():
    s = schedules()
    assert s == ["ZYXVW"]
    o = s[0]
    assert o[2] == "X" and DAYS[o.index("W")] == "Friday" and o.index("W") - o.index("Y") - 1 == 2
    assert len(schedules(rule4=False)) == 2

    b = {h: bill(u) for h, u in HOMES.items()}
    assert b == {"H1": 240, "H2": 550, "H3": 1120, "H4": 1680} and sum(b.values()) == 3590
    assert round(Fr(b["H3"], 240)) == 5
    assert next(u for u in range(1000) if bill(u) == 1000) == 225
    assert bill(180) - bill(150) == 150

    assert sum(passed(m) for m in MARKS.values()) == 4
    assert max(MARKS, key=lambda s: sum(MARKS[s])) == "Asha"
    assert Fr(sum(m[1] for m in MARKS.values()), 5) == 64
    assert sum(passed(m, floor=45) for m in MARKS.values()) == 3
    avg = [Fr(sum(m[i] for m in MARKS.values()), 5) for i in range(3)]
    assert avg == [72, 64, 64]

    assert min(PLANS, key=per_day) == "P4"
    assert round(float(per_gb("P3")), 2) == 4.28
    assert sum(1 for p in PLANS if per_day(p) < 9) == 3
    assert PLANS["P4"][1] * 365 == Fr(9125, 10)
    assert 13 * 299 - 2999 == 888

    assert tank(14) == 6800 and tank(18) == 7200 and tank(18, pump_from=10) == 9600
    assert min(t for t in range(6 * 60, 18 * 60) if tank(t / 60) <= 10000) == 8 * 60 + 30
    return "DILR: all 22 keys match the solvers"
