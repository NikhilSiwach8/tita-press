"""Warn when a numeric MCQ's keyed option does not appear in its worked solution (a sign the answer index is wrong).

Usage: python3 keycheck.py full-mock-10 full-mock-11 ...
"""
import re, sys
import build


def norm(s):
    return s.replace(",", "").replace(" ", "").replace("−", "-").rstrip("%°")


def main(folders):
    bad = 0
    for f in folders:
        build.load_paper(f)
        for q in build.build_questions():
            if q["tita"] or build.numeric_value(q["opts"][0]) is None: continue
            key = norm(q["opts"][q["ans"]])
            sol = norm(q["sol"])
            if key not in sol:
                bad += 1
                print(f"{f} Q{q['n']}: key {q['opts'][q['ans']]!r} not in solution | {q['sol'][:110]}")
    print("warnings:", bad)


if __name__ == "__main__":
    main(sys.argv[1:])
