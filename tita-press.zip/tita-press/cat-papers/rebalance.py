"""Swap the option list of a question, located by a unique phrase in its text. Usage in code: rebalance(path, [(phrase, new_opts, new_ans), ...])."""
import json, pathlib, re, sys


def rebalance(path, changes):
    p = pathlib.Path(path); s = p.read_text()
    for phrase, opts, ans in changes:
        i = s.index(phrase)
        assert s.count(phrase) == 1, phrase
        m = re.compile(r'"opts": \[[^\]]*\], "ans": \d+,').search(s, i)
        s = s[:m.start()] + f'"opts": {json.dumps(opts, ensure_ascii=False)}, "ans": {ans},' + s[m.end():]
    p.write_text(s)
