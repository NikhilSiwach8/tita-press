// Netlify Function that serves the whole store: pages, API and downloads all go through store/app.mjs,
// so the site password and the paid-download checks cover every address.
import { handle } from "../../store/app.mjs";

export default async request => handle(request);

export const config = { path: ["/", "/*"] };
