Netlify needs a publish folder. Every address is answered by the function in netlify/functions/app.mjs instead.
