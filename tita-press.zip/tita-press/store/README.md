# TITA Press store

The web shop for the CAT mock papers in `../cat-papers`. It sells the Diagnostic Mock (free), single mocks and bundles,
takes payment through Razorpay, and delivers the PDFs through private per-order download links.

## Run it

```bash
node store/server.mjs
```

Open http://localhost:3000. With no Razorpay keys it runs in **test mode**: checkout shows a simulated payment window and
nothing is charged. You need Node 18 or newer; there are no npm packages to install.

## Files

| Path | What it is |
|---|---|
| `app.mjs` | The whole backend: catalogue, pricing, checkout, Razorpay verification and webhook, downloads, admin page |
| `server.mjs` | Runs `app.mjs` on this computer |
| `public/index.html` | The storefront |
| `products.json` | Products, prices and coupon codes. Edit this to change what's on sale |
| `data/papers.json` | Paper list and preview questions, generated from the papers |
| `scripts/export_catalog.py` | Regenerates `data/papers.json` after papers are rebuilt |
| `data/db.json` | Orders when running locally without Upstash |

PDFs are served straight from `../cat-papers/out` (set `PAPERS_DIR` to move them). They are never publicly reachable:
a download needs the secret token of a paid order that includes that paper.

## How buying works

1. The browser sends the cart; the server works out the price itself from `products.json` (a bundle absorbs any
   single mocks it already contains, then the coupon applies).
2. Free orders complete at once. Paid orders create a Razorpay order and open Razorpay's checkout window.
3. When payment succeeds, the server checks Razorpay's signature, marks the order paid and gives it a random access
   token. The buyer sees their library and gets a receipt email with their private link.
4. The Razorpay webhook does the same from Razorpay's side, so the order is completed even if the buyer closes the tab.

Access is per order, never per email address, because anyone can type anyone's email at checkout. A buyer who loses
their link can recover an order with its email plus order number, or ask for every link to be emailed to them again.

## Publishing on Netlify (free) with Upstash

`netlify.toml` at the repository root sets everything up. The whole store runs as one Netlify Function
(`netlify/functions/app.mjs`, which calls `store/app.mjs`), so the site password and download checks cover every page.
The function has no disk, so orders are stored in Upstash Redis.

1. **Upstash:** create a free account at console.upstash.com, create a Redis database (pick Mumbai if offered), open its
   REST API section and copy `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`.
2. **GitHub:** the code must be in a **private** repository, because it contains the paid PDFs.
3. **Netlify:** Add new site → Import an existing project → GitHub → pick the repository. Leave the build settings as
   they are (they come from `netlify.toml`). Before or after the first deploy, add these under Site configuration →
   Environment variables, then redeploy: `SITE_PASSWORD` (keeps the site private), `ADMIN_PASSWORD`, and the two
   Upstash values.
4. Open the `netlify.app` address. Your browser asks for a password: any user name plus `SITE_PASSWORD` gets in. The
   admin page is at `/admin` (user name `admin`, password `ADMIN_PASSWORD`).

Every push to the repository redeploys. To open the site to everyone, delete `SITE_PASSWORD` and redeploy.

### Payments

Away from localhost, paid checkout stays **off** (paid items show "Opening soon") until a payment gateway is
configured; only the free Diagnostic Mock can be ordered. Simulated payments run only on localhost, or anywhere with
`ALLOW_TEST_PAYMENTS=1`. Never set that on a public site: it gives papers away.

The current gateway code is Razorpay (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, webhook at `/api/razorpay-webhook`
with `RAZORPAY_WEBHOOK_SECRET`).

### Email

Create a Resend account, verify your domain, and set `RESEND_API_KEY` and `MAIL_FROM`. Without them, receipt
emails are printed to the server log instead of sent.

Terms, Privacy, Refund and Contact pages are at `/terms`, `/privacy`, `/refunds` and `/contact` (files in `public/`).
Razorpay usually also asks for a business address on the Contact page; add it to `public/contact.html` if they do.

## Refunds and disabling links

Download links work only while an order's status is `paid`. To refund an order or cut off a link that has been
shared, change that order's `"status"` to `"refunded"` or `"revoked"` and restart the server. Orders are in
`data/db.json` locally, or in the Upstash hash `tita:orders` (edit the order in Upstash's Data Browser). Issue the
money back from the payment gateway's dashboard.

## After rebuilding papers

```bash
python3 -B cat-papers/build.py diagnostic-01 full-mock-{01..20}
python3 -B store/scripts/export_catalog.py
```

Then restart the server.
