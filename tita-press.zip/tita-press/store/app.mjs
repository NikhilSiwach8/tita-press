// TITA Press store: catalogue, checkout (Razorpay, or a local test mode), paper delivery and an admin view.
// One request handler, `handle(Request) → Response`, used by both the local server (server.mjs) and the
// Netlify Function (netlify/functions/app.mjs). No dependencies. Configuration comes from environment variables.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// The store's folder: next to this file locally; on Netlify the bundled function runs from elsewhere,
// and the files listed in netlify.toml's included_files sit under the function's root.
const ROOT = [
  path.dirname(fileURLToPath(import.meta.url)),
  path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../store"),
  process.env.LAMBDA_TASK_ROOT && path.join(process.env.LAMBDA_TASK_ROOT, "store"),
  path.join(process.cwd(), "store"),
  process.cwd(),
].find(dir => dir && fs.existsSync(path.join(dir, "products.json")));
if (!ROOT) throw new Error("Can't find the store folder (products.json)");
loadEnv(path.join(ROOT, ".env"));

const HOSTED = Boolean(process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.RENDER);
const CFG = {
  // Netlify sets URL and Render sets RENDER_EXTERNAL_URL; otherwise links use the address the request came in on
  baseUrl: (process.env.BASE_URL || process.env.URL || process.env.RENDER_EXTERNAL_URL || "").replace(/\/$/, ""),
  papersDir: path.resolve(ROOT, process.env.PAPERS_DIR || "../cat-papers/out"),
  dbFile: path.resolve(ROOT, process.env.DB_FILE || "data/db.json"),
  rzpKey: process.env.RAZORPAY_KEY_ID || "",
  rzpSecret: process.env.RAZORPAY_KEY_SECRET || "",
  rzpWebhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || "",
  adminPassword: process.env.ADMIN_PASSWORD || "",
  resendKey: process.env.RESEND_API_KEY || "",
  mailFrom: process.env.MAIL_FROM || "",
  upstashUrl: (process.env.UPSTASH_REDIS_REST_URL || "").replace(/\/$/, ""),
  upstashToken: process.env.UPSTASH_REDIS_REST_TOKEN || "",
  sitePassword: process.env.SITE_PASSWORD || "",
};
const LIVE = Boolean(CFG.rzpKey && CFG.rzpSecret);
// Simulated payments hand out papers for free, so they run only on this computer or when switched on explicitly
const TEST_PAYMENTS = !LIVE && (process.env.ALLOW_TEST_PAYMENTS === "1"
  || (!HOSTED && (!CFG.baseUrl || CFG.baseUrl.startsWith("http://localhost"))));
export const PAYMENTS = LIVE ? "live" : TEST_PAYMENTS ? "test" : "off";

const PAPERS = JSON.parse(fs.readFileSync(path.join(ROOT, "data/papers.json"), "utf8"));
const { products: PRODUCTS, coupons: COUPONS } = JSON.parse(fs.readFileSync(path.join(ROOT, "products.json"), "utf8"));
const paperById = Object.fromEntries(PAPERS.map(p => [p.id, p]));
const productById = Object.fromEntries(PRODUCTS.map(p => [p.id, p]));
for (const p of PRODUCTS) for (const id of p.papers) if (!paperById[id]) throw new Error(`Product ${p.id} lists unknown paper ${id}`);
for (const p of PAPERS) for (const f of Object.values(p.files))
  if (!fs.existsSync(path.join(CFG.papersDir, f))) throw new Error(`Missing PDF ${f} in ${CFG.papersDir}`);

/* ---------- storage ----------
   Upstash Redis when configured (needed on Netlify, where every request may run in a fresh instance with no disk):
   each order is a field of the hash tita:orders, with lookup hashes from access token and Razorpay order id.
   Otherwise a local JSON file, for running on this computer. */
export const UPSTASH = Boolean(CFG.upstashUrl && CFG.upstashToken);
async function redis(...command) {
  const r = await fetch(CFG.upstashUrl, {
    method: "POST",
    headers: { Authorization: `Bearer ${CFG.upstashToken}`, "Content-Type": "application/json" },
    body: JSON.stringify(command),
  });
  const data = await r.json();
  if (!r.ok || data.error) throw new Error(`Upstash: ${data.error || r.status}`);
  return data.result;
}

const redisStore = {
  async get(id) { const v = await redis("HGET", "tita:orders", id); return v ? JSON.parse(v) : null; },
  async put(order) {
    await redis("HSET", "tita:orders", order.id, JSON.stringify(order));
    if (order.token) await redis("HSET", "tita:tokens", order.token, order.id);
    if (order.rzpOrderId) await redis("HSET", "tita:rzp", order.rzpOrderId, order.id);
  },
  async byToken(token) { const id = await redis("HGET", "tita:tokens", token); return id ? this.get(id) : null; },
  async byRzp(rzpId) { const id = await redis("HGET", "tita:rzp", rzpId); return id ? this.get(id) : null; },
  async all() {
    const flat = await redis("HGETALL", "tita:orders") || [];
    const out = [];
    for (let i = 0; i < flat.length; i += 2) out.push(JSON.parse(flat[i + 1]));
    return out;
  },
  // Count events for a key within a rolling window, e.g. link resends per email per hour
  async hit(key, seconds) {
    const n = await redis("INCR", `tita:hits:${key}`);
    if (n === 1) await redis("EXPIRE", `tita:hits:${key}`, seconds);
    return n;
  },
};

const fileDb = { orders: fs.existsSync(CFG.dbFile) && !UPSTASH ? JSON.parse(fs.readFileSync(CFG.dbFile, "utf8")).orders : {} };
const hits = {};
const fileStore = {
  async get(id) { return fileDb.orders[id] || null; },
  async put(order) {
    fileDb.orders[order.id] = order;
    fs.mkdirSync(path.dirname(CFG.dbFile), { recursive: true });
    fs.writeFileSync(CFG.dbFile + ".tmp", JSON.stringify(fileDb, null, 1));
    fs.renameSync(CFG.dbFile + ".tmp", CFG.dbFile);
  },
  async byToken(token) { return Object.values(fileDb.orders).find(o => o.token && safeEqual(o.token, token)) || null; },
  async byRzp(rzpId) { return Object.values(fileDb.orders).find(o => o.rzpOrderId === rzpId) || null; },
  async all() { return Object.values(fileDb.orders); },
  async hit(key, seconds) {
    const now = Date.now();
    hits[key] = (hits[key] || []).filter(t => now - t < seconds * 1000);
    hits[key].push(now);
    return hits[key].length;
  },
};
const store = UPSTASH ? redisStore : fileStore;
export const STORAGE = UPSTASH ? "Upstash Redis" : CFG.dbFile;

// Access is per order: each paid order has its own secret token, which only its buyer sees (on screen and by email).
// Nothing is ever unlocked by email address alone, since anyone can type someone else's email at checkout.
async function paidOrderByToken(token) {
  if (!token || token.length < 20) return null;
  const order = await store.byToken(token);
  return order && order.status === "paid" && safeEqual(order.token, token) ? order : null;
}
const linkFor = (order, site) => `${site}/?library=${order.token}#library`;

/* ---------- pricing (the server is the only place prices are computed) ---------- */
function quote(ids, couponCode) {
  let items = [...new Set(ids)].map(id => productById[id]).filter(Boolean);
  if (!items.length) throw new UserError("Your cart is empty.");
  // Drop anything already covered by a bigger item in the same cart
  items = items.filter(p => !items.some(q => q !== p && q.papers.length > p.papers.length && p.papers.every(x => q.papers.includes(x))));
  const subtotal = items.reduce((s, p) => s + p.price, 0);
  const code = (couponCode || "").trim().toUpperCase();
  if (code && !COUPONS[code]) throw new UserError(`${code} isn't a valid coupon code.`);
  const discount = code && subtotal ? Math.round(subtotal * COUPONS[code] / 100) : 0;
  const papers = [...new Set(items.flatMap(p => p.papers))];
  return { items: items.map(p => p.id), subtotal, coupon: code && subtotal ? code : null, discount, total: subtotal - discount, papers };
}

/* ---------- orders ---------- */
const newId = (prefix, bytes) => prefix + crypto.randomBytes(bytes).toString("base64url").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, bytes + 2);
async function fulfil(order, payment, site) {
  // Only open orders can be fulfilled; a refunded or revoked order stays closed even if a late webhook arrives
  if (!["pending", "failed"].includes(order.status)) return order;
  order.status = "paid";
  order.paidAt = new Date().toISOString();
  if (payment) order.payment = payment;
  order.token = crypto.randomBytes(24).toString("base64url");
  await store.put(order);
  // Awaited, because a serverless function may be frozen as soon as it returns
  await sendReceipt(order, site).catch(err => console.error("Receipt email failed:", err.message));
  return order;
}

async function sendReceipt(order, site) {
  const lines = order.items.map(id => `• ${productById[id].name}`).join("\n");
  const text = `Hi ${order.name.split(" ")[0]},\n\nThanks for your order ${order.id} (₹${order.total.toLocaleString("en-IN")}).\n\n${lines}\n\nDownload your papers any time from this private link:\n${linkFor(order, site)}\n\nKeep it to yourself: anyone with the link can download these papers.\n\nTITA Press`;
  await sendMail(order.email, `Your TITA Press papers (order ${order.id})`, text);
}

async function sendMail(to, subject, text) {
  if (!CFG.resendKey || !CFG.mailFrom) { console.log(`[mail not configured] would send to ${to}: ${subject}\n${text}\n`); return; }
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${CFG.resendKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: CFG.mailFrom, to, subject, text }),
  });
  if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
}

async function razorpay(pathname, body) {
  const r = await fetch(`https://api.razorpay.com/v1${pathname}`, {
    method: "POST",
    headers: { Authorization: "Basic " + Buffer.from(`${CFG.rzpKey}:${CFG.rzpSecret}`).toString("base64"), "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(`Razorpay ${r.status}: ${data?.error?.description || "request failed"}`);
  return data;
}

/* ---------- routes ---------- */
const routes = {
  "GET /api/catalog": () => ({
    mode: PAYMENTS,
    papers: PAPERS.map(({ id, name, questions, tita, sample }) => ({ id, name, questions, tita, sample })),
    products: PRODUCTS.map(({ id, kind, name, badge, featured, price, mrp, blurb, papers }) => ({ id, kind, name, badge, featured, price, mrp, blurb, papers })),
  }),

  "POST /api/quote": ({ body }) => {
    const q = quote(body.items || [], body.coupon);
    return { ...q, papers: undefined };
  },

  "POST /api/checkout": async ({ body, site }) => {
    const name = String(body.name || "").trim().slice(0, 80);
    const email = String(body.email || "").trim().toLowerCase().slice(0, 120);
    const phone = String(body.phone || "").replace(/\D/g, "").slice(-10);
    if (name.length < 2) throw new UserError("Enter your name.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new UserError("Enter a valid email address.");
    if (phone && !/^[6-9]\d{9}$/.test(phone)) throw new UserError("Enter a 10-digit Indian mobile number, or leave it blank.");
    const q = quote(body.items || [], body.coupon);
    const order = { id: newId("TP-", 6), name, email, phone, ...q, status: "pending", created: new Date().toISOString() };

    if (order.total === 0) {
      await fulfil(order, { method: "free" }, site);
      return { orderId: order.id, status: "paid", token: order.token };
    }
    if (PAYMENTS === "off") throw new UserError("Payments are opening soon. You can get the free Diagnostic Mock now.");
    if (PAYMENTS === "test") { await store.put(order); return { orderId: order.id, status: "pending", mode: "test", amount: order.total }; }

    const rzp = await razorpay("/orders", { amount: order.total * 100, currency: "INR", receipt: order.id, notes: { order: order.id, email } });
    order.rzpOrderId = rzp.id;
    await store.put(order);
    return { orderId: order.id, status: "pending", mode: "live", amount: order.total,
      razorpay: { key: CFG.rzpKey, order_id: rzp.id, amount: rzp.amount, currency: "INR", name: "TITA Press", prefill: { name, email, contact: phone } } };
  },

  // Called by the browser after Razorpay's checkout succeeds
  "POST /api/verify": async ({ body, site }) => {
    const order = LIVE && await store.get(String(body.orderId || ""));
    if (!order) throw new UserError("Unknown order.", 404);
    const expected = crypto.createHmac("sha256", CFG.rzpSecret).update(`${order.rzpOrderId}|${body.razorpay_payment_id}`).digest("hex");
    if (body.razorpay_order_id !== order.rzpOrderId || !safeEqual(expected, String(body.razorpay_signature || "")))
      throw new UserError("We couldn't confirm this payment. If money left your account, write to us with your order number.", 400);
    await fulfil(order, { method: "razorpay", paymentId: body.razorpay_payment_id }, site);
    return { orderId: order.id, status: "paid", token: order.token };
  },

  // Razorpay calls this too, so an order is fulfilled even if the buyer closes the tab mid-payment
  "POST /api/razorpay-webhook": async ({ body, raw, headers, site }) => {
    if (!CFG.rzpWebhookSecret) throw new UserError("Webhook not configured.", 404);
    const expected = crypto.createHmac("sha256", CFG.rzpWebhookSecret).update(raw).digest("hex");
    if (!safeEqual(expected, headers.get("x-razorpay-signature") || "")) throw new UserError("Bad signature.", 400);
    const rzpOrderId = body?.payload?.payment?.entity?.order_id || body?.payload?.order?.entity?.id;
    const order = rzpOrderId && await store.byRzp(rzpOrderId);
    if (order && ["payment.captured", "order.paid"].includes(body.event))
      await fulfil(order, { method: "razorpay", paymentId: body?.payload?.payment?.entity?.id }, site);
    return { ok: true };
  },

  // Test mode only: stands in for the payment window when no Razorpay keys are set
  "POST /api/test-pay": async ({ body, site }) => {
    const order = PAYMENTS === "test" && await store.get(String(body.orderId || ""));
    if (!order) throw new UserError("Not available.", 404);
    if (!body.success) {
      if (order.status === "pending") { order.status = "failed"; await store.put(order); }
      return { orderId: order.id, status: order.status };
    }
    await fulfil(order, { method: "test" }, site);
    return { orderId: order.id, status: order.status, token: order.token };
  },

  // The browser keeps every order token it has been given and sends them all; the library is their union
  "POST /api/library": async ({ body }) => {
    const tokens = [...new Set([].concat(body.tokens || []).map(String))].slice(0, 50);
    const orders = await Promise.all(tokens.map(paidOrderByToken));
    const papers = [...new Set(orders.filter(Boolean).flatMap(o => o.papers))];
    return {
      tokens: orders.map(o => o ? o.token : null),
      papers: papers.map(id => ({ id, name: paperById[id].name, token: orders.find(o => o && o.papers.includes(id)).token })),
    };
  },

  // Recover one order's link with its email and order number (both appear only on the buyer's receipt)
  "POST /api/library/recover": async ({ body }) => {
    const order = await store.get(String(body.orderId || "").trim().toUpperCase());
    const email = String(body.email || "").trim().toLowerCase();
    if (!order || order.status !== "paid" || order.email !== email) throw new UserError("No paid order matches that email and order number.", 404);
    return { token: order.token };
  },

  // Email every library link for an address to that address. The reply is the same whether or not orders exist.
  "POST /api/library/resend": async ({ body, site }) => {
    const email = String(body.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new UserError("Enter a valid email address.");
    if (await store.hit(`resend:${email}`, 3600) > 3)
      throw new UserError("We've already sent your links several times this hour. Check your inbox and spam folder.", 429);
    const orders = (await store.all()).filter(o => o.status === "paid" && o.email === email);
    if (orders.length) await sendMail(email, "Your TITA Press library links",
      `Here are the private download links for your orders:\n\n${orders.map(o => `${o.id}: ${o.items.map(i => productById[i].name).join(", ")}\n${linkFor(o, site)}`).join("\n\n")}\n\nTITA Press`)
      .catch(err => console.error("Resend email failed:", err.message));
    return { ok: true };
  },
};

async function download([, token, paperId, kind]) {
  const order = await paidOrderByToken(token);
  const paper = paperById[paperId];
  if (!order || !paper || !order.papers.includes(paperId) || !paper.files[kind]) return text(404, "Not found");
  order.downloads = (order.downloads || 0) + 1;
  await store.put(order);
  return new Response(fs.readFileSync(path.join(CFG.papersDir, paper.files[kind])), {
    headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="${paper.files[kind]}"`, "Cache-Control": "private, no-store" },
  });
}

function credentials(headers) {
  const decoded = Buffer.from((headers.get("authorization") || "").replace(/^Basic /, ""), "base64").toString();
  const i = decoded.indexOf(":");
  return i < 0 ? ["", ""] : [decoded.slice(0, i), decoded.slice(i + 1)];
}
const isAdmin = (user, pass) => Boolean(CFG.adminPassword) && user === "admin" && safeEqual(pass, CFG.adminPassword);

// While SITE_PASSWORD is set the whole site is private: any user name with that password, or the admin login, gets in
function locked(headers) {
  if (!CFG.sitePassword) return false;
  const [user, pass] = credentials(headers);
  return !(safeEqual(pass, CFG.sitePassword) || isAdmin(user, pass));
}

async function admin(headers) {
  const [user, pass] = credentials(headers);
  if (!isAdmin(user, pass))
    return new Response(CFG.adminPassword ? "Sign in as admin." : "Set ADMIN_PASSWORD to enable the admin page.",
      { status: 401, headers: { "WWW-Authenticate": 'Basic realm="TITA Press admin"', "Content-Type": "text/plain" } });
  const orders = (await store.all()).sort((a, b) => b.created.localeCompare(a.created));
  const paid = orders.filter(o => o.status === "paid");
  const revenue = paid.reduce((s, o) => s + o.total, 0);
  const rows = orders.map(o => `<tr><td>${o.created.slice(0, 16).replace("T", " ")}</td><td>${o.id}</td><td>${esc(o.name)}<br><small>${esc(o.email)}</small></td><td>${o.items.map(i => esc(productById[i]?.name || i)).join("<br>")}</td><td class=n>₹${o.total.toLocaleString("en-IN")}</td><td class="${o.status}">${o.status}${o.downloads ? `<br><small>${o.downloads} downloads</small>` : ""}${o.payment?.paymentId ? `<br><small>${o.payment.paymentId}</small>` : ""}</td></tr>`).join("");
  return html(200, `<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>TITA Press admin</title>
<style>body{font:15px system-ui,sans-serif;margin:0;padding:24px 16px;background:#f4f6fa;color:#1a2132}main{max-width:1100px;margin:auto}table{width:100%;border-collapse:collapse;background:#fff}td,th{padding:8px 10px;border-bottom:1px solid #d9deea;text-align:left;vertical-align:top}small{color:#5a6377}.n{font-variant-numeric:tabular-nums}.paid{color:#1d8656}.failed{color:#c8304f}.pending{color:#5a6377}.stats{display:flex;gap:24px;flex-wrap:wrap;margin:16px 0}.stats b{display:block;font-size:1.6rem}.wrap{overflow-x:auto}</style>
<main><h1>Orders</h1><div class=stats><div><b>${paid.length}</b>paid orders</div><div><b>₹${revenue.toLocaleString("en-IN")}</b>revenue</div><div><b>${new Set(paid.map(o => o.email)).size}</b>customers</div><div><b>${{ live: "Razorpay", test: "Simulated", off: "Off" }[PAYMENTS]}</b>payments</div></div>
<div class=wrap><table><thead><tr><th>Created (UTC)</th><th>Order</th><th>Buyer</th><th>Items</th><th>Total</th><th>Status</th></tr></thead><tbody>${rows || "<tr><td colspan=6>No orders yet.</td></tr>"}</tbody></table></div></main>`);
}

/* ---------- plumbing ---------- */
class UserError extends Error { constructor(msg, status = 400) { super(msg); this.status = status; } }
function safeEqual(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
const text = (status, body) => new Response(body, { status, headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
const html = (status, body) => new Response(body, { status, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
const STATIC = {
  "/": "index.html", "/index.html": "index.html",
  "/terms": "terms.html", "/privacy": "privacy.html", "/refunds": "refunds.html", "/contact": "contact.html",
  "/legal.css": "legal.css",
};
function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, "$2");
  }
}

async function route(request) {
  const url = new URL(request.url);
  const site = CFG.baseUrl || url.origin;
  if (url.pathname === "/healthz") return json(200, { ok: true });
  if (locked(request.headers) && url.pathname !== "/api/razorpay-webhook")
    return new Response("This site is private for now.", { status: 401, headers: { "WWW-Authenticate": 'Basic realm="TITA Press (private preview)"', "Content-Type": "text/plain" } });
  try {
    if (request.method === "GET" && STATIC[url.pathname]) {
      const file = STATIC[url.pathname];
      return new Response(fs.readFileSync(path.join(ROOT, "public", file)), {
        headers: { "Content-Type": file.endsWith(".css") ? "text/css; charset=utf-8" : "text/html; charset=utf-8", "Cache-Control": "no-cache" },
      });
    }
    const dl = url.pathname.match(/^\/d\/([\w-]+)\/(\w+)\/(paper|solutions)$/);
    if (request.method === "GET" && dl) return await download(dl);
    if (request.method === "GET" && url.pathname === "/admin") return await admin(request.headers);
    const handler = routes[`${request.method} ${url.pathname}`];
    if (!handler) return json(404, { error: "Not found" });
    const raw = request.method === "POST" ? await request.text() : "";
    if (raw.length > 64 * 1024) throw new UserError("Request too large.", 413);
    let body = {};
    if (raw) { try { body = JSON.parse(raw); } catch { throw new UserError("Malformed request."); } }
    return json(200, await handler({ body, raw, headers: request.headers, site }));
  } catch (err) {
    if (err instanceof UserError) return json(err.status, { error: err.message });
    console.error(err);
    return json(500, { error: "Something went wrong on our side. Please try again." });
  }
}

export async function handle(request) {
  const response = await route(request);
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "no-referrer");
  response.headers.set("X-Frame-Options", "DENY");
  return response;
}

export const SUMMARY = [
  `Payments: ${{ live: "Razorpay", test: "SIMULATED (local testing only)", off: "OFF until a gateway is configured" }[PAYMENTS]}`,
  `Orders: ${STORAGE} · Site: ${CFG.sitePassword ? "private (password)" : "public"}`,
  `${PAPERS.length} papers, ${PRODUCTS.length} products, PDFs from ${CFG.papersDir}`,
].join("\n");
