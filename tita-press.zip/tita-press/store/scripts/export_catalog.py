"""Export the paper catalogue for the store: one entry per paper, with a sample question
taken from the built paper (same option order as the PDF) and the PDF file names.

Run from anywhere: python3 -B store/scripts/export_catalog.py
"""
import json
import pathlib
import sys

STORE = pathlib.Path(__file__).resolve().parent.parent
PAPERS = STORE.parent / "cat-papers"
sys.path.insert(0, str(PAPERS))
import build  # noqa: E402

FOLDERS = ["diagnostic-01"] + [f"full-mock-{i:02d}" for i in range(1, 21)]


def sample_for(qs, index):
    # Rotate through sections so previews show VARC summaries, DILR and QA across the catalogue
    pool = [q for q in qs if (q["sec"] == "QA") or (q["sec"] == "VARC" and q.get("kind") == "summary")]
    q = pool[(index * 7) % len(pool)]
    out = {"sec": q["sec"], "type": "TITA" if q["tita"] else "MCQ", "q": q["q"], "sol": q["sol"], "n": q["n"]}
    if q["tita"]:
        out["ans"] = str(q["ans"])
    else:
        out["opts"], out["ans"] = q["opts"], q["ans"]
    return out


def main():
    papers = []
    for i, folder in enumerate(FOLDERS):
        build.load_paper(folder)
        qs = build.build_questions()
        stem = f"TITA-Press-{build.PAPER_NAME.replace(' ', '-')}"
        files = {"paper": f"{stem}-Paper.pdf", "solutions": f"{stem}-Solutions.pdf"}
        for f in files.values():
            if not (PAPERS / "out" / f).exists():
                sys.exit(f"Missing {f}: run build.py for {folder} first")
        papers.append({
            "id": "diag" if folder.startswith("diagnostic") else f"m{folder[-2:]}",
            "name": "Diagnostic Mock" if folder.startswith("diagnostic") else build.PAPER_NAME,
            "folder": folder,
            "questions": len(qs),
            "tita": sum(q["tita"] for q in qs),
            "files": files,
            "sample": sample_for(qs, i),
        })
    (STORE / "data").mkdir(exist_ok=True)
    (STORE / "data" / "papers.json").write_text(json.dumps(papers, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Wrote {len(papers)} papers to data/papers.json")


if __name__ == "__main__":
    main()
