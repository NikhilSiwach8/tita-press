// Runs the store on this computer: `node store/server.mjs`, then open http://localhost:3000.
// All the store logic is in app.mjs; this file only turns Node's HTTP requests into Request/Response objects.
import http from "node:http";
import { Readable } from "node:stream";
import { handle, SUMMARY } from "./app.mjs";

const port = +(process.env.PORT || 3000);

http.createServer(async (req, res) => {
  const hasBody = !["GET", "HEAD"].includes(req.method);
  const request = new Request(`http://${req.headers.host || `localhost:${port}`}${req.url}`, {
    method: req.method,
    headers: Object.entries(req.headers).flatMap(([k, v]) => [].concat(v).map(x => [k, x])),
    body: hasBody ? Readable.toWeb(req) : undefined,
    duplex: hasBody ? "half" : undefined,
  });
  try {
    const response = await handle(request);
    res.writeHead(response.status, Object.fromEntries(response.headers));
    res.end(Buffer.from(await response.arrayBuffer()));
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.writeHead(500, { "Content-Type": "text/plain" });
    res.end("Server error");
  }
}).listen(port, () => console.log(`TITA Press store on http://localhost:${port}\n${SUMMARY}`));
